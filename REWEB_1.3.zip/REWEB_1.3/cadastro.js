const form = document.getElementById('formCadastro');
const senha = document.getElementById('senha');
const confirmar = document.getElementById('confirmar');

// Não deixa enviar se as duas senhas forem diferentes
form.addEventListener('submit', function (evento) {

    if (senha.value !== confirmar.value) {
        evento.preventDefault();
        alert('As senhas não são iguais!');
        confirmar.focus();
    }

});
