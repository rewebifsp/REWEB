<?php
// Busca os pedidos no banco para as telas "Painel de encomendas" e "Pesquisar".
// Quem usa: require('buscar-encomendas.php'); e depois percorre a lista $linhas.
require('conexao.php');
require('../Includes/funcoes.php');

// Cada item de pedido vira uma linha da tabela (o JOIN junta o item com os dados do pedido)
$sql = "SELECT i.produto, i.valor, i.quantidade, i.tema, i.precisa_arte, i.arte,
               p.cliente, p.data_pedido, p.prazo, p.pago, p.pronto, p.buscou, p.observacoes
        FROM itens_pedido i
        JOIN pedidos p ON p.id = i.id_pedido
        ORDER BY p.data_pedido DESC, i.id DESC";
$resultado = $con->query($sql);

$linhas = [];
while ($linha = mysqli_fetch_assoc($resultado)) {

    // O total da linha é o valor vezes a quantidade
    $linha['total'] = $linha['valor'] * $linha['quantidade'];

    // Essas informações ajudam os botões de filtro (Aguarda PGTO, Prontos...) da tela
    $linha['f_pagou'] = $linha['pago'] == 1 ? 'sim' : 'nao';
    $linha['f_pronto'] = $linha['pronto'] == 1 ? 'sim' : 'nao';
    $linha['f_arte'] = ($linha['precisa_arte'] == 1 && $linha['arte'] == '') ? 'sim' : 'nao';

    // Prazo próximo: o prazo é daqui a 15 dias ou menos
    $linha['f_prazo'] = ($linha['prazo'] != '' && strtotime($linha['prazo']) <= strtotime('+15 days')) ? 'sim' : 'nao';

    $linhas[] = $linha;
}

// As últimas coisas que aconteceram (caixa amarela "Histórico")
$resultado = $con->query("SELECT descricao, data_hora FROM historico ORDER BY data_hora DESC, id DESC LIMIT 10");
$historico = [];
while ($linha = mysqli_fetch_assoc($resultado)) {
    $historico[] = $linha;
}
