<?php
require('so-adm.php'); // só ADM entra

// Quando o formulário é enviado, salva o produto no banco
if (isset($_POST['produto'])) {

    require('conexao.php');
    require('../Includes/funcoes.php');

    $nome = trim($_POST['produto']);
    $tema = trim($_POST['tema']);
    $preco = (float) $_POST['valor'];
    $especificacoes = trim($_POST['especificacoes']);
    $topico = trim($_POST['topico']);
    $tipo = $_POST['tipo'] == 'pronta_entrega' ? 'pronta_entrega' : 'encomenda';
    $cores = trim($_POST['cores']);

    // O tópico é a categoria. Se já existir usa o que existe, se não existir cria
    $idTopico = null;
    if ($topico != '') {
        $stmt = $con->prepare("SELECT id FROM topicos WHERE nome = ?");
        $stmt->bind_param("s", $topico);
        $stmt->execute();
        $achou = mysqli_fetch_assoc($stmt->get_result());

        if ($achou) {
            $idTopico = $achou['id'];
        } else {
            $stmt = $con->prepare("INSERT INTO topicos (nome) VALUES (?)");
            $stmt->bind_param("s", $topico);
            $stmt->execute();
            $idTopico = $con->insert_id;
        }
    }

    // Guarda a foto do produto (se tiver)
    $foto = salvarImagem('imagem', 'produto_');

    $stmt = $con->prepare("INSERT INTO produtos (nome, tema, preco, especificacoes, id_topico, tipo, cores_disponiveis, foto1) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdsisss", $nome, $tema, $preco, $especificacoes, $idTopico, $tipo, $cores, $foto);
    $stmt->execute();

    $msg = 'Produto salvo com sucesso!';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserir produto | Corisco's Paper</title>
    <link rel="stylesheet" href="Css/admin-base.css">
    <link rel="stylesheet" href="Css/inserir-produto.css">
    <script src="Js/inserir-produto.js" defer></script>
</head>
<body>
    <header class="cabecalho-admin">
        <a href="painel.php" aria-label="Voltar ao painel"><img src="../imagens/logo.png" alt="Corisco's Paper"></a>
        <h1>INSERIR PRODUTO</h1>
    </header>
    <main class="pagina-produto">
        <form id="formProduto" class="form-produto" method="post" enctype="multipart/form-data">
            <section class="campos-produto" aria-label="Dados do produto">

                <label>
                    Produto<input id="nomeProduto" name="produto" type="text" placeholder="Nome do produto" required>
                </label>
                <label>
                    Tema<input name="tema" type="text" placeholder="Tema">
                </label>
                <label>
                    Valor<input id="valorProduto" name="valor" type="number" min="0" step="0.01" placeholder="0,00" required>
                </label>
                <label>
                    Especificações<textarea name="especificacoes" rows="3" placeholder="Detalhes do produto"></textarea>
                </label>
                <label>
                    Tópico<input name="topico" type="text" placeholder="Categoria">
                </label>
                <label>
                    Tipo<select name="tipo">
                        <option value="encomenda">Encomenda</option>
                        <option value="pronta_entrega">Pronta entrega</option>
                    </select>
                </label>
                <label>
                    Cores disponíveis<input name="cores" type="text" placeholder="Ex.: azul, rosa, amarelo">
                </label>
                <label>
                    Foto do produto<input id="imagemProduto" name="imagem" type="file" accept="image/*">
                </label>

            </section>
            
            <article class="cartao-produto">
                <div class="foto-produto">
                    <img id="previaImagem" src="../imagens/caixa.png" alt="Prévia do produto">
                </div>

                <h2 id="previaNome">NOME DO PRODUTO</h2>

                <p id="previaValor">R$ 0,00</p>

                <div class="especificacoes-previa" id="previaEspecificacoes">ESPECIFICAÇÕES</div>

            </article>
            
            <div class="acoes-formulario">
                <a href="painel.php">VOLTAR</a>
                <button type="submit">ENVIAR</button>
            </div>
        </form>
    </main>
    <?php
    // Se tiver mensagem, mostra num alert
    if (isset($msg)) {
        echo "<script>alert('$msg');</script>";
    }
    ?>
</body>
</html>
