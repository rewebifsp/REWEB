<?php
require('so-adm.php'); // só ADM entra

// Quando o formulário é enviado, salva a encomenda no banco
if (isset($_POST['cliente'])) {

    require('conexao.php');
    require('../Includes/funcoes.php');

    // Pega o que foi preenchido no formulário
    $cliente = trim($_POST['cliente']);
    $produto = trim($_POST['produto']);
    $valor = (float) $_POST['valor'];
    $quantidade = (int) $_POST['quantidade'];
    $tema = trim($_POST['tema']);
    $telefone = trim($_POST['telefone']);
    $endereco = trim($_POST['endereco']);
    $email = trim($_POST['email']);
    $observacoes = trim($_POST['observacoes']);

    // Se a data não foi preenchida, usa a data de hoje
    $data = $_POST['data'] != '' ? $_POST['data'] : date('Y-m-d');
    $data = $data . ' 00:00:00';

    // O prazo é opcional (fica vazio no banco quando não preenchido)
    $prazo = $_POST['prazo'] != '' ? $_POST['prazo'] : null;

    // Caixinhas de marcar: marcada = 1, desmarcada = 0
    $pagou = isset($_POST['pagou']) ? 1 : 0;
    $buscou = isset($_POST['buscou']) ? 1 : 0;

    // Se tem endereço é entrega, se não tem é retirada
    $forma = $endereco != '' ? 'entrega' : 'retirada';

    // Guarda a foto da encomenda (se tiver)
    $arte = salvarImagem('foto', 'encomenda_');

    // Salva o pedido (criado_por = 'adm' porque foi a administração que anotou)
    $stmt = $con->prepare("INSERT INTO pedidos (criado_por, cliente, telefone, email, forma_entrega, endereco, data_pedido, prazo, pago, buscou, observacoes) VALUES ('adm', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssiis", $cliente, $telefone, $email, $forma, $endereco, $data, $prazo, $pagou, $buscou, $observacoes);
    $stmt->execute();
    $idPedido = $con->insert_id;

    // Salva o produto dentro do pedido
    $stmt = $con->prepare("INSERT INTO itens_pedido (id_pedido, produto, valor, quantidade, tema, arte) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isdiss", $idPedido, $produto, $valor, $quantidade, $tema, $arte);
    $stmt->execute();

    // Anota no histórico
    $descricao = 'Administração adicionou encomenda de ' . $cliente;
    $stmt = $con->prepare("INSERT INTO historico (descricao, id_pedido) VALUES (?, ?)");
    $stmt->bind_param("si", $descricao, $idPedido);
    $stmt->execute();

    // Volta para o painel de encomendas
    header('Location: encomendas.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserir encomenda | Corisco's Paper</title>
    <link rel="stylesheet" href="Css/admin-base.css">
    <link rel="stylesheet" href="Css/adicionar-encomenda.css">
</head>
<body>
    <header class="cabecalho-admin">
        <a href="painel.php" aria-label="Voltar ao painel"><img src="../imagens/logo.png" alt="Corisco's Paper"></a>
        <h1>INSERIR ENCOMENDA</h1>
    </header>
    <main class="conteudo-admin">
        <form class="form-encomenda" id="formEncomenda" method="post" enctype="multipart/form-data">
            <div class="campos-encomenda">
                <label>Cliente<input name="cliente" type="text" placeholder="Nome do cliente" required></label>

                <label>Produto<input name="produto" type="text" placeholder="Produto" required></label>

                <label>Valor<input name="valor" type="number" min="0" step="0.01" placeholder="0,00" required></label>

                <label>Quantidade<input name="quantidade" type="number" min="1" placeholder="1" required></label>

                <label>Data<input name="data" type="date" required></label>

                <label>Tema<input name="tema" type="text" placeholder="Tema da encomenda"></label>

                <label>Prazo<input name="prazo" type="date"></label>

                <label>Telefone<input name="telefone" type="tel" placeholder="(00) 00000-0000"></label>

                <label>Endereço<input name="endereco" type="text" placeholder="Endereço do cliente"></label>

                <label>E-mail<input name="email" type="email" placeholder="email@exemplo.com"></label>

                <label class="campo-largo">Observações
                    <textarea name="observacoes" rows="3" placeholder="Detalhes da encomenda"></textarea>
                </label>

                <label class="marcacao"><input name="pagou" type="checkbox"> Já pagou</label>

                <label class="marcacao"><input name="buscou" type="checkbox"> Já buscou</label>

                <label class="campo-largo">Foto da encomenda<input name="foto" type="file" accept="image/*"></label>
            </div>

            <div class="acoes-formulario">
                <a href="painel.php">VOLTAR</a>
                <button type="submit">ENVIAR</button>
            </div>
        </form>
    </main>
</body>
</html>
