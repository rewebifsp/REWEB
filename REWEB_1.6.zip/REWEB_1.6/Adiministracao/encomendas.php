<?php
require('so-adm.php'); // só ADM entra
require('buscar-encomendas.php'); // busca os pedidos no banco
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de encomendas | Corisco's Paper</title>
    <link rel="stylesheet" href="Css/admin-base.css">
    <link rel="stylesheet" href="Css/encomendas.css">
    <script src="Js/encomendas.js" defer></script>
</head>
<body>
    <header class="cabecalho-admin">
        <a href="painel.php" aria-label="Voltar ao painel"><img src="../imagens/logo.png" alt="Corisco's Paper"></a>
        <h1>PAINEL DE ENCOMENDAS</h1>
    </header>

    <main class="pagina-encomendas">
    
        <div class="barra-acoes">
            <button id="exportar" type="button">Exportar CSV</button>
            <a href="adicionar-encomenda.php">+ Nova encomenda</a><a href="pesquisar.php">Pesquisar</a>
        </div>

        <section class="filtros-encomendas">

            <label>
                <span class="somente-leitor">Buscar encomenda</span>
                <input id="buscaEncomendas" type="search" placeholder="Pesquisar cliente ou encomenda">
            </label>
           
            <div class="filtros-rapidos">
                <button type="button" data-filtro="aguardando">Aguarda PGTO</button>
                <button type="button" data-filtro="pronto">Prontos</button>
                <button type="button" data-filtro="prazo">Prazo próximo</button>
                <button type="button" data-filtro="arte">Enviar arte</button>
                <button type="button" id="limpar">Limpar filtros</button>
            </div>

        </section>
        
        <div class="tabela-rolagem">
            <table id="tabelaEncomendas">
                <thead>
                    <tr>
                        <th>Cliente</th>
                        <th>Produto</th>
                        <th>Valor</th>
                        <th>Qtd.</th>
                        <th>Total</th>
                        <th>Data</th>
                        <th>Tema</th>
                        <th>Pagou</th>
                        <th>Buscou</th>
                        <th>Prazo</th>
                        <th>Obs.</th>
                        <th>Ações</th>
                    </tr>
                </thead>
            
                <tbody>
                    <?php foreach ($linhas as $linha) { ?>
                    <tr data-pagou="<?php echo $linha['f_pagou']; ?>" data-pronto="<?php echo $linha['f_pronto']; ?>" data-prazo="<?php echo $linha['f_prazo']; ?>" data-arte="<?php echo $linha['f_arte']; ?>">
                        <td contenteditable="false"><?php echo escapar($linha['cliente']); ?></td>
                        <td contenteditable="false"><?php echo escapar($linha['produto']); ?></td>
                        <td contenteditable="false"><?php echo dinheiro($linha['valor']); ?></td>
                        <td contenteditable="false"><?php echo $linha['quantidade']; ?></td>
                        <td><?php echo dinheiro($linha['total']); ?></td>
                        <td contenteditable="false"><?php echo date('d/m/y', strtotime($linha['data_pedido'])); ?></td>
                        <td><?php echo escapar($linha['tema']); ?></td>
                        <td class="<?php echo $linha['pago'] == 1 ? 'pago' : 'pendente'; ?>"><?php echo $linha['pago'] == 1 ? 'Sim' : 'Não'; ?></td>
                        <td><?php echo $linha['buscou'] == 1 ? 'Sim' : 'Não'; ?></td>
                        <td><?php echo $linha['prazo'] != '' ? date('d/m/y', strtotime($linha['prazo'])) : ''; ?></td>
                        <td><?php echo escapar($linha['observacoes']); ?></td>
                        <td class="acoes-linha">
                            <button class="editar" type="button">Editar</button>
                            <button class="excluir" type="button">Excluir</button>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        
        <section class = "historico" >
            <h2>Histórico</h2>
            <?php foreach ($historico as $item) { ?>
            <p>
                <span><?php echo escapar($item['descricao']); ?></span>
                <time><?php echo date('d/m/y — H:i', strtotime($item['data_hora'])); ?></time>
            </p>
            <?php } ?>
        </section>
        
        <a class="botao-voltar" href="painel.php">VOLTAR À PÁGINA INICIAL</a>
    
    </main>
</body>
</html>
