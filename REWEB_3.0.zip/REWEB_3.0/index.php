<?php
// Conecta com o banco de dados
// A tela inicial ainda não busca nada no banco, então a conexão fica desligada por enquanto.
// (Se o MySQL estiver desligado, essa linha derrubaria a página inteira.) Tirar o // quando for carregar os produtos.
require('Adiministracao/conexao.php');

require('Includes/funcoes.php'); // funções escapar() e sqlDisponivel()

// Inicia a sessão
@session_start();

// Produtos do carrossel: os de pronta entrega que ainda têm estoque (os últimos cadastrados primeiro).
// Quando o estoque de um produto zera, ele some daqui sozinho (ver sqlDisponivel() em Includes/funcoes.php).
$resultadoCarrossel = $con->query("SELECT id, nome, foto1
                                   FROM produtos
                                   WHERE estoque > 0 AND ativo = 1 AND " . sqlDisponivel() . "
                                   ORDER BY id DESC
                                   LIMIT 5");
$produtosCarrossel = [];
while ($linha = mysqli_fetch_assoc($resultadoCarrossel)) {
    $produtosCarrossel[] = $linha;
}

// Verifica se o usuário está logado
$usuarioLogado = isset($_SESSION['usuario']) && !empty($_SESSION['usuario']) ? $_SESSION['usuario'] : null;

// Quantos itens diferentes tem no carrinho (o carrinho fica guardado na sessão)
$qtdCarrinho = isset($_SESSION['carrinho']) ? count($_SESSION['carrinho']) : 0;

// Se tem item no carrinho, o botão ganha a classe "com-itens" (círculo laranja no CSS)
$classeCarrinho = $qtdCarrinho > 0 ? ' com-itens' : '';

// Texto que leitores de tela falam ao chegar no carrinho (exemplo: "Carrinho: 3 itens")
$textoCarrinho = 'Carrinho';
if ($qtdCarrinho > 0) {
    $textoCarrinho = 'Carrinho: ' . $qtdCarrinho . ($qtdCarrinho == 1 ? ' item' : ' itens');
}



?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Corisco's Paper</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); ?>"> <!-- ?v=... muda quando o CSS muda: o navegador não usa uma cópia antiga -->
</head>

<body>

    <header class="cabecalho cabecalho-inicio">

        <!-- Redes sociais. TROCAR os dois links pelos reais da Corisco's Paper -->
        <!-- Eu pedro, ja realizei as trocas dos links pelos links reais, e adicionei o carrinho e o coração de favoritos -->
        <div class="redes">
            <a class="rede-insta" href="https://www.instagram.com/juliacoriscopapelaria?rpxt=cHZmZG5xanV1enc0" target="_blank" rel="noopener"
                aria-label="Instagram da Corisco's Paper">
                <svg viewBox="0 0 24 24" aria-hidden="true">
                    <rect x="3" y="3" width="18" height="18" rx="5" />
                    <circle cx="12" cy="12" r="4" />
                    <circle cx="17.2" cy="6.8" r=".6" />
                </svg>
            </a>
            <a class="rede-zap" href="https://wa.me/5519988565666" target="_blank" rel="noopener"
                aria-label="WhatsApp da Corisco's Paper">
                <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M3 21l1.6-4.8A9 9 0 1 1 8 19.6L3 21z" />
                    <path d="M9 8.5c0 3.5 3 6.5 6.5 6.5l1-1.5-2-1-1 .8c-1-.4-2-1.4-2.4-2.4l.8-1-1-2z" />
                </svg>
            </a>
        </div>
        <!-- Logo (caixinha + nome). Aqui na tela inicial não precisa ser link.
             Nas outras telas, colocar <a href="index.html"> em volta da imagem para voltar ao início. -->
        <div class="logo">
            <img class="logo-img" src="imagens/logo.png" alt="Corisco's Paper - Papelaria Criativa">
        </div>

        <!-- Lado direito: favoritos, carrinho e login juntos (assim a logo continua no centro) -->
        <div class="lado-direito">

        <!-- Favoritos e carrinho aparecem para todos (favoritos leva ao login se não estiver logado) -->
        <div class="atalhos-loja">
            <button type="button" aria-label="Favoritos" onclick="window.location.href='Favoritos/favoritos.php'">
                <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8z"/>
                </svg>
            </button>

            <button class="botao-carrinho-inicio<?php echo $classeCarrinho; ?>" type="button" aria-label="<?php echo $textoCarrinho; ?>" onclick="window.location.href='Carrinho/carrinho.php'">
                <img src="imagens/carrinho.png" alt="">

                <!-- Número de itens diferentes: só aparece quando o carrinho não está vazio -->
                <?php if ($qtdCarrinho > 0) { ?>
                    <span class="contagem-inicio"><?php echo $qtdCarrinho; ?></span>
                <?php } ?>
            </button>
        </div>

        <!-- Login: o círculo escuro depois pode virar a foto/ícone do usuário -->
        <a class="login" href="<?php echo $usuarioLogado != null ? 'Cadastro/deslogar.php' : 'Cadastro/login.php'; ?>">

            <span class="login-icone"></span>

            <span class="login-texto">
                <?php if ($usuarioLogado != null) { ?>
                    LOGADO
                    <small>Sair da conta</small>
                <?php } else { ?>
                    LOGIN
                    <small>ou cadastre-se</small>
                <?php } ?>
            </span>

        </a>

        </div>

    </header>

    <main>

        <!-- Pesquisa e menu -->
        <section class="area-busca">

            <form class="form-busca" action="Pesquisa/pesquisa.php" method="get">
                <!-- Bonequinho da pesquisa: salvar a imagem em imagens/pesquisa.png -->
                <img class="mascote" src="imagens/pesquisa.png" alt="" onerror="this.remove()">
                <input class="busca" type="search" name="pesquisa"
                    placeholder="PESQUISA" aria-label="Pesquisar produtos">
            </form>

            <!-- Atualizado para essa navegção, side bar deixou de existir -->
            <nav class="navegacao-categorias" aria-label="Categorias">
                <!-- Cada categoria leva para a tela de tópicos (a mesma tela serve para todas) -->
                <a href="Topicos/topicos.php">GERAL</a>
                <a href="Topicos/topicos.php?nome=Lou%C3%A7as">LOUÇAS</a>
                <a href="Topicos/topicos.php?nome=T%C3%AAxtil">TÊXTIL</a>
                <a href="Topicos/topicos.php?nome=Topper">TOPPER</a>
                <a href="Topicos/topicos.php?nome=Papel%20arroz">PAPEL ARROZ/AÇÚCAR</a>
                <a href="Topicos/topicos.php?nome=Brindes">BRINDES</a>
                <a href="Topicos/topicos.php?nome=Encaderna%C3%A7%C3%A3o">ENCADERNAÇÃO</a>
            </nav>

        </section>

        <!-- Banner -->
        <!-- Banner: carrossel só de imagens (as fotos ficam em imagens/banner-1.jpg até banner-4.jpg).
             Para trocar uma imagem, é só substituir o arquivo com o mesmo nome. -->
        <section class="banner" id="inicio" aria-label="Destaques da loja">

            <div class="banner-slides">
                <img class="banner-slide ativo" src="imagens/banner-1.jpg" alt="Corisco's Paper em parceria com a ReWeb">
                <img class="banner-slide" src="imagens/banner-2.jpg" alt="Topos de bolo personalizados: simples, únicos e 3D">
                <img class="banner-slide" src="imagens/banner-3.jpg" alt="Papel arroz: impressão comestível para bolos">
                <img class="banner-slide" src="imagens/banner-4.jpg" alt="Canecas personalizadas: sublimação, jateada, alumínio e vidro/cristal">
            </div>

            <button class="banner-seta banner-voltar" id="banner-voltar" type="button" aria-label="Imagem anterior">&#10094;</button>
            <button class="banner-seta banner-avancar" id="banner-avancar" type="button" aria-label="Próxima imagem">&#10095;</button>

            <div class="banner-bolinhas" id="banner-bolinhas">
                <button type="button" class="ativa" aria-label="Ir para a imagem 1"></button>
                <button type="button" aria-label="Ir para a imagem 2"></button>
                <button type="button" aria-label="Ir para a imagem 3"></button>
                <button type="button" aria-label="Ir para a imagem 4"></button>
            </div>

        </section>

        <!-- Produtos pronta entrega -->
        <section class="secao-pronta-entrega">

            <!-- O título agora é só texto. O caminho para a tela de produtos pronta entrega é o cartão "Ver mais" no fim do carrossel -->
            <h2>PRODUTOS PRONTA ENTREGA</h2>

            <?php if (count($produtosCarrossel) == 0) { ?>

                <!-- Nenhum produto pronta entrega com estoque -->
                <p class="carrossel-vazio">No momento não temos produtos pronta entrega.</p>

            <?php } else { ?>

            <!-- CARROSEL: um cartão com a foto de cada produto pronta entrega que tem estoque.
                 É uma fila com começo e fim: termina no cartão "Ver mais" (não gira em círculo) -->
            <div class="area-carrossel">

                <button class="seta" id="voltar" type="button" aria-label="Produto anterior">
                    &#10094;
                </button>

                <div class="carrossel-fundo">
                <div class="carrossel" id="carrossel">

                    <?php foreach ($produtosCarrossel as $produto) { ?>
                        <a href="Produto/produto.php?id=<?php echo (int) $produto['id']; ?>" class="produto-card">
                            <img src="<?php echo $produto['foto1'] != '' ? escapar($produto['foto1']) : 'imagens/caixa.png'; ?>" alt="<?php echo escapar($produto['nome']); ?>">
                        </a>
                    <?php } ?>

                    <!-- Último cartão da fila (no lugar de um 6º produto): leva para a tela com TODOS os produtos pronta entrega -->
                    <a href="ProntaEntrega/pronta-entrega.php" class="produto-card card-ver-mais">
                        Ver mais
                        <span>&#10095;</span>
                    </a>

                </div>
                </div><!-- fim do carrossel-fundo -->

                <button class="seta" id="avancar" type="button" aria-label="Próximo produto">
                    &#10095;
                </button>

            </div>

            <?php } ?>

        </section>

        <!-- Categorias -->
        <section class="secao-produtos" id="produtos">

            <h2>PRODUTOS</h2>

            <div class="categorias">

                <!-- Cada botão joga o nome da categoria na tela de pesquisa (Pesquisa/pesquisa.php?pesquisa=NOME).
                     O texto do link vem com %XX no lugar de acentos e espaços (é assim que o endereço do site escreve).
                     Os id continuam aqui porque o menu do topo usa index.php#papel-arroz -->
                <a href="Pesquisa/pesquisa.php?pesquisa=Sublima%C3%A7%C3%A3o" id="sublimacao">SUBLIMAÇÃO</a>
                <a href="Pesquisa/pesquisa.php?pesquisa=Brindes">BRINDES</a>
                <a href="Pesquisa/pesquisa.php?pesquisa=Papel%20arroz" id="papel-arroz">PAPEL ARROZ</a>
                <a href="Pesquisa/pesquisa.php?pesquisa=Encaderna%C3%A7%C3%A3o">ENCADERNAÇÃO</a>
                <a href="Pesquisa/pesquisa.php?pesquisa=Topper">TOPPER</a>

            </div>

        </section>

        <!-- Coleções -->
        <section class="secao-colecoes" id="colecoes">

            <h2>COLEÇÕES</h2>

            <div class="colecoes">

                <!-- As coleções ainda não existem no banco, então cada uma pesquisa uma palavra
                     que aparece no nome ou no tema dos produtos (ex.: um produto chamado "Camisa ..." aparece em CAMISAS) -->
                <a href="Pesquisa/pesquisa.php?pesquisa=Camisa">
                    <span class="circulo camisas"></span>
                    <span>CAMISAS</span>
                </a>

                <a href="Pesquisa/pesquisa.php?pesquisa=Kit%20festa">
                    <span class="circulo kit-festas"></span>
                    <span>KITS FESTA</span>
                </a>

                <a href="Pesquisa/pesquisa.php?pesquisa=Presente">
                    <span class="circulo presentes"></span>
                    <span>PRESENTES</span>
                </a>

                <a href="Pesquisa/pesquisa.php?pesquisa=Volta%20%C3%A0s%20aulas">
                    <span class="circulo volta-aulas"></span>
                    <span>VOLTA ÀS<br>AULAS</span>
                </a>

                <a href="Pesquisa/pesquisa.php?pesquisa=Datas%20festivas">
                    <span class="circulo datas-festivas"></span>
                    <span>DATAS<br>FESTIVAS</span>
                </a>

            </div>

        </section>

    </main>

    <?php include('Includes/rodape.php'); ?>

    <!-- ?v=... muda sempre que o script.js é alterado, assim o navegador não usa uma cópia antiga guardada em cache -->
    <script src="script.js?v=<?php echo filemtime(__DIR__ . '/script.js'); ?>"></script>
    
     <!-- acessibilidades implementadas -->
    <div data-acc-position="bottom-left"></div>
    <script src="https://cdn.jsdelivr.net/gh/ifrederico/accessible-web-widget@1.6.3/dist/accessible-web-widget.min.js"></script>
    <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>

</body>
</html>
