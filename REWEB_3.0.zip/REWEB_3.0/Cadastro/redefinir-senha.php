<?php
$token = (string)($_GET['token'] ?? '');
$tokenValido = (bool)preg_match('/^[a-f0-9]{64}$/', $token);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir senha - Corisco's Paper</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
    <link rel="stylesheet" href="Css/login.css">
    <link rel="stylesheet" href="Css/recuperacao.css?v=<?php echo filemtime(__DIR__ . '/Css/recuperacao.css'); ?>">
</head>
<body>
    <header class="cabecalho cabecalho-recuperacao"><a class="logo" href="../index.php" aria-label="Voltar para a tela inicial"><img class="logo-img" src="../imagens/logo.png" alt="Corisco's Paper - Papelaria Criativa"></a></header>
    <main class="area-login area-recuperacao">
        <section class="coluna-form">
            <h1 class="titulo-recuperacao">REDEFINIR SENHA</h1>
            <p class="instrucao-recuperacao">Escolha uma nova senha para sua conta de cliente.</p>
            <?php if ($tokenValido): ?>
            <form class="form-login" id="formRedefinirSenha" action="salvar-nova-senha.php" method="post">
                <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
                <label class="so-leitor" for="novaSenha">Nova senha</label>
                <input class="campo" id="novaSenha" name="senha" type="password" placeholder="NOVA SENHA" autocomplete="new-password" minlength="8" maxlength="4096" required>
                <label class="so-leitor" for="confirmarSenha">Repita a nova senha</label>
                <input class="campo" id="confirmarSenha" name="confirmarSenha" type="password" placeholder="CONFIRMAR SENHA" autocomplete="new-password" minlength="8" maxlength="4096" required>
                <p class="erro-senha" id="erroSenha" role="alert" hidden>As senhas precisam ser iguais.</p>
                <button class="botao-entrar" type="submit">SALVAR SENHA</button>
            </form>
            <?php else: ?>
            <p class="mensagem-status" role="alert">Link inválido. Solicite uma nova recuperação.</p>
            <?php endif; ?>
            <p class="mensagem-status" id="statusRedefinicao" role="status" aria-live="polite"></p>
            <a class="link-azul voltar-login" href="esqueci-senha.php">SOLICITAR NOVO LINK</a>
            <a class="link-azul voltar-login" href="login.php">VOLTAR PARA O LOGIN</a>
        </section>
        <div class="coluna-imagem"><img src="../imagens/caixa.png" alt="Ilustração de uma caixa de presentes"></div>
    </main>
    <?php $raiz = '../'; include('../Includes/rodape.php'); ?>
    <script src="Js/recuperacao.js?v=<?php echo filemtime(__DIR__ . '/Js/recuperacao.js'); ?>"></script>
    <div data-acc-position="bottom-left"></div>
    <script src="https://cdn.jsdelivr.net/gh/ifrederico/accessible-web-widget@1.6.3/dist/accessible-web-widget.min.js"></script>
    <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
</body>
</html>
