<?php
session_start();
require_once __DIR__ . '/recuperacao-comum.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    recuperacaoJson(405, ['ok' => false, 'mensagem' => 'Método não permitido.']);
}
if (!$con) {
    error_log('Recuperação ReWeb: ' . mysqli_connect_error());
    recuperacaoJson(500, ['ok' => false, 'mensagem' => 'Não foi possível processar agora. Tente novamente mais tarde.']);
}
$token = strtolower(trim((string)($_POST['token'] ?? '')));
$senha = (string)($_POST['senha'] ?? '');
if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
    recuperacaoJson(400, ['ok' => false, 'mensagem' => 'Link inválido ou expirado. Solicite uma nova recuperação.']);
}
if (strlen($senha) < 8 || strlen($senha) > 4096) {
    recuperacaoJson(400, ['ok' => false, 'mensagem' => 'A senha deve ter pelo menos 8 caracteres.']);
}
$tokenHash = hash('sha256', $token);
$con->begin_transaction();
try {
    $stmt = $con->prepare('SELECT id, login_id, expira_em, usado_em, tentativas FROM reweb_tokens_recuperacao WHERE token_hash = ? LIMIT 1 FOR UPDATE');
    $stmt->bind_param('s', $tokenHash);
    $stmt->execute();
    $registro = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$registro || $registro['usado_em'] !== null || strtotime($registro['expira_em'] . ' UTC') <= time() || (int)$registro['tentativas'] >= 5) {
        $con->rollback();
        recuperacaoJson(400, ['ok' => false, 'mensagem' => 'Link inválido ou expirado. Solicite uma nova recuperação.']);
    }
    $stmt = $con->prepare('UPDATE reweb_tokens_recuperacao SET tentativas = tentativas + 1 WHERE id = ?');
    $stmt->bind_param('i', $registro['id']);
    $stmt->execute();
    $stmt->close();
    $confirmacao = (string)($_POST['confirmarSenha'] ?? '');
    if (!hash_equals($senha, $confirmacao)) {
        $con->commit();
        recuperacaoJson(400, ['ok' => false, 'mensagem' => 'As senhas informadas não são iguais.']);
    }
    $hashSenha = password_hash($senha, PASSWORD_DEFAULT);
    $stmt = $con->prepare('UPDATE login SET senha = ? WHERE id = ?');
    $stmt->bind_param('si', $hashSenha, $registro['login_id']);
    $stmt->execute();
    $stmt->close();
    $stmt = $con->prepare('UPDATE reweb_tokens_recuperacao SET usado_em = UTC_TIMESTAMP() WHERE id = ?');
    $stmt->bind_param('i', $registro['id']);
    $stmt->execute();
    $stmt->close();
    $stmt = $con->prepare('UPDATE reweb_tokens_recuperacao SET usado_em = UTC_TIMESTAMP() WHERE login_id = ? AND id <> ? AND usado_em IS NULL');
    $stmt->bind_param('ii', $registro['login_id'], $registro['id']);
    $stmt->execute();
    $stmt->close();
    $con->commit();
    recuperacaoJson(200, ['ok' => true, 'mensagem' => 'Senha alterada com sucesso. Você já pode entrar com a nova senha.']);
} catch (Throwable $e) {
    $con->rollback();
    error_log('Recuperação ReWeb: erro ao redefinir senha: ' . $e->getMessage());
    recuperacaoJson(500, ['ok' => false, 'mensagem' => 'Não foi possível salvar a senha agora. Tente novamente.']);
}
