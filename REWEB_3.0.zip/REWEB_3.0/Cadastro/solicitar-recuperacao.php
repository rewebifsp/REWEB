<?php
session_start();
require_once __DIR__ . '/recuperacao-comum.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    recuperacaoJson(405, ['ok' => false, 'mensagem' => 'Método não permitido.']);
}
if (!$con) {
    error_log('Recuperação ReWeb: ' . mysqli_connect_error());
    recuperacaoJson(500, ['ok' => false, 'mensagem' => 'Não foi possível processar agora. Tente novamente mais tarde.']);
}
$email = strtolower(trim((string)($_POST['email'] ?? '')));
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 100) {
    recuperacaoJson(400, ['ok' => false, 'mensagem' => 'Informe um e-mail válido.']);
}
$ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'desconhecido');
$emailHash = hash('sha256', 'email:' . $email);
$ipHash = hash('sha256', 'ip:' . $ip);
$con->begin_transaction();
try {
    $okEmail = limitarRecuperacao($con, $emailHash, 3);
    $okIp = limitarRecuperacao($con, $ipHash, 10);
    if (!$okEmail || !$okIp) {
        $con->commit();
        recuperacaoJson(200, ['ok' => true, 'mensagem' => 'Se houver uma conta para esse e-mail, enviaremos as instruções de recuperação.']);
    }
    $stmt = $con->prepare('SELECT id, email FROM login WHERE LOWER(email) = ? LIMIT 1');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $cliente = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $token = null;
    if ($cliente) {
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $stmt = $con->prepare('UPDATE reweb_tokens_recuperacao SET usado_em = UTC_TIMESTAMP() WHERE login_id = ? AND usado_em IS NULL');
        $stmt->bind_param('i', $cliente['id']);
        $stmt->execute();
        $stmt->close();
        $stmt = $con->prepare('INSERT INTO reweb_tokens_recuperacao (login_id, token_hash, criado_em, expira_em, tentativas) VALUES (?, ?, UTC_TIMESTAMP(), DATE_ADD(UTC_TIMESTAMP(), INTERVAL 30 MINUTE), 0)');
        $stmt->bind_param('is', $cliente['id'], $tokenHash);
        $stmt->execute();
        $stmt->close();
    }
    $con->commit();
    if ($cliente && $token !== null) {
        enviarEmailRecuperacao($cliente['email'], $token);
    }
    recuperacaoJson(200, ['ok' => true, 'mensagem' => 'Se houver uma conta para esse e-mail, enviaremos as instruções de recuperação.']);
} catch (Throwable $e) {
    $con->rollback();
    error_log('Recuperação ReWeb: erro ao solicitar token: ' . $e->getMessage());
    recuperacaoJson(500, ['ok' => false, 'mensagem' => 'Não foi possível processar agora. Tente novamente mais tarde.']);
}
