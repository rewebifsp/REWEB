<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar senha - Corisco's Paper</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
    <link rel="stylesheet" href="Css/login.css">
    <link rel="stylesheet" href="Css/recuperacao.css?v=<?php echo filemtime(__DIR__ . '/Css/recuperacao.css'); ?>">
</head>
<body>
    <header class="cabecalho cabecalho-recuperacao"><a class="logo" href="../index.php" aria-label="Voltar para a tela inicial"><img class="logo-img" src="../imagens/logo.png" alt="Corisco's Paper - Papelaria Criativa"></a></header>
    <main class="area-login area-recuperacao">
        <section class="coluna-form">
            <h1 class="titulo-recuperacao">ESQUECI A SENHA</h1>
            <p class="instrucao-recuperacao">Informe o e-mail cadastrado na sua conta de cliente.</p>
            <form class="form-login" id="formSolicitarCodigo" action="solicitar-recuperacao.php" method="post">
                <label class="so-leitor" for="emailRecuperacao">E-mail</label>
                <input class="campo" id="emailRecuperacao" name="email" type="email" maxlength="100" placeholder="E-MAIL CADASTRADO" autocomplete="email" required>
                <button class="botao-entrar" type="submit">ENVIAR LINK DE RECUPERAÇÃO</button>
            </form>
            <p class="mensagem-status" id="statusSolicitacao" role="status" aria-live="polite"></p>
            <a class="link-azul voltar-login" href="login.php">VOLTAR PARA O LOGIN</a>
        </section>
        <div class="coluna-imagem"><img src="../imagens/caixa.png" alt="Ilustração de uma caixa de presentes"></div>
    </main>
    <?php $raiz = '../'; include('../Includes/rodape.php'); ?>
    <script src="Js/recuperacao.js?v=<?php echo filemtime(__DIR__ . '/Js/recuperacao.js'); ?>"></script>
    <div data-acc-position="bottom-left"></div>
    <script src="https://cdn.jsdelivr.net/gh/ifrederico/accessible-web-widget@1.6.3/dist/accessible-web-widget.min.js"></script>
    <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
</body>
</html>
