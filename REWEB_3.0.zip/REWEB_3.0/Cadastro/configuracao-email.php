<?php
// Copie para configuracao-email.php e preencha com os dados SMTP da conta remetente.
return [
    'host' => 'smtp.gmail.com',
    'username' => 'juliacoriscopapelaria@gmail.com',
    'password' => 'olktfvwkfasuyqpy',
    'port' => 587,
    'secure' => PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS,
    'from_email' => 'juliacoriscopapelaria@gmail.com',
    'from_name' => "ReWeb - Corisco's Paper",
    // Ajuste para a pasta do projeto dentro de htdocs.
    'base_url' => 'http://localhost/REWEB_2.8',
];
