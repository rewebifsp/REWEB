<?php
// Shared helpers for client password recovery. Admin authentication stays independent.
require_once __DIR__ . '/../Adiministracao/conexao.php';

function recuperacaoJson(int $status, array $body): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function limitarRecuperacao(mysqli $con, string $escopo, int $limite): bool
{
    $stmt = $con->prepare('INSERT IGNORE INTO reweb_recuperacao_limites (escopo_hash, inicio_janela, quantidade) VALUES (?, UTC_TIMESTAMP(), 0)');
    $stmt->bind_param('s', $escopo);
    $stmt->execute();
    $stmt->close();

    $stmt = $con->prepare('SELECT inicio_janela, quantidade FROM reweb_recuperacao_limites WHERE escopo_hash = ? FOR UPDATE');
    $stmt->bind_param('s', $escopo);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$row) {
        return false;
    }

    $inicio = strtotime($row['inicio_janela'] . ' UTC');
    if ($inicio === false || $inicio <= time() - 3600) {
        $stmt = $con->prepare('UPDATE reweb_recuperacao_limites SET inicio_janela = UTC_TIMESTAMP(), quantidade = 1 WHERE escopo_hash = ?');
        $stmt->bind_param('s', $escopo);
        $stmt->execute();
        $stmt->close();
        return true;
    }
    if ((int)$row['quantidade'] >= $limite) {
        return false;
    }
    $stmt = $con->prepare('UPDATE reweb_recuperacao_limites SET quantidade = quantidade + 1 WHERE escopo_hash = ?');
    $stmt->bind_param('s', $escopo);
    $stmt->execute();
    $stmt->close();
    return true;
}

function enviarEmailRecuperacao(string $destinatario, string $token): bool
{
    $configFile = __DIR__ . '/configuracao-email.php';
    $autoload = __DIR__ . '/../vendor/autoload.php';
    if (!is_file($configFile) || !is_file($autoload)) {
        error_log('Recuperação ReWeb: configure configuracao-email.php e instale PHPMailer pelo Composer.');
        return false;
    }
    $config = require $configFile;
    require_once $autoload;
    if (empty($config['host']) || empty($config['username']) || empty($config['password']) || empty($config['from_email'])) {
        error_log('Recuperação ReWeb: configuração SMTP incompleta.');
        return false;
    }

    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = $config['host'];
        $mail->SMTPAuth = true;
        $mail->Username = $config['username'];
        $mail->Password = $config['password'];
        $mail->SMTPSecure = $config['secure'] ?? PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = (int)($config['port'] ?? 587);
        $mail->CharSet = 'UTF-8';
        $mail->setFrom($config['from_email'], $config['from_name'] ?? 'ReWeb');
        $mail->addAddress($destinatario);
        $baseUrl = rtrim((string)($config['base_url'] ?? ''), '/');
        if ($baseUrl === '') {
            throw new RuntimeException('Configure base_url em Cadastro/configuracao-email.php.');
        }
        $url = $baseUrl . '/Cadastro/redefinir-senha.php?token=' . rawurlencode($token);
        $mail->isHTML(true);
        $mail->Subject = 'Recuperação de senha - ReWeb';
        $mail->Body = '<p>Recebemos um pedido para redefinir a senha da sua conta.</p><p><a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">Criar nova senha</a></p><p>O link expira em 30 minutos e só pode ser usado uma vez. Se você não pediu a recuperação, ignore este e-mail.</p>';
        $mail->AltBody = "Acesse este link para criar uma nova senha (válido por 30 minutos):\n" . $url;
        $mail->send();
        return true;
    } catch (Throwable $e) {
        error_log('Recuperação ReWeb: falha ao enviar e-mail: ' . $e->getMessage());
        return false;
    }
}
