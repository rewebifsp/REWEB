const formSolicitacao = document.getElementById('formSolicitarCodigo');
const formRedefinicao = document.getElementById('formRedefinirSenha');

async function enviarFormulario(form, status) {
    const botao = form.querySelector('button[type="submit"]');
    botao.disabled = true;
    status.textContent = 'Processando...';
    try {
        const resposta = await fetch(form.action, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
        const dados = await resposta.json();
        status.textContent = dados.mensagem || 'Não foi possível concluir a solicitação.';
        status.classList.toggle('mensagem-sucesso', Boolean(dados.ok));
        status.classList.toggle('erro-senha', !dados.ok);
        if (dados.ok && formRedefinicao === form) form.hidden = true;
    } catch (erro) {
        status.textContent = 'Não foi possível conectar ao servidor. Tente novamente.';
        status.classList.add('erro-senha');
    } finally {
        botao.disabled = false;
    }
}

if (formSolicitacao) {
    formSolicitacao.addEventListener('submit', (evento) => {
        evento.preventDefault();
        enviarFormulario(formSolicitacao, document.getElementById('statusSolicitacao'));
    });
}

if (formRedefinicao) {
    const senha = document.getElementById('novaSenha');
    const confirmar = document.getElementById('confirmarSenha');
    const erro = document.getElementById('erroSenha');
    formRedefinicao.addEventListener('submit', (evento) => {
        evento.preventDefault();
        if (senha.value !== confirmar.value) {
            erro.hidden = false;
            confirmar.focus();
            return;
        }
        erro.hidden = true;
        enviarFormulario(formRedefinicao, document.getElementById('statusRedefinicao'));
    });
    confirmar.addEventListener('input', () => { erro.hidden = true; });
}
