<?php
// Copie para configuracao-email.php e preencha com os dados SMTP da conta remetente.
return [
    'host' => 'smtp.example.com',
    'username' => 'seu-email@example.com',
    'password' => 'senha-de-aplicativo-smtp',
    'port' => 587,
    'secure' => PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS,
    'from_email' => 'seu-email@example.com',
    'from_name' => "ReWeb - Corisco's Paper",
    // Ajuste para a pasta do projeto dentro de htdocs.
    'base_url' => 'http://localhost/REWEB_2.5',
];