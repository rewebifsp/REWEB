-- ============================================================
-- BANCO DO SITE CORISCO'S PAPER (REWEB) - versão 2.9
--
-- Como usar: rodar este arquivo INTEIRO no phpMyAdmin (aba SQL) ou no Workbench.
-- Pode rodar de novo quando quiser: ele apaga tudo e cria do zero.
--
-- Ordem do arquivo (cada parte depende só das anteriores):
--   1) Tabelas (com PK, FK, CHECK e UNIQUE)
--   2) Views
--   3) Funções e procedures
--   4) Triggers
--   5) Dados (conta de ADM + dados de exemplo)
--   6) Consultas documentadas e demonstrações (transação e triggers)
-- ============================================================

CREATE DATABASE IF NOT EXISTS test DEFAULT CHARACTER SET utf8mb4;
USE test;

-- Apaga o que já existe. A ordem importa: primeiro o que depende dos outros
DROP VIEW IF EXISTS vw_relatorio_vendas_mensal;
DROP VIEW IF EXISTS vw_encomendas_painel;
DROP VIEW IF EXISTS vw_produtos_loja;
DROP VIEW IF EXISTS vw_produtos_disponiveis;
DROP VIEW IF EXISTS vw_clientes_seguro;
DROP VIEW IF EXISTS vw_administradores_seguro;

DROP TABLE IF EXISTS log_pedidos;
DROP TABLE IF EXISTS reweb_tokens_recuperacao;
DROP TABLE IF EXISTS reweb_recuperacao_limites;
DROP TABLE IF EXISTS feedbacks;
DROP TABLE IF EXISTS historico;
DROP TABLE IF EXISTS itens_pedido;
DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS carrinho;
DROP TABLE IF EXISTS favoritos;
DROP TABLE IF EXISTS produtos;
DROP TABLE IF EXISTS topicos;
DROP TABLE IF EXISTS login;
DROP TABLE IF EXISTS administradores;


-- ============================================================
-- 1) TABELAS
-- Padrão de nomes das restrições:
--   pk_tabela, fk_tabela_coluna, uq_tabela_coluna, ck_tabela_regra
-- ============================================================

-- ------------------------------------------------------------
-- LOGIN: as contas dos clientes
-- E-mail e telefone não podem repetir (dá para entrar no site com qualquer um dos dois)
-- ------------------------------------------------------------
CREATE TABLE login (
  id INT NOT NULL AUTO_INCREMENT,
  telefone VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  senha VARCHAR(255) NOT NULL,
  data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT pk_login PRIMARY KEY (id),
  CONSTRAINT uq_login_email UNIQUE (email),
  CONSTRAINT uq_login_telefone UNIQUE (telefone),
  CONSTRAINT ck_login_email CHECK (email LIKE '%_@_%')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- TOPICOS: as categorias (Brindes, Topper, Papel arroz...)
-- ------------------------------------------------------------
CREATE TABLE topicos (
  id INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  CONSTRAINT pk_topicos PRIMARY KEY (id),
  CONSTRAINT uq_topicos_nome UNIQUE (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- PRODUTOS: o que a Júlia vende
-- tipo: 'encomenda' (feito sob pedido) ou 'pronta_entrega' (já está pronto)
-- estoque: só para pronta entrega (encomenda fica NULL). 0 = esgotado, some da loja
-- ------------------------------------------------------------
CREATE TABLE produtos (
  id INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(150) NOT NULL,
  tema VARCHAR(100),
  preco DECIMAL(10,2) NOT NULL,
  especificacoes TEXT,
  id_topico INT,
  tipo VARCHAR(20) NOT NULL DEFAULT 'encomenda',
  estoque INT NULL,
  cores_disponiveis VARCHAR(255),
  foto1 VARCHAR(255),
  foto2 VARCHAR(255),
  foto3 VARCHAR(255),
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  CONSTRAINT pk_produtos PRIMARY KEY (id),
  CONSTRAINT fk_produtos_id_topico FOREIGN KEY (id_topico) REFERENCES topicos(id) ON DELETE SET NULL,
  CONSTRAINT ck_produtos_preco CHECK (preco >= 0),
  CONSTRAINT ck_produtos_tipo CHECK (tipo IN ('encomenda', 'pronta_entrega')),
  CONSTRAINT ck_produtos_estoque CHECK (estoque IS NULL OR estoque >= 0),
  CONSTRAINT ck_produtos_estoque_tipo CHECK (tipo = 'pronta_entrega' OR estoque IS NULL),
  CONSTRAINT ck_produtos_ativo CHECK (ativo IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- FAVORITOS: só quem tem conta favorita (um favorito por produto)
-- Tabela de junção N:N entre login e produtos
-- ------------------------------------------------------------
CREATE TABLE favoritos (
  id INT NOT NULL AUTO_INCREMENT,
  id_usuario INT NOT NULL,
  id_produto INT NOT NULL,
  data_favorito DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT pk_favoritos PRIMARY KEY (id),
  CONSTRAINT uq_favoritos_usuario_produto UNIQUE (id_usuario, id_produto),
  CONSTRAINT fk_favoritos_id_usuario FOREIGN KEY (id_usuario) REFERENCES login(id) ON DELETE CASCADE,
  CONSTRAINT fk_favoritos_id_produto FOREIGN KEY (id_produto) REFERENCES produtos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- CARRINHO: reserva para o futuro (ainda NÃO é usada; o carrinho fica na sessão do navegador)
-- ------------------------------------------------------------
CREATE TABLE carrinho (
  id INT NOT NULL AUTO_INCREMENT,
  id_usuario INT NOT NULL,
  id_produto INT NOT NULL,
  quantidade INT NOT NULL DEFAULT 1,
  tamanho VARCHAR(100),
  idade VARCHAR(20),
  nome_escrito VARCHAR(100),
  tema VARCHAR(100),
  cor VARCHAR(50),
  observacoes VARCHAR(255),
  arte VARCHAR(255),
  CONSTRAINT pk_carrinho PRIMARY KEY (id),
  CONSTRAINT fk_carrinho_id_usuario FOREIGN KEY (id_usuario) REFERENCES login(id) ON DELETE CASCADE,
  CONSTRAINT fk_carrinho_id_produto FOREIGN KEY (id_produto) REFERENCES produtos(id) ON DELETE CASCADE,
  CONSTRAINT ck_carrinho_quantidade CHECK (quantidade > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- PEDIDOS: um pedido por compra
-- id_usuario fica vazio (NULL) quando a encomenda foi anotada pela administração
-- criado_por: 'site' (o cliente fez) ou 'adm' (a Júlia anotou na mão)
-- forma_entrega: 'retirada' ou 'entrega'
-- pago / pronto / buscou: 0 = não, 1 = sim
-- ------------------------------------------------------------
CREATE TABLE pedidos (
  id INT NOT NULL AUTO_INCREMENT,
  id_usuario INT,
  criado_por VARCHAR(10) NOT NULL DEFAULT 'site',
  cliente VARCHAR(150) NOT NULL,
  telefone VARCHAR(100),
  email VARCHAR(100),
  forma_entrega VARCHAR(20) NOT NULL DEFAULT 'retirada',
  endereco VARCHAR(255),
  data_pedido DATETIME DEFAULT CURRENT_TIMESTAMP,
  prazo DATE,
  pago TINYINT(1) NOT NULL DEFAULT 0,
  pronto TINYINT(1) NOT NULL DEFAULT 0,
  buscou TINYINT(1) NOT NULL DEFAULT 0,
  observacoes VARCHAR(255),
  status VARCHAR(40) NULL, -- status escolhido no painel (vazio = calculado pelas caixinhas Pagou/Pronto/Buscou)
  CONSTRAINT pk_pedidos PRIMARY KEY (id),
  CONSTRAINT fk_pedidos_id_usuario FOREIGN KEY (id_usuario) REFERENCES login(id) ON DELETE SET NULL,
  CONSTRAINT ck_pedidos_criado_por CHECK (criado_por IN ('site', 'adm')),
  CONSTRAINT ck_pedidos_forma_entrega CHECK (forma_entrega IN ('retirada', 'entrega')),
  CONSTRAINT ck_pedidos_pago CHECK (pago IN (0, 1)),
  CONSTRAINT ck_pedidos_pronto CHECK (pronto IN (0, 1)),
  CONSTRAINT ck_pedidos_buscou CHECK (buscou IN (0, 1)),
  CONSTRAINT ck_pedidos_prazo CHECK (prazo IS NULL OR prazo >= DATE(data_pedido))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- ITENS_PEDIDO: cada produto dentro de um pedido
-- O nome e o valor são copiados para cá, assim o pedido não muda se o produto mudar
-- precisa_arte: 1 quando o cliente ainda precisa enviar a arte
-- ------------------------------------------------------------
CREATE TABLE itens_pedido (
  id INT NOT NULL AUTO_INCREMENT,
  id_pedido INT NOT NULL,
  id_produto INT,
  produto VARCHAR(150) NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  quantidade INT NOT NULL DEFAULT 1,
  tema VARCHAR(100),
  tamanho VARCHAR(100),
  idade VARCHAR(20),
  nome_escrito VARCHAR(100),
  cor VARCHAR(50),
  observacoes VARCHAR(255),
  arte VARCHAR(255),
  precisa_arte TINYINT(1) NOT NULL DEFAULT 0,
  CONSTRAINT pk_itens_pedido PRIMARY KEY (id),
  CONSTRAINT fk_itens_pedido_id_pedido FOREIGN KEY (id_pedido) REFERENCES pedidos(id) ON DELETE CASCADE,
  CONSTRAINT fk_itens_pedido_id_produto FOREIGN KEY (id_produto) REFERENCES produtos(id) ON DELETE SET NULL,
  CONSTRAINT ck_itens_pedido_valor CHECK (valor >= 0),
  CONSTRAINT ck_itens_pedido_quantidade CHECK (quantidade > 0),
  CONSTRAINT ck_itens_pedido_precisa_arte CHECK (precisa_arte IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- HISTORICO: a caixinha amarela do painel ("Júlia adicionou encomenda...")
-- ------------------------------------------------------------
CREATE TABLE historico (
  id INT NOT NULL AUTO_INCREMENT,
  descricao VARCHAR(255) NOT NULL,
  data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
  id_pedido INT,
  autor VARCHAR(100) NULL,   -- nome do administrador (vazio quando foi o próprio cliente)
  CONSTRAINT pk_historico PRIMARY KEY (id),
  CONSTRAINT fk_historico_id_pedido FOREIGN KEY (id_pedido) REFERENCES pedidos(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- FEEDBACKS: estrelas e texto enviados pelo rodapé do site
-- ------------------------------------------------------------
CREATE TABLE feedbacks (
  id INT NOT NULL AUTO_INCREMENT,
  id_usuario INT NULL,                  -- quem enviou, se estava logado (vazio = visitante)
  estrelas TINYINT NOT NULL,
  mensagem VARCHAR(500),
  data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT pk_feedbacks PRIMARY KEY (id),
  CONSTRAINT fk_feedbacks_id_usuario FOREIGN KEY (id_usuario) REFERENCES login(id) ON DELETE SET NULL,
  CONSTRAINT ck_feedbacks_estrelas CHECK (estrelas BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- RECUPERAÇÃO DE SENHA: tokens enviados por e-mail e limite de pedidos por hora
-- ------------------------------------------------------------
CREATE TABLE reweb_tokens_recuperacao (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  login_id INT NOT NULL,
  token_hash CHAR(64) NOT NULL,
  criado_em DATETIME NOT NULL,
  expira_em DATETIME NOT NULL,
  usado_em DATETIME NULL DEFAULT NULL,
  tentativas TINYINT UNSIGNED NOT NULL DEFAULT 0,
  CONSTRAINT pk_reweb_tokens_recuperacao PRIMARY KEY (id),
  CONSTRAINT uq_reweb_tokens_recuperacao_token_hash UNIQUE (token_hash),
  KEY ix_reweb_token_login (login_id, usado_em),
  KEY ix_reweb_token_expira (expira_em),
  CONSTRAINT fk_reweb_tokens_recuperacao_login_id FOREIGN KEY (login_id) REFERENCES login(id) ON DELETE CASCADE,
  CONSTRAINT ck_reweb_tokens_recuperacao_expira CHECK (expira_em > criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE reweb_recuperacao_limites (
  escopo_hash CHAR(64) NOT NULL,
  inicio_janela DATETIME NOT NULL,
  quantidade SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  CONSTRAINT pk_reweb_recuperacao_limites PRIMARY KEY (escopo_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- ADMINISTRADORES: quem tem acesso ao painel (senhas CRIPTOGRAFADAS)
-- ------------------------------------------------------------
CREATE TABLE administradores (
  id INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  senha VARCHAR(255) NOT NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,   -- 1 = tem acesso, 0 = desativado
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT pk_administradores PRIMARY KEY (id),
  CONSTRAINT uq_administradores_email UNIQUE (email),
  CONSTRAINT ck_administradores_ativo CHECK (ativo IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- LOG_PEDIDOS: auditoria (preenchida pelos triggers, ninguém grava aqui na mão)
-- Uma linha para cada campo alterado de um pedido, ou uma linha quando o pedido é excluído.
-- id_pedido NÃO tem FK de propósito: o log precisa continuar mesmo depois que o pedido é apagado.
-- ------------------------------------------------------------
CREATE TABLE log_pedidos (
  id INT NOT NULL AUTO_INCREMENT,
  id_pedido INT NOT NULL,
  acao VARCHAR(10) NOT NULL,
  campo VARCHAR(40) NOT NULL,
  valor_antigo VARCHAR(255),
  valor_novo VARCHAR(255),
  usuario VARCHAR(100) NOT NULL,
  data_hora DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT pk_log_pedidos PRIMARY KEY (id),
  KEY ix_log_pedidos_id_pedido (id_pedido),
  CONSTRAINT ck_log_pedidos_acao CHECK (acao IN ('ALTERACAO', 'EXCLUSAO'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ============================================================
-- 2) VIEWS
-- ============================================================

-- ------------------------------------------------------------
-- 2.1) vw_relatorio_vendas_mensal  (VIEW DE RELATÓRIO - agregações)
-- Cenário de uso: relatório gerencial da Júlia com o movimento de cada mês:
-- quantos pedidos entraram, quantas unidades, o faturamento total e o quanto já foi pago.
-- Exemplo: SELECT * FROM vw_relatorio_vendas_mensal WHERE mes >= '2026-10';
-- ------------------------------------------------------------
CREATE VIEW vw_relatorio_vendas_mensal AS
SELECT DATE_FORMAT(p.data_pedido, '%Y-%m') AS mes,
       COUNT(DISTINCT p.id) AS total_pedidos,
       SUM(i.quantidade) AS unidades_vendidas,
       SUM(i.valor * i.quantidade) AS faturamento,
       SUM(CASE WHEN p.pago = 1 THEN i.valor * i.quantidade ELSE 0 END) AS faturamento_pago,
       ROUND(SUM(i.valor * i.quantidade) / COUNT(DISTINCT p.id), 2) AS ticket_medio
FROM pedidos p
JOIN itens_pedido i ON i.id_pedido = p.id
GROUP BY DATE_FORMAT(p.data_pedido, '%Y-%m');


-- ------------------------------------------------------------
-- 2.2) vw_encomendas_painel  (VIEW DE CONVENIÊNCIA - simplifica joins)
-- Cenário de uso: a tabela de encomendas do painel administrativo.
-- Junta itens_pedido + pedidos + login (para pegar o telefone da conta quando o pedido não tem)
-- e já traz o total da linha. Usada em Adiministracao/buscar-encomendas.php.
-- Exemplo: SELECT * FROM vw_encomendas_painel WHERE pago = 0;
-- ------------------------------------------------------------
CREATE VIEW vw_encomendas_painel AS
SELECT i.id AS id_item, i.id_pedido, i.produto, i.valor, i.quantidade,
       i.valor * i.quantidade AS total,
       i.tema, i.tamanho, i.idade, i.nome_escrito, i.cor, i.observacoes AS obs_item,
       i.precisa_arte, i.arte,
       p.cliente, COALESCE(NULLIF(p.telefone, ''), l.telefone) AS telefone,
       p.email, p.endereco, p.forma_entrega, p.criado_por,
       p.id_usuario, p.data_pedido, p.prazo, p.pago, p.pronto, p.buscou, p.status,
       p.observacoes
FROM itens_pedido i
JOIN pedidos p ON p.id = i.id_pedido
LEFT JOIN login l ON l.id = p.id_usuario;


-- ------------------------------------------------------------
-- 2.3) vw_produtos_loja  (VIEW PARAMETRIZÁVEL / GENÉRICA)
-- Deixa prontos o join com a categoria e os campos principais, e só aplica a regra
-- fixa da loja (produto ativo e, se for pronta entrega, com estoque).
-- Os outros filtros (categoria, tipo, busca, ordem) ficam para quem consulta.
-- Cenário de uso: telas da loja (início, categorias, pesquisa, pronta entrega, favoritos).
-- Exemplos:
--   SELECT * FROM vw_produtos_loja WHERE categoria = 'Topper' ORDER BY id DESC;
--   SELECT * FROM vw_produtos_loja WHERE tipo = 'pronta_entrega';
--   SELECT * FROM vw_produtos_loja WHERE nome LIKE '%caneca%' OR tema LIKE '%caneca%';
-- ------------------------------------------------------------
CREATE VIEW vw_produtos_loja AS
SELECT p.id, p.nome, p.tema, p.preco, p.especificacoes, p.tipo, p.estoque,
       p.cores_disponiveis, p.foto1, p.foto2, p.foto3,
       p.id_topico, t.nome AS categoria
FROM produtos p
LEFT JOIN topicos t ON t.id = p.id_topico
WHERE p.ativo = 1
  AND (p.tipo <> 'pronta_entrega' OR p.estoque > 0);


-- ------------------------------------------------------------
-- 2.4) vw_clientes_seguro e vw_administradores_seguro  (VIEWS DE SEGURANÇA)
-- Escondem a coluna senha (hash). Quem só precisa listar contas usa a view, não a tabela.
-- Cenário de uso: lista de administradores do painel (buscar-encomendas.php) e
-- relatórios de clientes, sem expor senhas.
-- Exemplo: SELECT * FROM vw_administradores_seguro WHERE ativo = 1;
-- ------------------------------------------------------------
CREATE VIEW vw_clientes_seguro AS
SELECT l.id, l.email, l.telefone, l.data_cadastro,
       (SELECT COUNT(*) FROM pedidos p WHERE p.id_usuario = l.id) AS total_pedidos
FROM login l;

CREATE VIEW vw_administradores_seguro AS
SELECT id, nome, email, ativo, criado_em
FROM administradores;


-- ============================================================
-- 3) FUNÇÕES E PROCEDURES
-- Erros de regra de negócio usam SIGNAL SQLSTATE '45000' com uma mensagem em português.
-- ============================================================
DELIMITER $$

-- ------------------------------------------------------------
-- 3.1) fn_total_pedido  (FUNÇÃO DERIVADA - cálculo de valor)
-- Pré-condição: p_pedido é o id de um pedido (se não existir, devolve 0).
-- Pós-condição: devolve a soma de valor * quantidade dos itens. Não altera nada.
-- Exemplo: SELECT fn_total_pedido(5);
-- ------------------------------------------------------------
DROP FUNCTION IF EXISTS fn_total_pedido$$
CREATE FUNCTION fn_total_pedido(p_pedido INT)
RETURNS DECIMAL(10,2)
READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(10,2);

    SELECT IFNULL(SUM(valor * quantidade), 0) INTO v_total
    FROM itens_pedido
    WHERE id_pedido = p_pedido;

    RETURN v_total;
END$$


-- ------------------------------------------------------------
-- 3.2) fn_status_pedido  (FUNÇÃO DERIVADA - situação do pedido)
-- Mesma regra de statusDoPedido() do Includes/funcoes.php:
--   1) vale o status escolhido no painel; 2) pedido do site sem nada marcado = "Verificar comprovante";
--   3) senão é calculado pelas caixinhas Pagou / Pronto / Buscou.
-- Pré-condição: p_pedido é o id de um pedido (se não existir, devolve NULL).
-- Pós-condição: devolve o texto do status. Não altera nada.
-- Exemplo: SELECT id, cliente, fn_status_pedido(id) AS situacao FROM pedidos;
-- ------------------------------------------------------------
DROP FUNCTION IF EXISTS fn_status_pedido$$
CREATE FUNCTION fn_status_pedido(p_pedido INT)
RETURNS VARCHAR(40)
READS SQL DATA
BEGIN
    DECLARE v_status VARCHAR(40);
    DECLARE v_criado_por VARCHAR(10);
    DECLARE v_forma VARCHAR(20);
    DECLARE v_pago INT;
    DECLARE v_pronto INT;
    DECLARE v_buscou INT;

    SELECT status, criado_por, forma_entrega, pago, pronto, buscou
    INTO v_status, v_criado_por, v_forma, v_pago, v_pronto, v_buscou
    FROM pedidos
    WHERE id = p_pedido;

    IF v_criado_por IS NULL THEN
        RETURN NULL; -- pedido não existe
    END IF;
    IF v_status IS NOT NULL AND v_status <> '' THEN
        RETURN v_status;
    END IF;
    IF v_criado_por = 'site' AND v_pago = 0 AND v_pronto = 0 AND v_buscou = 0 THEN
        RETURN 'Verificar comprovante';
    END IF;
    IF v_buscou = 1 THEN
        IF v_forma = 'entrega' THEN RETURN 'Enviado'; END IF;
        RETURN 'Retirado';
    END IF;
    IF v_pronto = 1 THEN
        IF v_forma = 'entrega' THEN RETURN 'Pronto para envio'; END IF;
        RETURN 'Pronto para retirada';
    END IF;
    IF v_pago = 1 THEN
        RETURN 'Em processamento';
    END IF;
    RETURN 'Aguardando pagamento';
END$$


-- ------------------------------------------------------------
-- 3.3) sp_registrar_historico  (procedure de apoio)
-- Pré-condição: p_descricao não pode ser vazia. p_pedido e p_autor podem ser NULL.
-- Pós-condição: uma linha nova na tabela historico.
-- Exemplo: CALL sp_registrar_historico('Maria solicitou encomenda', 5, NULL);
-- ------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_registrar_historico$$
CREATE PROCEDURE sp_registrar_historico(IN p_descricao VARCHAR(255),
                                        IN p_pedido INT,
                                        IN p_autor VARCHAR(100))
BEGIN
    IF p_descricao IS NULL OR TRIM(p_descricao) = '' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A descrição do histórico não pode ser vazia.';
    END IF;

    INSERT INTO historico (descricao, id_pedido, autor)
    VALUES (p_descricao, p_pedido, p_autor);
END$$


-- ------------------------------------------------------------
-- 3.4) sp_inserir_encomenda  (PROCEDURE DE CRUD TRANSACIONAL)
-- Grava uma encomenda anotada pela administração: pedido + item + histórico,
-- tudo na MESMA transação. Se qualquer parte falhar, o ROLLBACK desfaz tudo.
-- Usada em Adiministracao/acoes.php (ação nova_encomenda).
-- Pré-condições:
--   cliente e produto preenchidos; quantidade >= 1; valor >= 0;
--   prazo informado e não anterior à data da encomenda.
-- Pós-condições:
--   sucesso: 1 linha em pedidos (criado_por = 'adm'), 1 em itens_pedido, 1 em historico,
--            e p_id_pedido recebe o número do pedido novo;
--   erro:    nada é gravado (rollback) e o erro é repassado para quem chamou.
-- Exemplo:
--   CALL sp_inserir_encomenda('Carol Barros', '99620-9925', NULL, NULL,
--        '2026-11-25 00:00:00', '2026-11-30', 1, 0, NULL,
--        'Topper', 22.00, 1, 'Batman', NULL, 1, 'Júlia', @novo_id);
--   SELECT @novo_id;
-- ------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_inserir_encomenda$$
CREATE PROCEDURE sp_inserir_encomenda(IN p_cliente VARCHAR(150),
                                      IN p_telefone VARCHAR(100),
                                      IN p_email VARCHAR(100),
                                      IN p_endereco VARCHAR(255),
                                      IN p_data DATETIME,
                                      IN p_prazo DATE,
                                      IN p_pago TINYINT,
                                      IN p_buscou TINYINT,
                                      IN p_observacoes VARCHAR(255),
                                      IN p_produto VARCHAR(150),
                                      IN p_valor DECIMAL(10,2),
                                      IN p_quantidade INT,
                                      IN p_tema VARCHAR(100),
                                      IN p_arte VARCHAR(255),
                                      IN p_precisa_arte TINYINT,
                                      IN p_autor VARCHAR(100),
                                      OUT p_id_pedido INT)
BEGIN
    DECLARE v_forma VARCHAR(20);

    -- Qualquer erro dentro da transação: desfaz tudo e repassa o erro
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_id_pedido = NULL;
        RESIGNAL;
    END;

    -- Validações (pré-condições)
    IF p_cliente IS NULL OR TRIM(p_cliente) = '' OR p_produto IS NULL OR TRIM(p_produto) = '' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Preencha o cliente e o produto.';
    END IF;
    IF p_quantidade IS NULL OR p_quantidade < 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A quantidade precisa ser 1 ou mais.';
    END IF;
    IF p_valor IS NULL OR p_valor < 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'O valor não pode ser negativo.';
    END IF;
    IF p_prazo IS NULL OR p_prazo < DATE(p_data) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'O prazo não pode ser anterior à data da encomenda.';
    END IF;

    -- Com endereço é entrega, sem endereço é retirada
    IF p_endereco IS NULL OR TRIM(p_endereco) = '' THEN
        SET v_forma = 'retirada';
    ELSE
        SET v_forma = 'entrega';
    END IF;

    START TRANSACTION;

    INSERT INTO pedidos (criado_por, cliente, telefone, email, forma_entrega, endereco,
                         data_pedido, prazo, pago, buscou, observacoes)
    VALUES ('adm', p_cliente, p_telefone, p_email, v_forma, p_endereco,
            p_data, p_prazo, p_pago, p_buscou, p_observacoes);

    SET p_id_pedido = LAST_INSERT_ID();

    INSERT INTO itens_pedido (id_pedido, produto, valor, quantidade, tema, arte, precisa_arte)
    VALUES (p_id_pedido, p_produto, p_valor, p_quantidade, p_tema, p_arte, p_precisa_arte);

    CALL sp_registrar_historico(CONCAT('Administração adicionou encomenda de ', p_cliente),
                                p_id_pedido, p_autor);

    COMMIT;
END$$


-- ------------------------------------------------------------
-- 3.5) sp_baixar_estoque  (ROTINA DE NEGÓCIO - regra de consistência do estoque)
-- Confere se o produto pode ser vendido e dá baixa no estoque dos produtos de pronta entrega.
-- Usa SELECT ... FOR UPDATE: trava a linha do produto até o fim da transação de quem chamou,
-- assim duas compras ao mesmo tempo não vendem a mesma última unidade.
-- Deve ser chamada DENTRO de uma transação (a finalização da compra em Cobranca/cobranca.php).
-- Pré-condições: produto existe e está ativo; quantidade >= 1;
--                se for pronta entrega, estoque >= quantidade.
-- Pós-condições: pronta entrega -> estoque diminui a quantidade; encomenda -> nada muda.
--                Se alguma regra falhar, nada muda e o erro sobe para quem chamou.
-- Exemplo: CALL sp_baixar_estoque(3, 2);
-- ------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_baixar_estoque$$
CREATE PROCEDURE sp_baixar_estoque(IN p_produto INT, IN p_quantidade INT)
BEGIN
    DECLARE v_tipo VARCHAR(20);
    DECLARE v_estoque INT;
    DECLARE v_ativo INT;

    IF p_quantidade IS NULL OR p_quantidade < 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Quantidade inválida.';
    END IF;

    SELECT tipo, estoque, ativo INTO v_tipo, v_estoque, v_ativo
    FROM produtos
    WHERE id = p_produto
    FOR UPDATE;

    IF v_tipo IS NULL OR v_ativo = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Produto indisponível.';
    END IF;

    IF v_tipo = 'pronta_entrega' THEN
        IF v_estoque < p_quantidade THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Estoque insuficiente.';
        END IF;

        UPDATE produtos
        SET estoque = estoque - p_quantidade
        WHERE id = p_produto;
    END IF;
END$$


-- ------------------------------------------------------------
-- 3.6) sp_relatorio_vendas  (ROTINA RELATORIAL - tabela temporária)
-- Monta o ranking de produtos vendidos num período em uma tabela temporária
-- (tmp_relatorio_vendas) e devolve o resultado ordenado pela receita.
-- A tabela temporária só existe na conexão de quem chamou e some quando ela fecha.
-- Pré-condições: p_inicio e p_fim preenchidos e p_inicio <= p_fim.
-- Pós-condições: tmp_relatorio_vendas criada/recriada com uma linha por produto. Não altera tabelas.
-- Exemplo: CALL sp_relatorio_vendas('2026-10-01', '2026-10-31');
-- ------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_relatorio_vendas$$
CREATE PROCEDURE sp_relatorio_vendas(IN p_inicio DATE, IN p_fim DATE)
BEGIN
    IF p_inicio IS NULL OR p_fim IS NULL OR p_inicio > p_fim THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Período inválido: a data inicial deve ser menor ou igual à final.';
    END IF;

    DROP TEMPORARY TABLE IF EXISTS tmp_relatorio_vendas;

    CREATE TEMPORARY TABLE tmp_relatorio_vendas (
        produto VARCHAR(150) NOT NULL,
        pedidos INT NOT NULL,
        unidades INT NOT NULL,
        receita DECIMAL(12,2) NOT NULL,
        receita_paga DECIMAL(12,2) NOT NULL
    );

    INSERT INTO tmp_relatorio_vendas (produto, pedidos, unidades, receita, receita_paga)
    SELECT i.produto,
           COUNT(DISTINCT p.id),
           SUM(i.quantidade),
           SUM(i.valor * i.quantidade),
           SUM(CASE WHEN p.pago = 1 THEN i.valor * i.quantidade ELSE 0 END)
    FROM itens_pedido i
    JOIN pedidos p ON p.id = i.id_pedido
    WHERE p.data_pedido >= p_inicio
      AND p.data_pedido < DATE_ADD(p_fim, INTERVAL 1 DAY)
    GROUP BY i.produto;

    SELECT produto, pedidos, unidades, receita, receita_paga,
           ROUND(receita / (SELECT IFNULL(NULLIF(SUM(receita), 0), 1) FROM tmp_relatorio_vendas) * 100, 1) AS percentual
    FROM tmp_relatorio_vendas
    ORDER BY receita DESC;
END$$

DELIMITER ;


-- ============================================================
-- 4) TRIGGERS
-- ============================================================
DELIMITER $$

-- ------------------------------------------------------------
-- 4.1) trg_produtos_impedir_exclusao  (INTEGRIDADE / REGRA DE NEGÓCIO)
-- Um produto que já foi vendido não pode ser excluído: o certo é desativá-lo (ativo = 0),
-- assim ele some da loja mas continua ligado aos pedidos antigos.
-- Exemplo de ocorrência: DELETE FROM produtos WHERE id = 1;
--   -> ERRO 1644: Produto já vendido não pode ser excluído. Desative o produto no painel.
-- ------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_produtos_impedir_exclusao$$
CREATE TRIGGER trg_produtos_impedir_exclusao
BEFORE DELETE ON produtos
FOR EACH ROW
BEGIN
    IF EXISTS (SELECT 1 FROM itens_pedido WHERE id_produto = OLD.id) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Produto já vendido não pode ser excluído. Desative o produto no painel.';
    END IF;
END$$


-- ------------------------------------------------------------
-- 4.2) trg_pedidos_auditar_alteracao  (AUDITORIA)
-- Grava em log_pedidos cada campo importante que mudou num pedido (valor antigo e novo).
-- O painel informa quem está logado com SET @usuario_painel = 'nome' (Adiministracao/acoes.php);
-- fora do painel fica o usuário do banco.
-- Exemplo de ocorrência:
--   UPDATE pedidos SET pago = 1 WHERE id = 10;
--   SELECT * FROM log_pedidos WHERE id_pedido = 10;
--   -> ALTERACAO | pago | 0 | 1 | Júlia | 2026-11-23 10:00:00
-- ------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_pedidos_auditar_alteracao$$
CREATE TRIGGER trg_pedidos_auditar_alteracao
AFTER UPDATE ON pedidos
FOR EACH ROW
BEGIN
    DECLARE v_usuario VARCHAR(100);
    SET v_usuario = COALESCE(@usuario_painel, CURRENT_USER());

    IF NOT (OLD.cliente <=> NEW.cliente) THEN
        INSERT INTO log_pedidos (id_pedido, acao, campo, valor_antigo, valor_novo, usuario)
        VALUES (NEW.id, 'ALTERACAO', 'cliente', OLD.cliente, NEW.cliente, v_usuario);
    END IF;
    IF NOT (OLD.telefone <=> NEW.telefone) THEN
        INSERT INTO log_pedidos (id_pedido, acao, campo, valor_antigo, valor_novo, usuario)
        VALUES (NEW.id, 'ALTERACAO', 'telefone', OLD.telefone, NEW.telefone, v_usuario);
    END IF;
    IF NOT (OLD.forma_entrega <=> NEW.forma_entrega) THEN
        INSERT INTO log_pedidos (id_pedido, acao, campo, valor_antigo, valor_novo, usuario)
        VALUES (NEW.id, 'ALTERACAO', 'forma_entrega', OLD.forma_entrega, NEW.forma_entrega, v_usuario);
    END IF;
    IF NOT (OLD.endereco <=> NEW.endereco) THEN
        INSERT INTO log_pedidos (id_pedido, acao, campo, valor_antigo, valor_novo, usuario)
        VALUES (NEW.id, 'ALTERACAO', 'endereco', OLD.endereco, NEW.endereco, v_usuario);
    END IF;
    IF NOT (OLD.data_pedido <=> NEW.data_pedido) THEN
        INSERT INTO log_pedidos (id_pedido, acao, campo, valor_antigo, valor_novo, usuario)
        VALUES (NEW.id, 'ALTERACAO', 'data_pedido', OLD.data_pedido, NEW.data_pedido, v_usuario);
    END IF;
    IF NOT (OLD.prazo <=> NEW.prazo) THEN
        INSERT INTO log_pedidos (id_pedido, acao, campo, valor_antigo, valor_novo, usuario)
        VALUES (NEW.id, 'ALTERACAO', 'prazo', OLD.prazo, NEW.prazo, v_usuario);
    END IF;
    IF NOT (OLD.pago <=> NEW.pago) THEN
        INSERT INTO log_pedidos (id_pedido, acao, campo, valor_antigo, valor_novo, usuario)
        VALUES (NEW.id, 'ALTERACAO', 'pago', OLD.pago, NEW.pago, v_usuario);
    END IF;
    IF NOT (OLD.pronto <=> NEW.pronto) THEN
        INSERT INTO log_pedidos (id_pedido, acao, campo, valor_antigo, valor_novo, usuario)
        VALUES (NEW.id, 'ALTERACAO', 'pronto', OLD.pronto, NEW.pronto, v_usuario);
    END IF;
    IF NOT (OLD.buscou <=> NEW.buscou) THEN
        INSERT INTO log_pedidos (id_pedido, acao, campo, valor_antigo, valor_novo, usuario)
        VALUES (NEW.id, 'ALTERACAO', 'buscou', OLD.buscou, NEW.buscou, v_usuario);
    END IF;
    IF NOT (OLD.status <=> NEW.status) THEN
        INSERT INTO log_pedidos (id_pedido, acao, campo, valor_antigo, valor_novo, usuario)
        VALUES (NEW.id, 'ALTERACAO', 'status', OLD.status, NEW.status, v_usuario);
    END IF;
END$$


-- ------------------------------------------------------------
-- 4.3) trg_pedidos_auditar_exclusao  (AUDITORIA)
-- Quando um pedido é excluído, guarda em log_pedidos um resumo do que foi apagado.
-- Exemplo de ocorrência:
--   DELETE FROM pedidos WHERE id = 10;
--   SELECT * FROM log_pedidos WHERE id_pedido = 10 AND acao = 'EXCLUSAO';
-- ------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_pedidos_auditar_exclusao$$
CREATE TRIGGER trg_pedidos_auditar_exclusao
AFTER DELETE ON pedidos
FOR EACH ROW
BEGIN
    INSERT INTO log_pedidos (id_pedido, acao, campo, valor_antigo, valor_novo, usuario)
    VALUES (OLD.id, 'EXCLUSAO', 'pedido',
            CONCAT(OLD.cliente, ' | pedido de ', DATE_FORMAT(OLD.data_pedido, '%d/%m/%Y'),
                   ' | pago: ', OLD.pago, ' | prazo: ', IFNULL(DATE_FORMAT(OLD.prazo, '%d/%m/%Y'), '-')),
            NULL,
            COALESCE(@usuario_painel, CURRENT_USER()));
END$$

DELIMITER ;


-- ============================================================
-- 5) DADOS
-- ============================================================

-- Conta de TESTE para o primeiro acesso (e-mail adm@corisco.com, senha adm123).
-- Entre com ela, crie a conta real da Júlia pelo painel e depois desative esta.
INSERT INTO administradores (nome, email, senha) VALUES
('ADM (conta de teste)', 'adm@corisco.com', '$2y$12$TyhpcAZPAXG7TqbRelVWqO/veb7ahckRvlLrU9PK6MXXZzqEr2may');


-- ------------------------------------------------------------
-- DADOS DE EXEMPLO (encomendas reais da planilha da Júlia + clientes de teste).
-- Para começar com o banco vazio, apague daqui até o fim da parte 5.
-- ------------------------------------------------------------

INSERT INTO topicos (nome) VALUES
('Sublimação'), ('Brindes'), ('Papel arroz'), ('Encadernação'), ('Topper'), ('Louças'), ('Têxtil');

-- Produtos da vitrine (fotos em imagens/produtos/). Os preços estão provisórios: conferir com a Júlia.
-- Tópicos: 2 = Brindes, 3 = Papel arroz, 5 = Topper, 6 = Louças. Todos são encomenda (pronta entrega fica vazia até a Júlia informar o estoque).
INSERT INTO produtos (nome, tema, preco, especificacoes, id_topico, tipo, estoque, cores_disponiveis, foto1, foto2, foto3) VALUES
('Topper simples Toy Story', 'Toy Story', 22.00, 'Topper simples em papel especial, acompanha o nome e a idade escolhidos.', 5, 'encomenda', NULL, NULL, 'imagens/produtos/topper-simples-toy-story.jpg', NULL, NULL),
('Flores de papel para bolo', 'Flores', 35.00, 'Flores e borboletas de papel para decorar o bolo, nas cores que você escolher.', 5, 'encomenda', NULL, 'Rosa, Dourado', 'imagens/produtos/flores.jpg', NULL, NULL),
('Caixinha dedeira', 'Masha e o Urso', 8.00, 'Caixinha de lembrancinha personalizada com o tema, o nome e a idade da festa.', 2, 'encomenda', NULL, NULL, 'imagens/produtos/caixinha-dedeira-1.jpg', 'imagens/produtos/caixinha-dedeira-2.jpg', NULL),
('Papel arroz para envelopar', 'Stitch', 17.00, 'Papel de arroz impresso com o tema escolhido para envelopar o bolo (topo e laterais).', 3, 'encomenda', NULL, NULL, 'imagens/produtos/papel-arroz-envelopar.jpg', NULL, NULL),
('Papel arroz recortado para drinks', NULL, 20.00, 'Círculos de papel de arroz recortados com a imagem escolhida, para decorar drinks.', 3, 'encomenda', NULL, NULL, 'imagens/produtos/papel-arroz-drinks.jpg', NULL, NULL),
('Caneca personalizada', 'Mulher-Maravilha', 38.00, 'Caneca personalizada com a arte que você escolher.', 6, 'encomenda', NULL, 'Rosa', 'imagens/produtos/caneca.jpg', NULL, NULL);

-- Encomendas reais da planilha da Júlia (Outubro e Novembro de 2026)
INSERT INTO pedidos (criado_por, cliente, telefone, forma_entrega, data_pedido, prazo, pago, pronto, buscou, observacoes) VALUES
('adm', 'Embolados Doceria', '98870-0323', 'retirada', '2026-10-01 09:00:00', '2026-10-01', 1, 1, 1, NULL),
('adm', 'Maria', '99342-0945', 'entrega', '2026-09-30 09:00:00', '2026-10-01', 1, 1, 1, 'Total na planilha: R$ 17,00'),
('adm', 'Carol Barros', '99620-9925', 'retirada', '2026-09-24 09:00:00', '2026-10-01', 1, 1, 1, NULL),
('adm', 'SilFér Cake', '98846-0905', 'entrega', '2026-09-30 09:00:00', '2026-10-01', 1, 1, 1, NULL),
('adm', 'SilFér Cake', '98846-0905', 'entrega', '2026-09-30 09:00:00', '2026-10-01', 1, 1, 1, NULL),
('adm', 'Maria', '99342-0945', 'entrega', '2026-09-30 09:00:00', '2026-10-01', 1, 1, 1, NULL),
('adm', 'Isabella Araujo', '99144-8652', 'entrega', '2026-10-01 09:00:00', '2026-10-01', 1, 1, 1, NULL),
('adm', 'Stella', '98311-1043', 'retirada', '2026-10-01 09:00:00', '2026-10-01', 1, 1, 1, NULL),
('adm', 'Maria Isabel', '98402-0553', 'retirada', '2026-09-30 09:00:00', '2026-10-01', 1, 1, 1, NULL),
('adm', 'Alline Moura', '98183-3026', 'retirada', '2026-09-29 09:00:00', '2026-10-01', 1, 1, 1, NULL),
('adm', 'Lila', '97156-7493', 'retirada', '2026-10-01 09:00:00', '2026-10-01', 1, 1, 1, NULL),
('adm', 'Lila', '97156-7493', 'retirada', '2026-10-01 09:00:00', '2026-10-01', 1, 1, 1, NULL),
('adm', 'Isabella Araujo', '99144-8652', 'entrega', '2026-10-01 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Camila VS', '98902-5551', 'retirada', '2026-09-28 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Jéssica', '99433-5685', 'retirada', '2026-10-01 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Julia Aveline', '99664-9900', 'entrega', '2026-10-01 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Line Càrniele', '99614-5268', 'retirada', '2026-09-30 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Line Càrniele', '99614-5268', 'retirada', '2026-09-30 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Line Càrniele', '99614-5268', 'retirada', '2026-09-30 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Naiara', '99689-8015', 'retirada', '2026-10-01 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Fernanda Sissi', '99520-7000', 'entrega', '2026-10-01 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Luizinho', '99556-1500', 'retirada', '2026-10-02 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Andréa Kuniyoshi Miss Cake', '97117-7447', 'retirada', '2026-10-02 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Milena', '99811-5262', 'retirada', '2026-10-02 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Fernanda Sissi', '99520-7000', 'entrega', '2026-10-02 09:00:00', '2026-10-02', 1, 1, 1, NULL),
('adm', 'Renato Luciano', '98382-2667', 'retirada', '2026-10-01 09:00:00', '2026-10-03', 1, 1, 1, NULL),
('adm', 'Carol La Cakerie', '99929-0076', 'entrega', '2026-10-01 09:00:00', '2026-10-03', 1, 1, 1, NULL),
('adm', 'Michelle Tagliati', '61 9303-1271', 'retirada', '2026-10-02 09:00:00', '2026-10-03', 1, 1, 1, NULL),
('adm', 'Cristiane Diniz', '99394-9695', 'entrega', '2026-10-01 09:00:00', '2026-10-03', 1, 1, 1, NULL),
('adm', 'Alex', '99227-3418', 'retirada', '2026-10-02 09:00:00', '2026-10-03', 1, 1, 1, NULL),
('adm', 'Michele Micuca', '99384-8384', 'entrega', '2026-09-25 09:00:00', '2026-10-05', 1, 1, 1, NULL),
('adm', 'Michele Micuca', '99384-8384', 'entrega', '2026-09-29 09:00:00', '2026-10-05', 1, 1, 1, NULL),
('adm', 'Gah :) Clicô', '99137-2616', 'retirada', '2026-09-28 09:00:00', '2026-10-05', 1, 1, 1, NULL),
('adm', 'Gah :) Clicô', '99137-2616', 'retirada', '2026-09-28 09:00:00', '2026-10-05', 1, 1, 1, NULL),
('adm', 'Alessandra Italianinha', '98132-6637', 'retirada', '2026-10-02 09:00:00', '2026-10-05', 1, 1, 1, NULL),
('adm', 'Aline Masson', '99285-3610', 'retirada', '2026-10-02 09:00:00', '2026-10-05', 1, 1, 1, NULL),
('adm', 'Camila', '12 98155-4661', 'retirada', '2026-09-21 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Isabela ️Passos', '98202-1007', 'retirada', '2026-09-29 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', '...', '99487-5248', 'retirada', '2026-10-05 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Jéssica Algodão Doce', '99276-7343', 'entrega', '2026-10-05 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Lila/Érika', '21 98163-9366', 'retirada', '2026-10-05 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Raquel Cia dos Doces', '98386-4702', 'retirada', '2026-10-05 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Raquel Cia dos Doces', '98386-4702', 'retirada', '2026-10-05 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Raquel Cia dos Doces', '98386-4702', 'retirada', '2026-10-05 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Bendito''S Cake - Luana Tamires', '99945-2352', 'retirada', '2026-10-05 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Maria Luiza', '99595-2812', 'retirada', '2026-10-05 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Paula Luiza', '99131-0210', 'retirada', '2026-10-05 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Elian Oishi', '99226-0062', 'entrega', '2026-10-05 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Fernando', '99692-1811', 'retirada', '2026-10-06 09:00:00', '2026-10-06', 1, 0, 0, NULL),
('adm', 'Jak Motta', '77 9829-3018', 'entrega', '2026-10-06 09:00:00', '2026-10-06', 1, 1, 1, NULL),
('adm', 'Nil', '99308-6466', 'entrega', '2026-09-23 09:00:00', '2026-10-07', 1, 1, 1, NULL),
('adm', 'Nil', '99308-6466', 'entrega', '2026-09-23 09:00:00', '2026-10-07', 1, 1, 1, NULL),
('adm', 'Nil', '99308-6466', 'entrega', '2026-09-24 09:00:00', '2026-10-07', 1, 1, 1, NULL),
('adm', 'Nil', '99308-6466', 'entrega', '2026-10-01 09:00:00', '2026-10-07', 1, 1, 1, NULL),
('adm', 'Sandra', '99124-7503', 'retirada', '2026-10-05 09:00:00', '2026-10-07', 1, 1, 1, NULL),
('adm', 'Mari', '98233-1829', 'entrega', '2026-10-06 09:00:00', '2026-10-07', 1, 1, 1, NULL),
('adm', 'Mary', '99215-2666', 'retirada', '2026-10-06 09:00:00', '2026-10-07', 1, 0, 0, NULL),
('adm', 'Fernando', '99692-1811', 'retirada', '2026-10-07 09:00:00', '2026-10-07', 1, 1, 1, NULL),
('adm', 'Andréa Kuniyoshi Miss Cake', '97117-7447', 'retirada', '2026-10-06 09:00:00', '2026-10-07', 1, 1, 1, NULL),
('adm', 'Jéssica', '11 97453-4135', 'entrega', '2026-10-06 09:00:00', '2026-10-07', 1, 1, 1, NULL),
('adm', 'Dolce Nina', '99902-4522', 'entrega', '2026-10-05 09:00:00', '2026-10-08', 1, 1, 1, NULL),
('adm', 'Valquíria Fagundes', '99112-6985', 'retirada', '2026-10-05 09:00:00', '2026-10-08', 1, 1, 1, NULL),
('adm', 'Danielle Naves', '99103-8239', 'retirada', '2026-10-06 09:00:00', '2026-10-08', 1, 1, 1, NULL),
('adm', 'Dolce Nina', '99902-4522', 'entrega', '2026-10-06 09:00:00', '2026-10-08', 1, 1, 1, NULL),
('adm', 'Raquel', '98386-4702', 'entrega', '2026-10-07 09:00:00', '2026-10-08', 1, 1, 1, NULL),
('adm', 'Zane Teal Gaia', '1 (949) 987-4062', 'retirada', '2026-10-07 09:00:00', '2026-10-08', 1, 1, 1, NULL),
('adm', 'Crislaine Liara', '99665-7111', 'retirada', '2026-10-06 09:00:00', '2026-10-08', 1, 1, 1, NULL),
('adm', 'Crislaine Liara', '99665-7111', 'retirada', '2026-10-06 09:00:00', '2026-10-08', 1, 1, 1, NULL),
('adm', 'Luciana', '98238-6281', 'retirada', '2026-09-28 09:00:00', '2026-10-08', 1, 1, 0, 'pronto'),
('adm', 'Michele Micuca', '99384-8384', 'entrega', '2026-10-08 09:00:00', '2026-10-08', 0, 1, 1, 'Pagamento pendente'),
('adm', 'Camila Reinato', '99452-8607', 'retirada', '2026-10-02 09:00:00', '2026-10-08', 0, 1, 1, 'Pagamento pendente'),
('adm', 'Ana Carolinha Passafaro', '99195-4453', 'retirada', '2026-10-06 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Ana Carolinha Passafaro', '99195-4454', 'retirada', '2026-10-06 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Ana Carolinha Passafaro', '99195-4454', 'retirada', '2026-10-08 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Melina Queiroz', '99132-5472', 'retirada', '2026-10-02 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Fernanda', '99193-1639', 'entrega', '2026-10-06 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Genifer Rocha', '98942-3423', 'entrega', '2026-10-06 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Genifer Rocha', '98942-3423', 'entrega', '2026-10-06 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Genifer Rocha', '98942-3423', 'entrega', '2026-10-06 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Genifer Rocha', '98942-3423', 'entrega', '2026-10-09 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Genifer Rocha', '98942-3423', 'entrega', '2026-10-09 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Camila Maria', '99196-4154', 'entrega', '2026-10-08 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Bruna Silva', '99234-4827', 'retirada', '2026-10-08 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Debby Cake', '98708-0182', 'retirada', '2026-10-07 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Lidiane Costa', '99210-5563', 'retirada', '2026-10-08 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Marli Costta', '98824-2817', 'retirada', '2026-10-08 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Lidiane Costa', '99210-5563', 'retirada', '2026-10-08 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Isabella Araujo', '99144-8652', 'entrega', '2026-10-08 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Jak Motta', '77 9829-3018', 'retirada', '2026-10-09 09:00:00', '2026-10-09', 1, 1, 1, NULL),
('adm', 'Debby Cake', '98708-0182', 'entrega', '2026-10-07 09:00:00', '2026-10-10', 1, 1, 1, NULL),
('adm', 'Amanda Lopes', '99842-3656', 'retirada', '2026-10-08 09:00:00', '2026-10-10', 1, 1, 1, NULL),
('adm', 'Ellen Cardoso', '97409-1452', 'retirada', '2026-10-11 09:00:00', '2026-10-11', 1, 1, 1, NULL),
('adm', 'Emanuelle Bergamin', '96900-0996', 'retirada', '2026-10-10 09:00:00', '2026-10-11', 1, 1, 1, NULL),
('adm', 'Isabella Araujo', '99144-8652', 'entrega', '2026-10-08 09:00:00', '2026-10-12', 1, 1, 1, NULL),
('adm', 'Gabi Bittencourt', '41 9775-9286', 'retirada', '2026-10-09 09:00:00', '2026-10-12', 1, 1, 1, NULL),
('adm', 'Valéria', '99201-1575', 'retirada', '2026-10-09 09:00:00', '2026-10-13', 1, 1, 1, NULL),
('adm', 'Soemmys Regina', '99526-9936', 'retirada', '2026-10-09 09:00:00', '2026-10-13', 1, 1, 1, NULL),
('adm', 'Tatiane Vilela', '99391-5750', 'retirada', '2026-09-23 09:00:00', '2026-10-13', 1, 1, 1, NULL),
('adm', 'Fernanda Sissi', '99520-7000', 'retirada', '2026-10-10 09:00:00', '2026-10-13', 1, 1, 1, NULL),
('adm', 'Lucas Fortunato', '98346-1661', 'retirada', '2026-10-10 09:00:00', '2026-10-13', 1, 1, 1, NULL),
('adm', 'Angelica alexandra', '99451-1311', 'retirada', '2026-10-13 09:00:00', '2026-10-13', 1, 1, 1, NULL),
('adm', 'Gih', '98936-8105', 'retirada', '2026-10-14 09:00:00', '2026-10-14', 1, 1, 1, NULL),
('adm', 'Aryane Dias', '99811-0784', 'entrega', '2026-10-08 09:00:00', '2026-10-14', 1, 1, 1, NULL),
('adm', 'Thaís', '99157-1692', 'retirada', '2026-10-14 09:00:00', '2026-10-14', 1, 1, 1, NULL),
('adm', 'Jana Pão De Mel', '97412-1012', 'retirada', '2026-10-14 09:00:00', '2026-10-14', 1, 1, 1, NULL),
('adm', 'Raquel Cia dos Bolos', '98386-4702', 'retirada', '2026-10-13 09:00:00', '2026-10-14', 1, 1, 1, NULL),
('adm', 'Larissa Ferrari', '98343-2850', 'retirada', '2026-10-14 09:00:00', '2026-10-14', 1, 1, 1, NULL),
('adm', 'Larissa Ferrari', '98343-2850', 'retirada', '2026-10-14 09:00:00', '2026-10-14', 1, 1, 1, NULL),
('adm', 'Jessica', '11 97453-4135', 'entrega', '2026-10-08 09:00:00', '2026-10-14', 1, 1, 1, NULL),
('adm', 'Jak Motta', '77 9829-3018', 'entrega', '2026-10-14 09:00:00', '2026-10-14', 1, 1, 1, NULL),
('adm', 'Jak Motta', '77 9829-3018', 'entrega', '2026-10-14 09:00:00', '2026-10-14', 1, 1, 1, NULL),
('adm', 'Fabrício - Leo Soldeira', '97106-3209', 'retirada', '2026-10-14 09:00:00', '2026-10-15', 1, 1, 1, NULL),
('adm', 'Angelica alexandra', '99451-1311', 'retirada', '2026-10-14 09:00:00', '2026-10-15', 1, 1, 1, NULL),
('adm', 'Angelica alexandra', '99451-1311', 'retirada', '2026-10-14 09:00:00', '2026-10-15', 1, 1, 1, NULL),
('adm', 'Raquel Pereira', '99959-4821', 'retirada', '2026-10-15 09:00:00', '2026-10-15', 1, 1, 1, NULL),
('adm', 'Marcia', '99221-6249', 'entrega', '2026-10-15 09:00:00', '2026-10-15', 1, 1, 1, NULL),
('adm', 'Thiago Borges', '99818-7863', 'entrega', '2026-10-16 09:00:00', '2026-10-16', 0, 1, 1, 'Pagamento pendente'),
('adm', 'Debby Cake', '98708-0182', 'retirada', '2026-10-13 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Debby Cake', '98708-0182', 'retirada', '2026-10-15 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Debby Cake', '98708-0182', 'retirada', '2026-10-16 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Célia', '98909-3658', 'retirada', '2026-10-13 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Danielle Naves', '99103-8239', 'retirada', '2026-10-16 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Poly stelly', '99727-5222', 'entrega', '2026-10-07 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Poly stelly', '99727-5222', 'entrega', '2026-10-07 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Isabella Araujo', '99144-8652', 'entrega', '2026-10-15 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Fernanda', '99193-1639', 'entrega', '2026-09-25 09:00:00', '2026-10-16', 1, 1, 1, 'R$5 em haver'),
('adm', 'Marina', '98115-9297', 'retirada', '2026-10-02 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Helen Freitas', '97119-6267', 'retirada', '2026-10-14 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Zuzu Bolo Salgado', '99715-3164', 'retirada', '2026-10-15 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Jackeline Domingues', '98916-2159', 'entrega', '2026-10-16 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Camys', '97127-4631', 'retirada', '2026-10-15 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Fabrício Brownies', '99373-1412', 'retirada', '2026-10-16 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Isabella Araujo', '99144-8652', 'entrega', '2026-10-15 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Laís Andrade', '98977-5565', 'entrega', '2026-10-16 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Jak Motta', '77 9829-3018', 'entrega', '2026-10-16 09:00:00', '2026-10-16', 1, 1, 1, NULL),
('adm', 'Duci Parmezani', '98239-6297', 'retirada', '2026-10-16 09:00:00', '2026-10-16', 0, 0, 0, 'pagamento pendente'),
('adm', 'Duci Parmezani', '98239-6297', 'retirada', '2026-10-16 09:00:00', '2026-10-16', 0, 0, 0, 'pagamento pendente'),
('adm', 'Jéssica Algodão Doce', '99276-7343', 'entrega', '2026-10-16 09:00:00', '2026-10-19', 1, 1, 1, NULL),
('adm', 'Mara Luciana', '99258-0266', 'retirada', '2026-10-16 09:00:00', '2026-10-19', 1, 1, 1, NULL),
('adm', 'Elisandra Cardoso', '99270-4516', 'retirada', '2026-10-19 09:00:00', '2026-10-19', 1, 1, 1, NULL),
('adm', 'Dayana Felipe', '99127-0424', 'retirada', '2026-10-15 09:00:00', '2026-10-20', 1, 1, 1, NULL),
('adm', 'MADZ', '97111-7407', 'retirada', '2026-10-14 09:00:00', '2026-10-20', 1, 1, 1, NULL),
('adm', 'MADZ', '97111-7407', 'retirada', '2026-10-14 09:00:00', '2026-10-20', 1, 1, 1, NULL),
('adm', 'MADZ', '97111-7407', 'retirada', '2026-10-16 09:00:00', '2026-10-20', 1, 1, 1, NULL),
('adm', 'Genifer Rocha', '98942-3423', 'retirada', '2026-10-19 09:00:00', '2026-10-20', 1, 1, 1, NULL),
('adm', 'Lucas', '98301-8351', 'retirada', '2026-10-19 09:00:00', '2026-10-20', 1, 1, 1, NULL),
('adm', 'Doces Ferretti', '98354-1949', 'retirada', '2026-10-20 09:00:00', '2026-10-20', 1, 1, 1, NULL),
('adm', 'Andréa Meneguite', '99320-2088', 'retirada', '2026-10-20 09:00:00', '2026-10-20', 1, 1, 1, NULL),
('adm', 'Debby Cake', '98708-0182', 'entrega', '2026-10-19 09:00:00', '2026-10-21', 1, 1, 1, NULL),
('adm', 'Maristela Morango', '99885-8240', 'retirada', '2026-10-20 09:00:00', '2026-10-21', 1, 1, 1, NULL),
('adm', 'Gra Senna', '99799-6126', 'entrega', '2026-10-20 09:00:00', '2026-10-21', 1, 1, 1, NULL),
('adm', 'Dayana Felipe', '99127-0424', 'retirada', '2026-10-20 09:00:00', '2026-10-21', 1, 1, 1, NULL),
('adm', 'Núbia Leal', '98314-9201', 'entrega', '2026-10-21 09:00:00', '2026-10-21', 1, 1, 1, NULL),
('adm', 'Aline', '99656-5232', 'retirada', '2026-10-20 09:00:00', '2026-10-21', 1, 1, 1, NULL),
('adm', 'Lunara', '67 8179-8123', 'retirada', '2026-09-01 09:00:00', '2026-10-22', 1, 1, 1, NULL),
('adm', 'Amanda Lopes', '99842-3656', 'retirada', '2026-10-21 09:00:00', '2026-10-22', 1, 1, 1, NULL),
('adm', 'Silfér Cake', '98846-0905', 'entrega', '2026-10-22 09:00:00', '2026-10-22', 1, 1, 1, NULL),
('adm', 'Nil', '99308-6466', 'retirada', '2026-10-12 09:00:00', '2026-10-22', 1, 1, 1, NULL),
('adm', 'Paula', '99159-4791', 'retirada', '2026-10-15 09:00:00', '2026-10-22', 1, 1, 1, 'R$5 em haver'),
('adm', 'Guilherme', '99418-4725', 'retirada', '2026-10-16 09:00:00', '2026-10-22', 1, 1, 1, NULL),
('adm', 'Bruno Peterson', '98781-9995', 'retirada', '2026-10-22 09:00:00', '2026-10-22', 1, 1, 1, NULL),
('adm', 'Akemi', '99116-2243', 'retirada', '2026-10-20 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Akemi', '99116-2243', 'retirada', '2026-10-20 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Fernanda Sissi', '99520-7000', 'entrega', '2026-10-23 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Leylane Lopes', '98965-8093', 'retirada', '2026-10-16 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Leylane Lopes', '98965-8093', 'retirada', '2026-10-22 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Leylane Lopes', '98965-8093', 'retirada', '2026-10-16 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Denise Doce Infância', '99833-5109', 'entrega', '2026-10-20 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Denise Doce Infância', '99833-5109', 'entrega', '2026-10-20 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Denise Doce Infância', '99833-5109', 'entrega', '2026-10-20 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Sanae Kumagai', '99271-0022', 'retirada', '2026-10-19 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Genifer Rocha', '98942-3423', 'entrega', '2026-10-19 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Genifer Rocha', '98942-3423', 'entrega', '2026-10-20 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Genifer Rocha', '98942-3423', 'entrega', '2026-10-23 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Dolce Nina', '99902-4522', 'entrega', '2026-10-20 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Dolce Nina', '99902-4522', 'entrega', '2026-10-20 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Dolce Nina', '99902-4522', 'entrega', '2026-10-20 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Raquel Cia do Bolo', '98386-4702', 'entrega', '2026-10-20 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Beatriz Amaral', '98904-3443', 'retirada', '2026-10-21 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Ana Paula', '98196-9569', 'entrega', '2026-10-22 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Jullia Pereira Aveline', '99664-9900', 'retirada', '2026-10-22 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Larissa Oliveira', '98288-9941', 'retirada', '2026-10-23 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Bia', '98456-5908', 'entrega', '2026-10-22 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Giovana', '98726-9641', 'retirada', '2026-10-22 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Hellen', '98241-1639', 'entrega', '2026-10-22 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Dandrea', '99353-2285', 'retirada', '2026-10-16 09:00:00', '2026-10-23', 1, 1, 1, NULL),
('adm', 'Isabella Araujo', '99144-8652', 'entrega', '2026-10-19 09:00:00', '2026-10-24', 1, 1, 1, NULL),
('adm', 'Clarice Martins', '89 9402-2037', 'retirada', '2026-10-22 09:00:00', '2026-10-24', 1, 1, 1, NULL),
('adm', 'Dandrea', '99353-2285', 'retirada', '2026-10-20 09:00:00', '2026-10-24', 1, 1, 1, NULL),
('adm', 'Isabella Araujo', '99144-8652', 'retirada', '2026-10-22 09:00:00', '2026-10-24', 1, 1, 1, NULL),
('adm', 'Raquel', '99432-8652', 'retirada', '2026-10-23 09:00:00', '2026-10-24', 1, 1, 1, NULL),
('adm', 'Manuela Rocha', '98224-8477', 'retirada', '2026-10-23 09:00:00', '2026-10-24', 1, 1, 1, NULL),
('adm', 'Jak Motta', '77 9829-3018', 'entrega', '2026-10-20 09:00:00', '2026-10-24', 1, 1, 1, NULL),
('adm', 'Jak Motta', '77 9829-3018', 'retirada', '2026-10-20 09:00:00', '2026-10-24', 1, 1, 1, NULL),
('adm', 'Cidinha', '97145-3596', 'retirada', '2026-10-22 09:00:00', '2026-10-24', 1, 0, 0, NULL),
('adm', 'Debby Cake', '98708-0182', 'retirada', '2026-10-24 09:00:00', '2026-10-26', 1, 1, 1, NULL),
('adm', 'Willanys Silva', '98727-6141', 'entrega', '2026-10-19 09:00:00', '2026-10-26', 1, 1, 1, NULL),
('adm', 'Jana Pão de Mel', '97412-1012', 'retirada', '2026-10-22 09:00:00', '2026-10-26', 1, 1, 1, NULL),
('adm', 'Carol Machado La Cakery', '99929-0076', 'entrega', '2026-10-22 09:00:00', '2026-10-26', 1, 1, 1, NULL),
('adm', 'Raquel Cia do Bolo', '98386-4702', 'retirada', '2026-10-22 09:00:00', '2026-10-26', 1, 1, 1, NULL),
('adm', 'Sandra Nucci', '99208-0436', 'retirada', '2026-10-21 09:00:00', '2026-10-26', 1, 1, 1, NULL),
('adm', 'Joice', '99485-5051', 'retirada', '2026-10-23 09:00:00', '2026-10-26', 1, 1, 1, NULL),
('adm', 'Larissa', '98167-7386', 'entrega', '2026-10-26 09:00:00', '2026-10-26', 1, 1, 1, NULL),
('adm', 'Joana e Marta', '97417-9235', 'retirada', '2026-10-26 09:00:00', '2026-10-26', 1, 1, 1, NULL),
('adm', 'Isabella Araujo', '99144-8652', 'entrega', '2026-10-23 09:00:00', '2026-10-27', 1, 1, 1, NULL),
('adm', 'Isabella Araujo', '99144-8652', 'entrega', '2026-10-26 09:00:00', '2026-10-27', 1, 1, 1, NULL),
('adm', 'Eliane Doce Amor', '98353-7587', 'retirada', '2026-10-26 09:00:00', '2026-10-27', 1, 1, 1, NULL),
('adm', 'Guilherme Fabris', '13 99721-0955', 'retirada', '2026-10-26 09:00:00', '2026-10-27', 1, 1, 1, NULL),
('adm', 'Raquel Cia do Bolo', '98386-4702', 'entrega', '2026-10-23 09:00:00', '2026-10-27', 1, 1, 1, NULL),
('adm', 'Luana', '99525-3047', 'entrega', '2026-10-26 09:00:00', '2026-10-27', 1, 1, 1, NULL),
('adm', 'Marli Costta', '98824-2817', 'retirada', '2026-10-26 09:00:00', '2026-10-28', 1, 1, 1, NULL),
('adm', 'Aryza', '51 9591-0467', 'retirada', '2026-10-28 09:00:00', '2026-10-28', 1, 1, 1, NULL),
('adm', 'Jak Motta', '77 9829-3018', 'entrega', '2026-10-20 09:00:00', '2026-10-28', 1, 1, 1, NULL),
('adm', 'Jak Motta', '77 9829-3018', 'entrega', '2026-10-20 09:00:00', '2026-10-28', 1, 1, 1, NULL),
('adm', 'Jak Motta', '77 9829-3018', 'entrega', '2026-10-20 09:00:00', '2026-10-28', 1, 1, 1, NULL),
('adm', 'Akemi', '99116-2243', 'retirada', '2026-10-20 09:00:00', '2026-10-28', 1, 1, 1, NULL),
('adm', 'Akemi', '99116-2243', 'retirada', '2026-10-20 09:00:00', '2026-10-28', 1, 1, 1, NULL),
('adm', 'Michelle Tagliati', '61 9303-1271', 'retirada', '2026-10-29 09:00:00', '2026-10-29', 0, 1, 1, 'pendente 29,00'),
('adm', 'Anacleto Coquetéis', '97413-9571', 'retirada', '2026-09-29 09:00:00', '2026-10-29', 1, 1, 1, NULL),
('adm', 'Daniele', '99183-9433', 'retirada', '2026-10-22 09:00:00', '2026-10-29', 1, 1, 1, NULL),
('adm', 'Carol Tito', '35 8875-2310', 'retirada', '2026-10-26 09:00:00', '2026-10-29', 1, 1, 1, NULL),
('adm', 'Dolce Nina', '99902-4522', 'retirada', '2026-10-27 09:00:00', '2026-10-29', 1, 1, 1, NULL),
('adm', 'Dolce Nina', '99902-4522', 'retirada', '2026-10-27 09:00:00', '2026-10-29', 1, 1, 1, NULL),
('adm', 'Genifer Rocha', '98942-3423', 'retirada', '2026-10-27 09:00:00', '2026-10-29', 1, 1, 1, NULL),
('adm', 'Caroline Boriolo', '1 (845) 536-0077', 'retirada', '2026-10-01 09:00:00', '2026-10-29', 1, 1, 1, NULL),
('adm', 'Raquel Cia do Bolo', '98386-4702', 'entrega', '2026-10-23 09:00:00', '2026-10-29', 1, 1, 1, NULL),
('adm', 'Michelle Tagliati', '61 9303-1271', 'retirada', '2026-10-28 09:00:00', '2026-10-29', 1, 1, 1, NULL),
('adm', 'Jak Motta', '77 9829-3018', 'retirada', '2026-10-29 09:00:00', '2026-10-29', 1, 1, 1, NULL),
('adm', 'Debby Cake', '98708-0182', 'retirada', '2026-10-19 09:00:00', '2026-10-29', 1, 1, 1, NULL),
('adm', 'Duci Parmezani', '98239-6297', 'retirada', '2026-10-29 09:00:00', '2026-10-29', 0, 1, 1, 'Pagamento pendente'),
('adm', 'Duci Parmezani', '98239-6297', 'retirada', '2026-10-29 09:00:00', '2026-10-29', 0, 1, 1, 'Pagamento pendente'),
('adm', 'Duci Parmezani', '98239-6297', 'retirada', '2026-10-29 09:00:00', '2026-10-29', 0, 1, 1, 'Pagamento pendente'),
('adm', 'Gabriel Lima Pixel Print', '99303-5677', 'retirada', '2026-10-23 09:00:00', '2026-10-30', 1, 1, 1, NULL),
('adm', 'Raquel Cia do Bolo', '98386-4702', 'retirada', '2026-10-23 09:00:00', '2026-10-31', 1, 1, 1, NULL),
('adm', 'Chef Maria Lúcia', '99342-0945', 'entrega', '2026-10-29 09:00:00', '2026-10-31', 1, 1, 1, NULL),
('adm', 'Lila/Carla', '21 97320-2000', 'retirada', '2026-10-28 09:00:00', '2026-10-31', 1, 1, 1, NULL),
('adm', 'Cidinha', '97145-3596', 'retirada', '2026-10-30 09:00:00', '2026-10-31', 1, 1, 1, NULL),
('adm', 'Cidinha', '97145-3596', 'retirada', '2026-10-30 09:00:00', '2026-10-31', 1, 1, 1, NULL),
('adm', 'Bruna Silva', '99234-4827', 'retirada', '2026-10-29 09:00:00', '2026-10-31', 1, 1, 1, NULL),
('adm', 'Antonia VS', '68 9207-4249', 'retirada', '2026-10-01 09:00:00', '2026-10-31', 1, 1, 1, 'Total na planilha: R$ 35,00'),
('adm', 'Antonia VS', '68 9207-4249', 'retirada', '2026-10-01 09:00:00', '2026-10-31', 1, 1, 1, NULL),
('adm', 'Antonia VS', '68 9207-4249', 'retirada', '2026-10-01 09:00:00', '2026-10-31', 1, 1, 1, NULL),
('adm', 'Antonia VS', '68 9207-4249', 'retirada', '2026-10-01 09:00:00', '2026-10-31', 1, 1, 1, NULL),
('adm', 'Antonia VS', '68 9207-4249', 'retirada', '2026-10-01 09:00:00', '2026-10-31', 1, 1, 1, NULL),
('adm', 'Antonia VS', '68 9207-4249', 'retirada', '2026-10-01 09:00:00', '2026-10-31', 1, 1, 1, NULL),
('adm', 'Carol Barros', '99620-9925', 'retirada', '2026-10-27 09:00:00', '2026-11-01', 1, 0, 0, NULL),
('adm', 'Camila Rosado', '89 9988-1338', 'retirada', '2026-10-30 09:00:00', '2026-11-01', 1, 1, 1, NULL),
('adm', 'Joana e Marta', '97417-9235', 'retirada', '2026-10-26 09:00:00', '2026-11-02', 0, 0, 0, 'produzir'),
('adm', 'Midiã', '99745-7797', 'retirada', '2026-10-28 09:00:00', '2026-11-02', 1, 0, 0, 'Enviar arte'),
('adm', 'Jak Motta', '77 9829-3018', 'retirada', '2026-10-20 09:00:00', '2026-11-04', 1, 0, 0, 'Enviar arte'),
('adm', 'Gabby Bolos', '98221-5043', 'retirada', '2026-10-30 09:00:00', '2026-11-04', 0, 0, 0, 'Enviar arte'),
('adm', 'Ana Luiza Vila Do Figo', '21 96627-7927', 'retirada', '2026-11-01 09:00:00', '2026-11-04', 0, 0, 0, 'Enviar arte'),
('adm', 'Angélica', '99952-3518', 'entrega', '2026-10-27 09:00:00', '2026-11-04', 1, 1, 1, NULL),
('adm', 'Renata Silva', '94 8119-1655', 'retirada', '2026-11-04 09:00:00', '2026-11-04', 0, 0, 0, 'Enviar arte'),
('adm', 'Kariny Queiroz', '41 7400-1334', 'retirada', '2026-10-26 09:00:00', '2026-11-06', 0, 0, 0, 'Enviar arte'),
('adm', 'Camila Reinato', '99452-8607', 'retirada', '2026-09-30 09:00:00', '2026-11-15', 0, 0, 0, 'Enviar arte'),
('adm', 'Thais Fonseca', '99152-9315', 'retirada', '2026-10-21 09:00:00', '2026-11-23', 1, 1, 1, NULL),
('adm', 'Neusa', '98303-7811', 'retirada', '2026-11-03 09:00:00', '2026-11-18', 0, 0, 0, 'Enviar arte'),
('adm', 'Debby Cake', '98708-0182', 'retirada', '2026-11-17 09:00:00', '2026-11-18', 0, 0, 0, 'produzir'),
('adm', 'Debby Cake', '98708-0182', 'retirada', '2026-11-17 09:00:00', '2026-11-18', 0, 0, 0, 'Enviar arte'),
('adm', 'Rodrigo', '99381-9535', 'retirada', '2026-11-16 09:00:00', '2026-11-19', 0, 0, 0, 'Enviar arte'),
('adm', 'Café com Caramelo', '99788-1941', 'retirada', '2026-11-18 09:00:00', '2026-11-19', 0, 0, 0, 'aguardando confirmação'),
('adm', 'Jefferson', '99285-5732', 'retirada', '2026-11-17 09:00:00', '2026-11-19', 0, 0, 0, 'Enviar arte'),
('adm', 'Danielle Naves', '99103-8239', 'retirada', '2026-11-18 09:00:00', '2026-11-19', 0, 0, 0, 'Enviar arte'),
('adm', 'Genifer Rocha', '98942-3423', 'retirada', '2026-11-17 09:00:00', '2026-11-19', 0, 0, 0, 'Enviar arte'),
('adm', 'Genifer Rocha', '98942-3423', 'retirada', '2026-11-17 09:00:00', '2026-11-19', 0, 0, 0, 'Enviar arte'),
('adm', 'Glaucia Carvalho', '99752-4753', 'retirada', '2026-11-12 09:00:00', '2026-11-20', 0, 0, 0, 'aguardando arte'),
('adm', 'Renan Guimarães', '99643-6891', 'retirada', '2026-11-10 09:00:00', '2026-11-20', 0, 0, 0, 'Enviar arte'),
('adm', 'I-medic', '98384-0169', 'retirada', '2026-11-16 09:00:00', '2026-11-20', 0, 0, 0, 'aguardando arte'),
('adm', 'Julia Pereira Aveline', '99664-9900', 'retirada', '2026-11-18 09:00:00', '2026-11-20', 0, 1, 0, 'aguardo pagamento/ pronto'),
('adm', 'Salette Rodrigues', '98894-2304', 'retirada', '2026-11-20 09:00:00', '2026-11-20', 0, 0, 0, 'Enviar arte'),
('adm', 'Maya', '99617-2179', 'retirada', '2026-11-19 09:00:00', '2026-11-26', 1, 0, 0, 'produzir'),
('adm', 'Angélica', '99952-3518', 'retirada', '2026-10-27 09:00:00', '2026-11-30', 0, 0, 0, 'Enviar arte'),
('adm', 'Chef Maria Lúcia', '99342-0945', 'retirada', '2026-11-11 09:00:00', '2026-12-01', 0, 0, 0, 'Enviar arte | 11/11/26'),
('adm', 'Gislaine', '99850-5946', 'retirada', '2026-11-04 09:00:00', '2026-12-01', 0, 0, 0, 'Enviar arte'),
('adm', 'Maria Helena', '45 99958-7245', 'retirada', '2026-11-10 09:00:00', '2026-12-01', 0, 0, 0, 'Enviar arte'),
('adm', 'Andréa Kuniyoshi', '97117-7447', 'retirada', '2026-11-16 09:00:00', '2026-12-01', 0, 0, 0, 'Enviar arte'),
('adm', 'Chef Maria Lúcia', '99342-0945', 'retirada', '2026-11-05 09:00:00', '2026-12-04', 0, 0, 0, 'Enviar arte'),
('adm', 'Sheyla', '11 97594-9740', 'retirada', '2026-11-09 09:00:00', '2026-12-18', 0, 0, 0, 'Enviar arte'),
('adm', 'Lila/ Carol', '99161-7029', 'retirada', '2026-11-17 09:00:00', '2026-12-18', 1, 0, 0, 'Enviar arte');

INSERT INTO itens_pedido (id_pedido, produto, valor, quantidade, tema, precisa_arte) VALUES
(1, 'Impressão - papel arroz', 17.00, 1, 'Dave da Esquina', 0),
(2, 'Impressão - papel arroz', 17.00, 2, 'GB Demolição/Heineken', 0),
(3, 'Topper', 15.00, 1, 'Cebolinha/ Levi', 0),
(4, 'Impressão - papel arroz', 17.00, 2, 'Guerreiras do KPOP', 0),
(5, 'Impressão - papel arroz', 17.00, 2, 'Fotos', 0),
(6, 'Topper', 12.00, 1, 'GB Demolição', 0),
(7, 'Topper', 22.00, 1, 'Bike', 0),
(8, 'Impressão - papel arroz', 17.00, 1, 'Spotify', 0),
(9, 'Cortado - papel arroz', 730.00, 1, 'Nossa Senhora do Rosário', 0),
(10, 'Impressão - papel arroz', 17.00, 1, 'Andrea Kimi Antonelli', 0),
(11, 'Impressão - papel arroz', 17.00, 1, 'Não duvide Ele pode', 0),
(12, 'Impressão - photoglosy', 12.00, 1, 'qr code', 0),
(13, 'Impressão - papel arroz', 17.00, 1, 'Super Mario', 0),
(14, 'Topper', 15.00, 1, 'Homem Aranha', 0),
(15, 'Círculo - papel arroz', 20.00, 2, 'Sim Summer', 0),
(16, 'Topper', 22.00, 1, 'Flork', 0),
(17, 'Impressão - papel arroz', 17.00, 1, 'Coroinhas', 0),
(18, 'Impressão - papel arroz', 17.00, 1, 'Diversos', 0),
(19, 'Topper', 15.00, 1, 'Diversos', 0),
(20, 'Topper', 30.00, 1, 'Homem Aranha', 0),
(21, 'Papel açúcar', 17.00, 2, 'circulos azuis', 0),
(22, 'Impressão - papel arroz', 17.00, 1, 'Caricatura rapaz', 0),
(23, 'Topper', 22.00, 1, 'Fotos', 0),
(24, 'Círculo - papel arroz', 20.00, 1, 'Games Vlll', 0),
(25, 'Impressão - papel açucar', 17.00, 2, 'PN Pharma', 0),
(26, 'Caneca', 38.00, 2, 'fotos', 0),
(27, 'Círculo - papel arroz', 20.00, 2, 'La Cakerie', 0),
(28, 'Caneca', 38.00, 1, 'Capitão Vitório', 0),
(29, 'Impressão - papel arroz', 17.00, 1, 'RBD', 0),
(30, 'Topper', 30.00, 1, 'Bodas de Heliotrópio', 0),
(31, 'Topper', 32.00, 1, 'Roblox', 0),
(32, 'Tags', 18.00, 2, 'Margaridas', 0),
(33, 'Círculo - papel arroz', 20.00, 10, 'Noivos', 0),
(34, 'Círculo - papel arroz', 20.00, 7, 'Monograma', 0),
(35, 'Impressão - papel arroz', 17.00, 2, 'Mario', 0),
(36, 'Impressão - papel arroz', 17.00, 1, 'Swift', 0),
(37, 'Topper', 25.00, 1, 'Pool Party', 0),
(38, 'Topper', 22.00, 1, 'Fotos', 0),
(39, 'Impressão - papel arroz', 17.00, 1, 'Calendário', 0),
(40, 'Impressão - papel arroz', 17.00, 3, 'Turma da Monica', 0),
(41, 'Impressão - papel arroz', 17.00, 1, 'Aluno Cardoso', 0),
(42, 'Impressão - papel arroz', 17.00, 1, 'Jujutsu Kaisen', 0),
(43, 'Topper', 22.00, 1, 'De repente 30', 0),
(44, 'Topper - docinho', 18.00, 1, 'De repente 30', 0),
(45, 'Impressão - papel arroz', 17.00, 1, 'Galinha', 0),
(46, 'Impressão - papel arroz', 17.00, 1, 'Belo', 0),
(47, 'Impressão - papel arroz', 17.00, 1, 'Vogue', 0),
(48, 'Impressão - papel arroz', 17.00, 1, 'Mr. Big', 0),
(49, 'Impressão - papel arroz', 17.00, 1, 'arte própria', 0),
(50, 'Impressão - papel arroz', 17.00, 1, 'Onça', 0),
(51, 'Topper', 35.00, 1, 'Bolofofos', 0),
(52, 'Topper', 22.00, 1, 'Zíngara', 0),
(53, 'Topper', 50.00, 1, 'Maria Cogumelos', 0),
(54, 'Topper', 22.00, 1, 'Onibus', 0),
(55, 'Impressão - papel arroz', 17.00, 1, 'Nossa Senhora Aparecida', 0),
(56, 'Impressão - papel arroz', 17.00, 1, 'Toy Story', 0),
(57, 'Impressão - papel arroz', 17.00, 2, 'Estampa flor', 0),
(58, 'Impressão - papel arroz', 17.00, 1, 'arte própria', 0),
(59, 'Topper', 22.00, 1, 'Parabéns Jonas lamicote', 0),
(60, 'Impressão - papel arroz', 17.00, 1, 'Lula Molusco/ Flork', 0),
(61, 'Impressão - papel arroz', 17.00, 1, 'Foto', 0),
(62, 'Impressão - papel arroz', 17.00, 1, 'Caveira mexicana', 0),
(63, 'Topper', 22.00, 1, 'Chá de bebê', 0),
(64, 'Impressão - papel arroz', 17.00, 1, 'lamicote prata', 0),
(65, 'Impressão - papel arroz', 17.00, 1, 'Relógio', 0),
(66, 'Impressão - papel arroz', 17.00, 7, 'Van Gogh/Picasso', 0),
(67, 'Impressão - papel arroz', 17.00, 5, 'Umbanda/Dia dos Professores', 0),
(68, 'Círculo - papel arroz', 20.00, 6, 'Umbanda/Dia dos Professores', 0),
(69, 'Impressão - papel arroz', 17.00, 1, 'Casamento', 0),
(70, 'Tag', 18.00, 1, 'Dia dos Professores', 0),
(71, 'Tag', 20.00, 1, 'Dia dos Professores', 0),
(72, 'Topper', 40.00, 1, 'Harry Potter', 0),
(73, 'Impressão - papel arroz', 17.00, 1, 'Patrulha Canina', 0),
(74, 'Tag', 18.00, 1, 'Futebol', 0),
(75, 'Topper', 35.00, 1, 'Kung Fu', 0),
(76, 'Impressão - papel arroz', 20.00, 3, 'Looney Tunes', 0),
(77, 'Topper', 22.00, 1, 'Princesa Tiana', 0),
(78, 'Topper', 22.00, 1, 'Branca de Neve', 0),
(79, 'Topper', 22.00, 1, 'Mel', 0),
(80, 'Impressão - papel arroz', 17.00, 3, 'Orixás Mirim', 0),
(81, 'Impressão - papel arroz', 17.00, 1, 'Homem Aranha', 0),
(82, 'Impressão - papel arroz', 17.00, 1, 'Frozen', 0),
(83, 'Topper', 22.00, 1, 'Musico', 0),
(84, 'Impressão - papel arroz', 17.00, 1, 'Crepusculo', 0),
(85, 'Impressão - papel arroz', 17.00, 2, 'Monster High', 0),
(86, 'Topper', 22.00, 1, 'Great Place', 0),
(87, 'Impressão - papel arroz', 17.00, 2, 'Carros', 0),
(88, 'Topper', 25.00, 1, 'De repente 40', 0),
(89, 'Impressão - papel arroz', 17.00, 1, 'Batman', 0),
(90, 'Topper', 22.00, 1, 'Poderoso chefinho', 0),
(91, 'Círculo - papel arroz', 20.00, 3, 'Dia dos Professores', 0),
(92, 'Impressão - papel arroz', 17.00, 1, 'Tico e Teco Pool', 0),
(93, 'Círculo - papel arroz', 20.00, 10, 'casamento', 0),
(94, 'Topper', 22.00, 1, 'Sonic', 0),
(95, 'Kit bandeja', 39.00, 1, 'Homem Aranha', 0),
(96, 'Impressão - papel arroz', 17.00, 1, 'Neeko', 0),
(97, 'Impressão - papel arroz', 17.00, 1, 'gato aniversario', 0),
(98, 'Caneca', 966.00, 1, 'Dia dos Professores', 0),
(99, 'Cortado - papel arroz', 20.00, 12, 'Dia dos Professores', 0),
(100, 'Topper', 22.00, 1, 'Happy Birthday prata', 0),
(101, 'Topper', 22.00, 1, 'Guerreiras do KPOP', 0),
(102, 'Impressão - papel arroz', 17.00, 1, 'arte propria', 0),
(103, 'Kit', 435.00, 1, 'Dia dos Professores', 0),
(104, 'Impressão - papel arroz', 17.00, 1, 'arte propria menina de preto', 0),
(105, 'Impressão - papel arroz', 17.00, 1, 'Viviane Moller', 0),
(106, 'Topper', 35.00, 1, 'Vasco', 0),
(107, 'Topper', 12.00, 1, 'Happy Birthday', 0),
(108, 'Papel arroz', 8.00, 5, 'papel arroz em branco', 0),
(109, 'Topper', 35.00, 1, 'Batizado', 0),
(110, 'Topper', 17.00, 1, 'Feliz aniversário Emilia', 0),
(111, 'Topper', 25.00, 1, 'Happy Birthday/borboletas', 0),
(112, 'Impressão - papel arroz', 17.00, 1, 'Halloween Nicolas', 0),
(113, 'Topper', 22.00, 1, 'Hello 29 lamicote', 0),
(114, 'Topper', 22.00, 1, 'Dino balão', 0),
(115, 'Impressão - papel arroz', 17.00, 1, 'Homem Aranha', 0),
(116, 'Topper', 30.00, 1, 'Fazendinha', 0),
(117, 'Impressão - papel arroz', 17.00, 2, 'Virgem Maria', 0),
(118, 'Topper', 22.00, 1, 'Ponte Preta', 0),
(119, 'Impressão - papel arroz', 17.00, 1, 'Flork Vai comemorar redondo', 0),
(120, 'Impressão - papel arroz', 17.00, 1, 'Flork Vai comemorar quadrado', 0),
(121, 'Impressão - papel arroz', 17.00, 1, 'O Cavaleiro', 0),
(122, 'Impressão - papel arroz', 17.00, 3, 'Flork Ifood', 0),
(123, 'Topper', 22.00, 1, 'Fazendinha', 0),
(124, 'Topper', 4.00, 1, 'Plaquinha lamicote', 0),
(125, 'Topper', 16.00, 1, 'Happy Birthday', 0),
(126, 'Topper', 45.00, 1, 'Primeira Eucaristia', 0),
(127, 'Topper', 28.00, 1, 'Forró', 0),
(128, 'Impressão - papel arroz', 17.00, 1, 'Cabine telefonica casal', 0),
(129, 'Topper', 10.00, 1, 'Trinta e tantos planos', 0),
(130, 'Impressão - papel arroz', 17.00, 1, 'Slipknot', 0),
(131, 'Impressão - papel arroz', 17.00, 1, 'Mickey Safari', 0),
(132, 'Impressão - photoglosy', 7.00, 1, 'Cartão', 0),
(133, 'Topper', 14.00, 1, 'Boy or Girl?', 0),
(134, 'Topper', 22.00, 1, 'Cocoricó', 0),
(135, 'Topper', 25.00, 1, 'Allan 38 anos', 0),
(136, 'Impressão - papel arroz', 17.00, 1, 'BC', 0),
(137, 'Impressão - photoglosy', 12.00, 1, 'BC', 0),
(138, 'Impressão - papel arroz', 17.00, 3, 'Moana', 0),
(139, 'Impressão - papel arroz', 17.00, 1, 'Pequena Sereia', 0),
(140, 'Impressão - papel arroz', 17.00, 1, 'Caveira', 0),
(141, 'Caneca', 42.00, 2, 'Manu e Bella', 0),
(142, 'Círculo - papel arroz', 20.00, 9, 'Cachorrinho GeP', 0),
(143, 'Círculo - papel arroz', 20.00, 9, 'Cachorrinho LeS', 0),
(144, 'Círculo - papel arroz', 20.00, 5, 'Monograma', 0),
(145, 'Topper', 22.00, 1, 'Heineken', 0),
(146, 'Impressão - papel arroz', 17.00, 1, 'Joy Division', 0),
(147, 'Impressão - papel arroz', 17.00, 2, 'Bluey', 0),
(148, 'Impressão - papel arroz', 17.00, 1, 'Hello Kitty', 0),
(149, 'Impressão - papel arroz', 17.00, 1, 'Glaucia/Loirão', 0),
(150, 'Cortado - papel arroz', 20.00, 6, 'Monograma', 0),
(151, 'Impressão - papel arroz', 17.00, 1, 'Patrulha Canina', 0),
(152, 'Caneca', 42.00, 2, 'Pastores', 0),
(153, 'Impressão - papel arroz', 17.00, 1, 'Palmeiras/ times', 0),
(154, 'Caneca', 42.00, 1, 'Nossa Senhora Aparecida', 0),
(155, 'Plastificação', 7.00, 1, 'Calendário', 0),
(156, 'Cortado - papel arroz', 20.00, 1, 'Foto', 0),
(157, 'Impressão - papel arroz', 17.00, 1, 'Foto irmão', 0),
(158, 'Topper', 22.00, 1, 'Hamburguer', 0),
(159, 'Impressão - papel arroz', 17.00, 2, 'Festa na piscina', 0),
(160, 'Topper', 22.00, 1, 'Princesa Desastrada', 0),
(161, 'Cortado - papel arroz', 20.00, 3, 'Monograma EM', 0),
(162, 'Topper', 22.00, 1, 'Hello Kitty', 0),
(163, 'Folha de açúcar', 17.00, 1, 'Hello Kitty', 0),
(164, 'Impressão - papel açucar', 17.00, 1, 'Cartão bege', 0),
(165, 'Painel', 12.00, 4, 'Spa da Lavínia', 0),
(166, 'Topper', 25.00, 1, 'Família', 0),
(167, 'Topper', 22.00, 1, 'Spa da Lavínia', 0),
(168, 'Topper', 22.00, 1, 'Passarinho e carros', 0),
(169, 'Cortado - papel arroz', 20.00, 2, 'BTS', 0),
(170, 'Adesivo', 15.00, 2, 'Doce Infancia', 0),
(171, 'Cortado - papel arroz', 20.00, 4, 'Tati 42', 0),
(172, 'Topper', 22.00, 1, 'Hot Weels', 0),
(173, 'Topper', 22.00, 1, 'Os Incriveis', 0),
(174, 'Topper', 22.00, 1, 'Corinthians', 0),
(175, 'Impressão - papel arroz', 17.00, 1, 'Branca de Neve', 0),
(176, 'Topper', 40.00, 1, 'Mickey Halloween', 0),
(177, 'Topper', 22.00, 1, 'Ronaldinho', 0),
(178, 'Topper', 22.00, 1, 'Moranguinho', 0),
(179, 'Topper', 22.00, 1, 'Bolsonaro', 0),
(180, 'Topper', 22.00, 1, 'BTS', 0),
(181, 'Topper', 22.00, 1, 'Corinthians', 0),
(182, 'Impressão - papel arroz', 17.00, 1, 'Hello Kitty+ olhos', 0),
(183, 'Impressão - papel arroz', 17.00, 1, 'Menina', 0),
(184, 'Impressão - papel arroz', 17.00, 1, 'Menina', 0),
(185, 'Impressão - papel arroz', 17.00, 1, 'Avós', 0),
(186, 'Topper - docinho', 22.00, 1, 'Bebê 1 ano', 0),
(187, 'Topper', 25.00, 1, 'Halloween', 0),
(188, 'Topper', 22.00, 1, 'Fundo do Mar', 0),
(189, 'Topper', 22.00, 1, 'Cerejinhas/ foto', 0),
(190, 'Topper', 32.00, 1, 'Branca de Neve', 0),
(191, 'Impressão - papel arroz', 17.00, 1, 'Maomao apotecaria', 0),
(192, 'Impressão - papel arroz', 17.00, 2, 'Avatar', 0),
(193, 'Topper', 12.00, 1, '33', 0),
(194, 'Topper', 38.00, 1, 'Outubro Rosa', 0),
(195, 'Impressão - papel arroz', 17.00, 2, 'Corinthians', 0),
(196, 'Topper', 35.00, 1, 'Flamengo', 0),
(197, 'Impressão - papel arroz', 17.00, 1, 'Diário de um vampiro', 0),
(198, 'Impressão - papel arroz', 17.00, 2, 'Diversos', 0),
(199, 'Cortado - papel arroz', 20.00, 2, 'Bontempo', 0),
(200, 'Topper', 22.00, 1, 'Borboletas', 0),
(201, 'Impressão - papel arroz', 17.00, 1, 'Palmeiras', 0),
(202, 'Topper', 22.00, 1, 'Aposentado GMC', 0),
(203, 'Impressão - papel arroz', 17.00, 1, 'Flork', 0),
(204, 'Papel arroz', 7.00, 5, 'folha em branco', 0),
(205, 'Topper', 20.00, 1, 'Halloween morcego', 0),
(206, 'Topper', 20.00, 1, 'Halloween bruxa', 0),
(207, 'Topper', 22.00, 1, 'Legumes', 0),
(208, 'Topper', 15.00, 1, 'Yu Yu Hakusho/Harry Potter', 0),
(209, 'Impressão - papel arroz', 17.00, 1, 'Ariana Grande', 0),
(210, 'Impressão - papel arroz', 17.00, 1, 'Frozen', 0),
(211, 'Topper', 22.00, 1, 'Aniversariantes', 0),
(212, 'Impressão - photoglosy', 12.00, 1, 'fotos escola', 0),
(213, 'Topper', 22.00, 1, 'Monster', 0),
(214, 'Topper', 24.00, 1, 'Halloween', 0),
(215, 'Impressão - papel arroz', 17.00, 4, 'SIPAT 2026', 0),
(216, 'Topper', 22.00, 1, 'Casamento', 0),
(217, 'Papel arroz', 8.00, 8, 'Casamento', 0),
(218, 'Caneca', 35.00, 1, 'Outubra Rosa', 0),
(219, 'Círculo - papel arroz', 20.00, 5, 'Cachorrinhos', 0),
(220, 'Topper', 22.00, 1, 'Super Mario', 0),
(221, 'Topper', 35.00, 1, 'Espírito Santo', 0),
(222, 'Topper docinho', 18.00, 3, 'Halloween', 0),
(223, 'Impressão - papel arroz', 17.00, 1, 'Branca de Neve', 0),
(224, 'Topper', 22.00, 1, 'São Paulo', 0),
(225, 'Círculo - papel arroz', 20.00, 5, 'Cachorrinho', 0),
(226, 'Impressão - papel arroz', 17.00, 1, 'Friends', 0),
(227, 'Caneca', 42.00, 7, 'Outubra Rosa', 0),
(228, 'Topper', 15.00, 1, '36 anos', 0),
(229, 'Topper', 38.00, 1, 'Pequena Sereia', 0),
(230, 'Impressão - papel arroz', 17.00, 1, 'Cont', 0),
(231, 'Impressão - photoglosy', 12.00, 1, 'Cont', 0),
(232, 'Impressão - photoglosy', 12.00, 1, 'E. Pires', 0),
(233, 'Kit', 112.00, 1, 'Hot Wheels', 0),
(234, 'Topper', 35.00, 1, 'Batman', 0),
(235, 'Topper', 22.00, 1, 'Boteco da Camila', 0),
(236, 'Impressão - papel arroz', 17.00, 1, 'Aluno pantera', 0),
(237, 'Impressão - papel arroz', 17.00, 1, 'Palmeiras', 0),
(238, 'Impressão - papel arroz', 17.00, 1, 'Foto Gabi', 0),
(239, 'Topper', 22.00, 1, 'Sonic', 0),
(240, 'Topper', 30.00, 1, 'Harry Potter', 0),
(241, 'Topper', 30.00, 1, '50 anos', 0),
(242, 'Adesivo ou tag', 18.00, 1, 'Ovos de Dragão', 0),
(243, 'Caneca', 38.00, 1, 'Filhos e netos', 0),
(244, 'Caneca', 38.00, 1, 'Cachorro', 0),
(245, 'Caneca', 38.00, 1, 'Antonia', 0),
(246, 'Topper', 15.00, 1, 'Harry Potter Sonserina', 0),
(247, 'Topper', 22.00, 1, 'Médico', 0),
(248, 'Topper', 15.00, 1, 'S e A', 0),
(249, 'Impressão - papel arroz', 17.00, 2, 'Ferrari marlboro', 1),
(250, 'Topper', 28.00, 1, 'Moana', 1),
(251, 'Impressão - papel arroz', 17.00, 1, 'Aguardando arte', 1),
(252, 'Topper', 22.00, 1, 'Minnie', 1),
(253, 'Topper', 35.00, 1, 'Harry Potter', 0),
(254, 'Topper', 22.00, 1, 'Flork', 1),
(255, 'Impressão - papel arroz', 17.00, 1, 'Aguardando arte', 1),
(256, 'Impressão - papel arroz', 17.00, 1, 'Urso Pooh', 1),
(257, 'Impressão - papel arroz', 17.00, 2, 'Menina bebê', 0),
(258, 'Impressão - papel arroz', 17.00, 1, 'São Paulo', 1),
(259, 'Topper', 22.00, 1, 'Velozes e furiosos', 0),
(260, 'Impressão - papel arroz', 17.00, 1, 'Lule', 1),
(261, 'Impressão - papel arroz', 17.00, 1, 'Snoop', 1),
(262, 'Impressão - papel arroz', 17.00, 1, 'Patricia Mitica', 0),
(263, 'Cortado - papel arroz', 20.00, 7, 'Monograma', 1),
(264, 'Impressão - papel arroz', 18.00, 1, 'Flork', 1),
(265, 'Topper', 22.00, 1, 'Flamengo', 1),
(266, 'Topper', 22.00, 1, 'Bela e a Fera', 1),
(267, 'Impressão - papel arroz', 17.00, 1, 'aguardando arte', 0),
(268, 'Caneca', 30.00, 1, 'Alumínio CCS', 1),
(269, 'Cortado - papel arroz', 20.00, 1, 'I-medic', 0),
(270, 'Topper', 10.00, 1, 'Encaixe foto menina', 0),
(271, 'Impressão - papel arroz', 17.00, 1, 'Anime', 1),
(272, 'Impressão - papel arroz', 17.00, 1, 'Snoop', 0),
(273, 'Adesivo', 15.00, 1, 'logo 3x3 200und', 1),
(274, 'Topper', 26.00, 1, 'Praia', 1),
(275, 'Cortado - papel arroz', 20.00, 1, 'ursinho', 1),
(276, 'Caneca', 38.00, 1, 'Extrovertida, caipirinha', 1),
(277, 'Impressão - papel arroz', 17.00, 1, 'Encanto', 1),
(278, 'Topper docinho', 18.00, 1, 'Festa na piscina', 1),
(279, 'Impressão - papel arroz', 17.00, 1, 'Global label', 1),
(280, 'Impressão - papel arroz', 17.00, 1, 'Palmeiras', 1);

INSERT INTO historico (descricao, data_hora, id_pedido, autor) VALUES
('Administração adicionou encomenda de Embolados Doceria', '2026-10-01 09:00:00', 1, 'Júlia'),
('Administração adicionou encomenda de Maria', '2026-09-30 09:00:00', 2, 'Júlia'),
('Administração adicionou encomenda de Carol Barros', '2026-09-24 09:00:00', 3, 'Júlia'),
('Administração adicionou encomenda de SilFér Cake', '2026-09-30 09:00:00', 4, 'Júlia'),
('Administração adicionou encomenda de SilFér Cake', '2026-09-30 09:00:00', 5, 'Júlia'),
('Administração adicionou encomenda de Maria', '2026-09-30 09:00:00', 6, 'Júlia'),
('Administração adicionou encomenda de Isabella Araujo', '2026-10-01 09:00:00', 7, 'Júlia'),
('Administração adicionou encomenda de Stella', '2026-10-01 09:00:00', 8, 'Júlia'),
('Administração adicionou encomenda de Maria Isabel', '2026-09-30 09:00:00', 9, 'Júlia'),
('Administração adicionou encomenda de Alline Moura', '2026-09-29 09:00:00', 10, 'Júlia'),
('Administração adicionou encomenda de Lila', '2026-10-01 09:00:00', 11, 'Júlia'),
('Administração adicionou encomenda de Lila', '2026-10-01 09:00:00', 12, 'Júlia'),
('Administração adicionou encomenda de Isabella Araujo', '2026-10-01 09:00:00', 13, 'Júlia'),
('Administração adicionou encomenda de Camila VS', '2026-09-28 09:00:00', 14, 'Júlia'),
('Administração adicionou encomenda de Jéssica', '2026-10-01 09:00:00', 15, 'Júlia'),
('Administração adicionou encomenda de Julia Aveline', '2026-10-01 09:00:00', 16, 'Júlia'),
('Administração adicionou encomenda de Line Càrniele', '2026-09-30 09:00:00', 17, 'Júlia'),
('Administração adicionou encomenda de Line Càrniele', '2026-09-30 09:00:00', 18, 'Júlia'),
('Administração adicionou encomenda de Line Càrniele', '2026-09-30 09:00:00', 19, 'Júlia'),
('Administração adicionou encomenda de Naiara', '2026-10-01 09:00:00', 20, 'Júlia'),
('Administração adicionou encomenda de Fernanda Sissi', '2026-10-01 09:00:00', 21, 'Júlia'),
('Administração adicionou encomenda de Luizinho', '2026-10-02 09:00:00', 22, 'Júlia'),
('Administração adicionou encomenda de Andréa Kuniyoshi Miss Cake', '2026-10-02 09:00:00', 23, 'Júlia'),
('Administração adicionou encomenda de Milena', '2026-10-02 09:00:00', 24, 'Júlia'),
('Administração adicionou encomenda de Fernanda Sissi', '2026-10-02 09:00:00', 25, 'Júlia'),
('Administração adicionou encomenda de Renato Luciano', '2026-10-01 09:00:00', 26, 'Júlia'),
('Administração adicionou encomenda de Carol La Cakerie', '2026-10-01 09:00:00', 27, 'Júlia'),
('Administração adicionou encomenda de Michelle Tagliati', '2026-10-02 09:00:00', 28, 'Júlia'),
('Administração adicionou encomenda de Cristiane Diniz', '2026-10-01 09:00:00', 29, 'Júlia'),
('Administração adicionou encomenda de Alex', '2026-10-02 09:00:00', 30, 'Júlia'),
('Administração adicionou encomenda de Michele Micuca', '2026-09-25 09:00:00', 31, 'Júlia'),
('Administração adicionou encomenda de Michele Micuca', '2026-09-29 09:00:00', 32, 'Júlia'),
('Administração adicionou encomenda de Gah :) Clicô', '2026-09-28 09:00:00', 33, 'Júlia'),
('Administração adicionou encomenda de Gah :) Clicô', '2026-09-28 09:00:00', 34, 'Júlia'),
('Administração adicionou encomenda de Alessandra Italianinha', '2026-10-02 09:00:00', 35, 'Júlia'),
('Administração adicionou encomenda de Aline Masson', '2026-10-02 09:00:00', 36, 'Júlia'),
('Administração adicionou encomenda de Camila', '2026-09-21 09:00:00', 37, 'Júlia'),
('Administração adicionou encomenda de Isabela ️Passos', '2026-09-29 09:00:00', 38, 'Júlia'),
('Administração adicionou encomenda de ...', '2026-10-05 09:00:00', 39, 'Júlia'),
('Administração adicionou encomenda de Jéssica Algodão Doce', '2026-10-05 09:00:00', 40, 'Júlia'),
('Administração adicionou encomenda de Lila/Érika', '2026-10-05 09:00:00', 41, 'Júlia'),
('Administração adicionou encomenda de Raquel Cia dos Doces', '2026-10-05 09:00:00', 42, 'Júlia'),
('Administração adicionou encomenda de Raquel Cia dos Doces', '2026-10-05 09:00:00', 43, 'Júlia'),
('Administração adicionou encomenda de Raquel Cia dos Doces', '2026-10-05 09:00:00', 44, 'Júlia'),
('Administração adicionou encomenda de Bendito''S Cake - Luana Tamires', '2026-10-05 09:00:00', 45, 'Júlia'),
('Administração adicionou encomenda de Maria Luiza', '2026-10-05 09:00:00', 46, 'Júlia'),
('Administração adicionou encomenda de Paula Luiza', '2026-10-05 09:00:00', 47, 'Júlia'),
('Administração adicionou encomenda de Elian Oishi', '2026-10-05 09:00:00', 48, 'Júlia'),
('Administração adicionou encomenda de Fernando', '2026-10-06 09:00:00', 49, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-06 09:00:00', 50, 'Júlia'),
('Administração adicionou encomenda de Nil', '2026-09-23 09:00:00', 51, 'Júlia'),
('Administração adicionou encomenda de Nil', '2026-09-23 09:00:00', 52, 'Júlia'),
('Administração adicionou encomenda de Nil', '2026-09-24 09:00:00', 53, 'Júlia'),
('Administração adicionou encomenda de Nil', '2026-10-01 09:00:00', 54, 'Júlia'),
('Administração adicionou encomenda de Sandra', '2026-10-05 09:00:00', 55, 'Júlia'),
('Administração adicionou encomenda de Mari', '2026-10-06 09:00:00', 56, 'Júlia'),
('Administração adicionou encomenda de Mary', '2026-10-06 09:00:00', 57, 'Júlia'),
('Administração adicionou encomenda de Fernando', '2026-10-07 09:00:00', 58, 'Júlia'),
('Administração adicionou encomenda de Andréa Kuniyoshi Miss Cake', '2026-10-06 09:00:00', 59, 'Júlia'),
('Administração adicionou encomenda de Jéssica', '2026-10-06 09:00:00', 60, 'Júlia'),
('Administração adicionou encomenda de Dolce Nina', '2026-10-05 09:00:00', 61, 'Júlia'),
('Administração adicionou encomenda de Valquíria Fagundes', '2026-10-05 09:00:00', 62, 'Júlia'),
('Administração adicionou encomenda de Danielle Naves', '2026-10-06 09:00:00', 63, 'Júlia'),
('Administração adicionou encomenda de Dolce Nina', '2026-10-06 09:00:00', 64, 'Júlia'),
('Administração adicionou encomenda de Raquel', '2026-10-07 09:00:00', 65, 'Júlia'),
('Administração adicionou encomenda de Zane Teal Gaia', '2026-10-07 09:00:00', 66, 'Júlia'),
('Administração adicionou encomenda de Crislaine Liara', '2026-10-06 09:00:00', 67, 'Júlia'),
('Administração adicionou encomenda de Crislaine Liara', '2026-10-06 09:00:00', 68, 'Júlia'),
('Administração adicionou encomenda de Luciana', '2026-09-28 09:00:00', 69, 'Júlia'),
('Administração adicionou encomenda de Michele Micuca', '2026-10-08 09:00:00', 70, 'Júlia'),
('Administração adicionou encomenda de Camila Reinato', '2026-10-02 09:00:00', 71, 'Júlia'),
('Administração adicionou encomenda de Ana Carolinha Passafaro', '2026-10-06 09:00:00', 72, 'Júlia'),
('Administração adicionou encomenda de Ana Carolinha Passafaro', '2026-10-06 09:00:00', 73, 'Júlia'),
('Administração adicionou encomenda de Ana Carolinha Passafaro', '2026-10-08 09:00:00', 74, 'Júlia'),
('Administração adicionou encomenda de Melina Queiroz', '2026-10-02 09:00:00', 75, 'Júlia'),
('Administração adicionou encomenda de Fernanda', '2026-10-06 09:00:00', 76, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-10-06 09:00:00', 77, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-10-06 09:00:00', 78, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-10-06 09:00:00', 79, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-10-09 09:00:00', 80, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-10-09 09:00:00', 81, 'Júlia'),
('Administração adicionou encomenda de Camila Maria', '2026-10-08 09:00:00', 82, 'Júlia'),
('Administração adicionou encomenda de Bruna Silva', '2026-10-08 09:00:00', 83, 'Júlia'),
('Administração adicionou encomenda de Debby Cake', '2026-10-07 09:00:00', 84, 'Júlia'),
('Administração adicionou encomenda de Lidiane Costa', '2026-10-08 09:00:00', 85, 'Júlia'),
('Administração adicionou encomenda de Marli Costta', '2026-10-08 09:00:00', 86, 'Júlia'),
('Administração adicionou encomenda de Lidiane Costa', '2026-10-08 09:00:00', 87, 'Júlia'),
('Administração adicionou encomenda de Isabella Araujo', '2026-10-08 09:00:00', 88, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-09 09:00:00', 89, 'Júlia'),
('Administração adicionou encomenda de Debby Cake', '2026-10-07 09:00:00', 90, 'Júlia'),
('Administração adicionou encomenda de Amanda Lopes', '2026-10-08 09:00:00', 91, 'Júlia'),
('Administração adicionou encomenda de Ellen Cardoso', '2026-10-11 09:00:00', 92, 'Júlia'),
('Administração adicionou encomenda de Emanuelle Bergamin', '2026-10-10 09:00:00', 93, 'Júlia'),
('Administração adicionou encomenda de Isabella Araujo', '2026-10-08 09:00:00', 94, 'Júlia'),
('Administração adicionou encomenda de Gabi Bittencourt', '2026-10-09 09:00:00', 95, 'Júlia'),
('Administração adicionou encomenda de Valéria', '2026-10-09 09:00:00', 96, 'Júlia'),
('Administração adicionou encomenda de Soemmys Regina', '2026-10-09 09:00:00', 97, 'Júlia'),
('Administração adicionou encomenda de Tatiane Vilela', '2026-09-23 09:00:00', 98, 'Júlia'),
('Administração adicionou encomenda de Fernanda Sissi', '2026-10-10 09:00:00', 99, 'Júlia'),
('Administração adicionou encomenda de Lucas Fortunato', '2026-10-10 09:00:00', 100, 'Júlia'),
('Administração adicionou encomenda de Angelica alexandra', '2026-10-13 09:00:00', 101, 'Júlia'),
('Administração adicionou encomenda de Gih', '2026-10-14 09:00:00', 102, 'Júlia'),
('Administração adicionou encomenda de Aryane Dias', '2026-10-08 09:00:00', 103, 'Júlia'),
('Administração adicionou encomenda de Thaís', '2026-10-14 09:00:00', 104, 'Júlia'),
('Administração adicionou encomenda de Jana Pão De Mel', '2026-10-14 09:00:00', 105, 'Júlia'),
('Administração adicionou encomenda de Raquel Cia dos Bolos', '2026-10-13 09:00:00', 106, 'Júlia'),
('Administração adicionou encomenda de Larissa Ferrari', '2026-10-14 09:00:00', 107, 'Júlia'),
('Administração adicionou encomenda de Larissa Ferrari', '2026-10-14 09:00:00', 108, 'Júlia'),
('Administração adicionou encomenda de Jessica', '2026-10-08 09:00:00', 109, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-14 09:00:00', 110, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-14 09:00:00', 111, 'Júlia'),
('Administração adicionou encomenda de Fabrício - Leo Soldeira', '2026-10-14 09:00:00', 112, 'Júlia'),
('Administração adicionou encomenda de Angelica alexandra', '2026-10-14 09:00:00', 113, 'Júlia'),
('Administração adicionou encomenda de Angelica alexandra', '2026-10-14 09:00:00', 114, 'Júlia'),
('Administração adicionou encomenda de Raquel Pereira', '2026-10-15 09:00:00', 115, 'Júlia'),
('Administração adicionou encomenda de Marcia', '2026-10-15 09:00:00', 116, 'Júlia'),
('Administração adicionou encomenda de Thiago Borges', '2026-10-16 09:00:00', 117, 'Júlia'),
('Administração adicionou encomenda de Debby Cake', '2026-10-13 09:00:00', 118, 'Júlia'),
('Administração adicionou encomenda de Debby Cake', '2026-10-15 09:00:00', 119, 'Júlia'),
('Administração adicionou encomenda de Debby Cake', '2026-10-16 09:00:00', 120, 'Júlia'),
('Administração adicionou encomenda de Célia', '2026-10-13 09:00:00', 121, 'Júlia'),
('Administração adicionou encomenda de Danielle Naves', '2026-10-16 09:00:00', 122, 'Júlia'),
('Administração adicionou encomenda de Poly stelly', '2026-10-07 09:00:00', 123, 'Júlia'),
('Administração adicionou encomenda de Poly stelly', '2026-10-07 09:00:00', 124, 'Júlia'),
('Administração adicionou encomenda de Isabella Araujo', '2026-10-15 09:00:00', 125, 'Júlia'),
('Administração adicionou encomenda de Fernanda', '2026-09-25 09:00:00', 126, 'Júlia'),
('Administração adicionou encomenda de Marina', '2026-10-02 09:00:00', 127, 'Júlia'),
('Administração adicionou encomenda de Helen Freitas', '2026-10-14 09:00:00', 128, 'Júlia'),
('Administração adicionou encomenda de Zuzu Bolo Salgado', '2026-10-15 09:00:00', 129, 'Júlia'),
('Administração adicionou encomenda de Jackeline Domingues', '2026-10-16 09:00:00', 130, 'Júlia'),
('Administração adicionou encomenda de Camys', '2026-10-15 09:00:00', 131, 'Júlia'),
('Administração adicionou encomenda de Fabrício Brownies', '2026-10-16 09:00:00', 132, 'Júlia'),
('Administração adicionou encomenda de Isabella Araujo', '2026-10-15 09:00:00', 133, 'Júlia'),
('Administração adicionou encomenda de Laís Andrade', '2026-10-16 09:00:00', 134, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-16 09:00:00', 135, 'Júlia'),
('Administração adicionou encomenda de Duci Parmezani', '2026-10-16 09:00:00', 136, 'Júlia'),
('Administração adicionou encomenda de Duci Parmezani', '2026-10-16 09:00:00', 137, 'Júlia'),
('Administração adicionou encomenda de Jéssica Algodão Doce', '2026-10-16 09:00:00', 138, 'Júlia'),
('Administração adicionou encomenda de Mara Luciana', '2026-10-16 09:00:00', 139, 'Júlia'),
('Administração adicionou encomenda de Elisandra Cardoso', '2026-10-19 09:00:00', 140, 'Júlia'),
('Administração adicionou encomenda de Dayana Felipe', '2026-10-15 09:00:00', 141, 'Júlia'),
('Administração adicionou encomenda de MADZ', '2026-10-14 09:00:00', 142, 'Júlia'),
('Administração adicionou encomenda de MADZ', '2026-10-14 09:00:00', 143, 'Júlia'),
('Administração adicionou encomenda de MADZ', '2026-10-16 09:00:00', 144, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-10-19 09:00:00', 145, 'Júlia'),
('Administração adicionou encomenda de Lucas', '2026-10-19 09:00:00', 146, 'Júlia'),
('Administração adicionou encomenda de Doces Ferretti', '2026-10-20 09:00:00', 147, 'Júlia'),
('Administração adicionou encomenda de Andréa Meneguite', '2026-10-20 09:00:00', 148, 'Júlia'),
('Administração adicionou encomenda de Debby Cake', '2026-10-19 09:00:00', 149, 'Júlia'),
('Administração adicionou encomenda de Maristela Morango', '2026-10-20 09:00:00', 150, 'Júlia'),
('Administração adicionou encomenda de Gra Senna', '2026-10-20 09:00:00', 151, 'Júlia'),
('Administração adicionou encomenda de Dayana Felipe', '2026-10-20 09:00:00', 152, 'Júlia'),
('Administração adicionou encomenda de Núbia Leal', '2026-10-21 09:00:00', 153, 'Júlia'),
('Administração adicionou encomenda de Aline', '2026-10-20 09:00:00', 154, 'Júlia'),
('Administração adicionou encomenda de Lunara', '2026-09-01 09:00:00', 155, 'Júlia'),
('Administração adicionou encomenda de Amanda Lopes', '2026-10-21 09:00:00', 156, 'Júlia'),
('Administração adicionou encomenda de Silfér Cake', '2026-10-22 09:00:00', 157, 'Júlia'),
('Administração adicionou encomenda de Nil', '2026-10-12 09:00:00', 158, 'Júlia'),
('Administração adicionou encomenda de Paula', '2026-10-15 09:00:00', 159, 'Júlia'),
('Administração adicionou encomenda de Guilherme', '2026-10-16 09:00:00', 160, 'Júlia'),
('Administração adicionou encomenda de Bruno Peterson', '2026-10-22 09:00:00', 161, 'Júlia'),
('Administração adicionou encomenda de Akemi', '2026-10-20 09:00:00', 162, 'Júlia'),
('Administração adicionou encomenda de Akemi', '2026-10-20 09:00:00', 163, 'Júlia'),
('Administração adicionou encomenda de Fernanda Sissi', '2026-10-23 09:00:00', 164, 'Júlia'),
('Administração adicionou encomenda de Leylane Lopes', '2026-10-16 09:00:00', 165, 'Júlia'),
('Administração adicionou encomenda de Leylane Lopes', '2026-10-22 09:00:00', 166, 'Júlia'),
('Administração adicionou encomenda de Leylane Lopes', '2026-10-16 09:00:00', 167, 'Júlia'),
('Administração adicionou encomenda de Denise Doce Infância', '2026-10-20 09:00:00', 168, 'Júlia'),
('Administração adicionou encomenda de Denise Doce Infância', '2026-10-20 09:00:00', 169, 'Júlia'),
('Administração adicionou encomenda de Denise Doce Infância', '2026-10-20 09:00:00', 170, 'Júlia'),
('Administração adicionou encomenda de Sanae Kumagai', '2026-10-19 09:00:00', 171, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-10-19 09:00:00', 172, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-10-20 09:00:00', 173, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-10-23 09:00:00', 174, 'Júlia'),
('Administração adicionou encomenda de Dolce Nina', '2026-10-20 09:00:00', 175, 'Júlia'),
('Administração adicionou encomenda de Dolce Nina', '2026-10-20 09:00:00', 176, 'Júlia'),
('Administração adicionou encomenda de Dolce Nina', '2026-10-20 09:00:00', 177, 'Júlia'),
('Administração adicionou encomenda de Raquel Cia do Bolo', '2026-10-20 09:00:00', 178, 'Júlia'),
('Administração adicionou encomenda de Beatriz Amaral', '2026-10-21 09:00:00', 179, 'Júlia'),
('Administração adicionou encomenda de Ana Paula', '2026-10-22 09:00:00', 180, 'Júlia'),
('Administração adicionou encomenda de Jullia Pereira Aveline', '2026-10-22 09:00:00', 181, 'Júlia'),
('Administração adicionou encomenda de Larissa Oliveira', '2026-10-23 09:00:00', 182, 'Júlia'),
('Administração adicionou encomenda de Bia', '2026-10-22 09:00:00', 183, 'Júlia'),
('Administração adicionou encomenda de Giovana', '2026-10-22 09:00:00', 184, 'Júlia'),
('Administração adicionou encomenda de Hellen', '2026-10-22 09:00:00', 185, 'Júlia'),
('Administração adicionou encomenda de Dandrea', '2026-10-16 09:00:00', 186, 'Júlia'),
('Administração adicionou encomenda de Isabella Araujo', '2026-10-19 09:00:00', 187, 'Júlia'),
('Administração adicionou encomenda de Clarice Martins', '2026-10-22 09:00:00', 188, 'Júlia'),
('Administração adicionou encomenda de Dandrea', '2026-10-20 09:00:00', 189, 'Júlia'),
('Administração adicionou encomenda de Isabella Araujo', '2026-10-22 09:00:00', 190, 'Júlia'),
('Administração adicionou encomenda de Raquel', '2026-10-23 09:00:00', 191, 'Júlia'),
('Administração adicionou encomenda de Manuela Rocha', '2026-10-23 09:00:00', 192, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-20 09:00:00', 193, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-20 09:00:00', 194, 'Júlia'),
('Administração adicionou encomenda de Cidinha', '2026-10-22 09:00:00', 195, 'Júlia'),
('Administração adicionou encomenda de Debby Cake', '2026-10-24 09:00:00', 196, 'Júlia'),
('Administração adicionou encomenda de Willanys Silva', '2026-10-19 09:00:00', 197, 'Júlia'),
('Administração adicionou encomenda de Jana Pão de Mel', '2026-10-22 09:00:00', 198, 'Júlia'),
('Administração adicionou encomenda de Carol Machado La Cakery', '2026-10-22 09:00:00', 199, 'Júlia'),
('Administração adicionou encomenda de Raquel Cia do Bolo', '2026-10-22 09:00:00', 200, 'Júlia'),
('Administração adicionou encomenda de Sandra Nucci', '2026-10-21 09:00:00', 201, 'Júlia'),
('Administração adicionou encomenda de Joice', '2026-10-23 09:00:00', 202, 'Júlia'),
('Administração adicionou encomenda de Larissa', '2026-10-26 09:00:00', 203, 'Júlia'),
('Administração adicionou encomenda de Joana e Marta', '2026-10-26 09:00:00', 204, 'Júlia'),
('Administração adicionou encomenda de Isabella Araujo', '2026-10-23 09:00:00', 205, 'Júlia'),
('Administração adicionou encomenda de Isabella Araujo', '2026-10-26 09:00:00', 206, 'Júlia'),
('Administração adicionou encomenda de Eliane Doce Amor', '2026-10-26 09:00:00', 207, 'Júlia'),
('Administração adicionou encomenda de Guilherme Fabris', '2026-10-26 09:00:00', 208, 'Júlia'),
('Administração adicionou encomenda de Raquel Cia do Bolo', '2026-10-23 09:00:00', 209, 'Júlia'),
('Administração adicionou encomenda de Luana', '2026-10-26 09:00:00', 210, 'Júlia'),
('Administração adicionou encomenda de Marli Costta', '2026-10-26 09:00:00', 211, 'Júlia'),
('Administração adicionou encomenda de Aryza', '2026-10-28 09:00:00', 212, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-20 09:00:00', 213, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-20 09:00:00', 214, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-20 09:00:00', 215, 'Júlia'),
('Administração adicionou encomenda de Akemi', '2026-10-20 09:00:00', 216, 'Júlia'),
('Administração adicionou encomenda de Akemi', '2026-10-20 09:00:00', 217, 'Júlia'),
('Administração adicionou encomenda de Michelle Tagliati', '2026-10-29 09:00:00', 218, 'Júlia'),
('Administração adicionou encomenda de Anacleto Coquetéis', '2026-09-29 09:00:00', 219, 'Júlia'),
('Administração adicionou encomenda de Daniele', '2026-10-22 09:00:00', 220, 'Júlia'),
('Administração adicionou encomenda de Carol Tito', '2026-10-26 09:00:00', 221, 'Júlia'),
('Administração adicionou encomenda de Dolce Nina', '2026-10-27 09:00:00', 222, 'Júlia'),
('Administração adicionou encomenda de Dolce Nina', '2026-10-27 09:00:00', 223, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-10-27 09:00:00', 224, 'Júlia'),
('Administração adicionou encomenda de Caroline Boriolo', '2026-10-01 09:00:00', 225, 'Júlia'),
('Administração adicionou encomenda de Raquel Cia do Bolo', '2026-10-23 09:00:00', 226, 'Júlia'),
('Administração adicionou encomenda de Michelle Tagliati', '2026-10-28 09:00:00', 227, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-29 09:00:00', 228, 'Júlia'),
('Administração adicionou encomenda de Debby Cake', '2026-10-19 09:00:00', 229, 'Júlia'),
('Administração adicionou encomenda de Duci Parmezani', '2026-10-29 09:00:00', 230, 'Júlia'),
('Administração adicionou encomenda de Duci Parmezani', '2026-10-29 09:00:00', 231, 'Júlia'),
('Administração adicionou encomenda de Duci Parmezani', '2026-10-29 09:00:00', 232, 'Júlia'),
('Administração adicionou encomenda de Gabriel Lima Pixel Print', '2026-10-23 09:00:00', 233, 'Júlia'),
('Administração adicionou encomenda de Raquel Cia do Bolo', '2026-10-23 09:00:00', 234, 'Júlia'),
('Administração adicionou encomenda de Chef Maria Lúcia', '2026-10-29 09:00:00', 235, 'Júlia'),
('Administração adicionou encomenda de Lila/Carla', '2026-10-28 09:00:00', 236, 'Júlia'),
('Administração adicionou encomenda de Cidinha', '2026-10-30 09:00:00', 237, 'Júlia'),
('Administração adicionou encomenda de Cidinha', '2026-10-30 09:00:00', 238, 'Júlia'),
('Administração adicionou encomenda de Bruna Silva', '2026-10-29 09:00:00', 239, 'Júlia'),
('Administração adicionou encomenda de Antonia VS', '2026-10-01 09:00:00', 240, 'Júlia'),
('Administração adicionou encomenda de Antonia VS', '2026-10-01 09:00:00', 241, 'Júlia'),
('Administração adicionou encomenda de Antonia VS', '2026-10-01 09:00:00', 242, 'Júlia'),
('Administração adicionou encomenda de Antonia VS', '2026-10-01 09:00:00', 243, 'Júlia'),
('Administração adicionou encomenda de Antonia VS', '2026-10-01 09:00:00', 244, 'Júlia'),
('Administração adicionou encomenda de Antonia VS', '2026-10-01 09:00:00', 245, 'Júlia'),
('Administração adicionou encomenda de Carol Barros', '2026-10-27 09:00:00', 246, 'Júlia'),
('Administração adicionou encomenda de Camila Rosado', '2026-10-30 09:00:00', 247, 'Júlia'),
('Administração adicionou encomenda de Joana e Marta', '2026-10-26 09:00:00', 248, 'Júlia'),
('Administração adicionou encomenda de Midiã', '2026-10-28 09:00:00', 249, 'Júlia'),
('Administração adicionou encomenda de Jak Motta', '2026-10-20 09:00:00', 250, 'Júlia'),
('Administração adicionou encomenda de Gabby Bolos', '2026-10-30 09:00:00', 251, 'Júlia'),
('Administração adicionou encomenda de Ana Luiza Vila Do Figo', '2026-11-01 09:00:00', 252, 'Júlia'),
('Administração adicionou encomenda de Angélica', '2026-10-27 09:00:00', 253, 'Júlia'),
('Administração adicionou encomenda de Renata Silva', '2026-11-04 09:00:00', 254, 'Júlia'),
('Administração adicionou encomenda de Kariny Queiroz', '2026-10-26 09:00:00', 255, 'Júlia'),
('Administração adicionou encomenda de Camila Reinato', '2026-09-30 09:00:00', 256, 'Júlia'),
('Administração adicionou encomenda de Thais Fonseca', '2026-10-21 09:00:00', 257, 'Júlia'),
('Administração adicionou encomenda de Neusa', '2026-11-03 09:00:00', 258, 'Júlia'),
('Administração adicionou encomenda de Debby Cake', '2026-11-17 09:00:00', 259, 'Júlia'),
('Administração adicionou encomenda de Debby Cake', '2026-11-17 09:00:00', 260, 'Júlia'),
('Administração adicionou encomenda de Rodrigo', '2026-11-16 09:00:00', 261, 'Júlia'),
('Administração adicionou encomenda de Café com Caramelo', '2026-11-18 09:00:00', 262, 'Júlia'),
('Administração adicionou encomenda de Jefferson', '2026-11-17 09:00:00', 263, 'Júlia'),
('Administração adicionou encomenda de Danielle Naves', '2026-11-18 09:00:00', 264, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-11-17 09:00:00', 265, 'Júlia'),
('Administração adicionou encomenda de Genifer Rocha', '2026-11-17 09:00:00', 266, 'Júlia'),
('Administração adicionou encomenda de Glaucia Carvalho', '2026-11-12 09:00:00', 267, 'Júlia'),
('Administração adicionou encomenda de Renan Guimarães', '2026-11-10 09:00:00', 268, 'Júlia'),
('Administração adicionou encomenda de I-medic', '2026-11-16 09:00:00', 269, 'Júlia'),
('Administração adicionou encomenda de Julia Pereira Aveline', '2026-11-18 09:00:00', 270, 'Júlia'),
('Administração adicionou encomenda de Salette Rodrigues', '2026-11-20 09:00:00', 271, 'Júlia'),
('Administração adicionou encomenda de Maya', '2026-11-19 09:00:00', 272, 'Júlia'),
('Administração adicionou encomenda de Angélica', '2026-10-27 09:00:00', 273, 'Júlia'),
('Administração adicionou encomenda de Chef Maria Lúcia', '2026-11-11 09:00:00', 274, 'Júlia'),
('Administração adicionou encomenda de Gislaine', '2026-11-04 09:00:00', 275, 'Júlia'),
('Administração adicionou encomenda de Maria Helena', '2026-11-10 09:00:00', 276, 'Júlia'),
('Administração adicionou encomenda de Andréa Kuniyoshi', '2026-11-16 09:00:00', 277, 'Júlia'),
('Administração adicionou encomenda de Chef Maria Lúcia', '2026-11-05 09:00:00', 278, 'Júlia'),
('Administração adicionou encomenda de Sheyla', '2026-11-09 09:00:00', 279, 'Júlia'),
('Administração adicionou encomenda de Lila/ Carol', '2026-11-17 09:00:00', 280, 'Júlia');


-- ------------------------------------------------------------
-- Clientes com conta no site, pedidos feitos pelo site, favoritos e feedbacks
-- (cobrem as chaves estrangeiras de login, pedidos.id_usuario, itens_pedido.id_produto,
--  favoritos e feedbacks). Contas de teste: a senha de todas é cliente123
-- ------------------------------------------------------------
INSERT INTO login (telefone, email, senha, data_cadastro) VALUES
('19 98811-2030', 'ana.souza@email.com',     '$2y$10$dnmKk026K1YEVh4vMT07hOIvJ38fICE2GQK3xj40Dz8ggStWGaLde', '2026-10-02 14:12:00'),
('19 99230-4411', 'bruno.lima@email.com',    '$2y$10$dnmKk026K1YEVh4vMT07hOIvJ38fICE2GQK3xj40Dz8ggStWGaLde', '2026-10-05 09:40:00'),
('19 97145-8820', 'carla.mendes@email.com',  '$2y$10$dnmKk026K1YEVh4vMT07hOIvJ38fICE2GQK3xj40Dz8ggStWGaLde', '2026-10-11 20:05:00'),
('19 98402-6613', 'daniela.rocha@email.com', '$2y$10$dnmKk026K1YEVh4vMT07hOIvJ38fICE2GQK3xj40Dz8ggStWGaLde', '2026-10-18 16:30:00'),
('19 99671-0094', 'eduardo.alves@email.com', '$2y$10$dnmKk026K1YEVh4vMT07hOIvJ38fICE2GQK3xj40Dz8ggStWGaLde', '2026-10-25 11:22:00'),
('19 98123-5578', 'fernanda.dias@email.com', '$2y$10$dnmKk026K1YEVh4vMT07hOIvJ38fICE2GQK3xj40Dz8ggStWGaLde', '2026-11-01 18:47:00'),
('19 99512-3369', 'gabriela.reis@email.com', '$2y$10$dnmKk026K1YEVh4vMT07hOIvJ38fICE2GQK3xj40Dz8ggStWGaLde', '2026-11-06 10:15:00'),
('19 97788-4102', 'henrique.costa@email.com','$2y$10$dnmKk026K1YEVh4vMT07hOIvJ38fICE2GQK3xj40Dz8ggStWGaLde', '2026-11-12 21:03:00');

-- Pedidos feitos pelo site (ficam com os números 281 a 288)
INSERT INTO pedidos (id_usuario, criado_por, cliente, telefone, email, forma_entrega, endereco, data_pedido, prazo, pago, pronto, buscou, observacoes) VALUES
(1, 'site', 'Ana Souza',       '19 98811-2030', 'ana.souza@email.com',      'retirada', NULL, '2026-10-06 15:20:00', '2026-10-15', 1, 1, 1, NULL),
(2, 'site', 'Bruno Lima',      '19 99230-4411', 'bruno.lima@email.com',     'entrega',  'Rua Barão de Jaguara, 1200 - Centro, Campinas', '2026-10-09 10:02:00', '2026-10-20', 1, 1, 1, NULL),
(3, 'site', 'Carla Mendes',    '19 97145-8820', 'carla.mendes@email.com',   'retirada', NULL, '2026-10-20 19:45:00', '2026-10-31', 1, 1, 1, NULL),
(1, 'site', 'Ana Souza',       '19 98811-2030', 'ana.souza@email.com',      'retirada', NULL, '2026-11-03 08:55:00', '2026-11-14', 1, 1, 0, NULL),
(4, 'site', 'Daniela Rocha',   '19 98402-6613', 'daniela.rocha@email.com',  'entrega',  'Av. Orosimbo Maia, 450 - Cambuí, Campinas', '2026-11-08 14:10:00', '2026-11-21', 1, 0, 0, NULL),
(5, 'site', 'Eduardo Alves',   '19 99671-0094', 'eduardo.alves@email.com',  'retirada', NULL, '2026-11-14 17:33:00', '2026-11-28', 0, 0, 0, NULL),
(6, 'site', 'Fernanda Dias',   '19 98123-5578', 'fernanda.dias@email.com',  'retirada', NULL, '2026-11-16 12:08:00', '2026-11-30', 1, 0, 0, NULL),
(7, 'site', 'Gabriela Reis',   '19 99512-3369', 'gabriela.reis@email.com',  'entrega',  'Rua Coronel Quirino, 980 - Cambuí, Campinas', '2026-11-19 09:27:00', '2026-12-03', 0, 0, 0, NULL);

INSERT INTO itens_pedido (id_pedido, id_produto, produto, valor, quantidade, tema, tamanho, idade, nome_escrito, cor, observacoes, precisa_arte) VALUES
(281, 1, 'Topper simples Toy Story',          22.00, 1,  'Toy Story',        NULL,    '5 anos', 'Theo',   NULL,     NULL, 0),
(281, 3, 'Caixinha dedeira',                   8.00, 20, 'Toy Story',        NULL,    '5 anos', 'Theo',   NULL,     NULL, 0),
(282, 6, 'Caneca personalizada',              38.00, 2,  'Mulher-Maravilha', NULL,    NULL,     'Bia',    'Rosa',   NULL, 0),
(283, 4, 'Papel arroz para envelopar',        17.00, 1,  'Stitch',           '20 cm', '3 anos', 'Lara',   NULL,     NULL, 0),
(283, 2, 'Flores de papel para bolo',         35.00, 1,  'Flores',           NULL,    NULL,     NULL,     'Rosa',   'Tons claros', 0),
(284, 5, 'Papel arroz recortado para drinks', 20.00, 2,  'Casamento',        NULL,    NULL,     'Ana & Léo', NULL,  NULL, 1),
(285, 1, 'Topper simples Toy Story',          22.00, 1,  'Toy Story',        NULL,    '4 anos', 'Miguel', NULL,     NULL, 0),
(286, 3, 'Caixinha dedeira',                   8.00, 30, 'Masha e o Urso',   NULL,    '2 anos', 'Alice',  NULL,     NULL, 1),
(287, 2, 'Flores de papel para bolo',         35.00, 1,  'Flores',           NULL,    NULL,     NULL,     'Dourado', NULL, 0),
(288, 6, 'Caneca personalizada',              38.00, 1,  'Mulher-Maravilha', NULL,    NULL,     'Gabi',   'Rosa',   NULL, 1);

INSERT INTO historico (descricao, data_hora, id_pedido, autor) VALUES
('Ana Souza solicitou encomenda',     '2026-10-06 15:20:00', 281, NULL),
('Bruno Lima solicitou encomenda',    '2026-10-09 10:02:00', 282, NULL),
('Carla Mendes solicitou encomenda',  '2026-10-20 19:45:00', 283, NULL),
('Ana Souza solicitou encomenda',     '2026-11-03 08:55:00', 284, NULL),
('Daniela Rocha solicitou encomenda', '2026-11-08 14:10:00', 285, NULL),
('Eduardo Alves solicitou encomenda', '2026-11-14 17:33:00', 286, NULL),
('Fernanda Dias solicitou encomenda', '2026-11-16 12:08:00', 287, NULL),
('Gabriela Reis solicitou encomenda', '2026-11-19 09:27:00', 288, NULL);

INSERT INTO favoritos (id_usuario, id_produto, data_favorito) VALUES
(1, 1, '2026-10-02 14:20:00'), (1, 3, '2026-10-02 14:22:00'), (1, 5, '2026-11-02 19:10:00'),
(2, 6, '2026-10-05 09:45:00'), (2, 2, '2026-10-07 13:00:00'),
(3, 4, '2026-10-11 20:10:00'), (3, 2, '2026-10-11 20:12:00'), (3, 1, '2026-10-19 08:30:00'),
(4, 1, '2026-10-18 16:35:00'), (4, 6, '2026-10-30 10:05:00'),
(5, 3, '2026-10-25 11:30:00'),
(6, 2, '2026-11-01 18:50:00'), (6, 4, '2026-11-01 18:52:00'),
(7, 6, '2026-11-06 10:20:00'), (7, 2, '2026-11-15 15:40:00'),
(8, 1, '2026-11-12 21:10:00');

INSERT INTO feedbacks (id_usuario, estrelas, mensagem, data_hora) VALUES
(1, 5, 'O topper ficou lindo, igualzinho ao que eu pedi!', '2026-10-16 10:12:00'),
(2, 5, 'Canecas chegaram bem embaladas e no prazo.', '2026-10-21 18:40:00'),
(3, 4, 'Papel arroz perfeito, só demorou um pouco para responder no WhatsApp.', '2026-11-01 09:05:00'),
(NULL, 5, 'Atendimento muito atencioso, recomendo.', '2026-11-04 14:30:00'),
(4, 3, 'Gostei do produto, mas queria mais opções de cores.', '2026-11-10 20:15:00'),
(NULL, 4, 'Site fácil de usar.', '2026-11-12 11:48:00'),
(6, 5, 'As flores de papel deixaram o bolo maravilhoso!', '2026-11-18 16:02:00'),
(1, 5, 'Segunda compra e de novo tudo perfeito.', '2026-11-20 08:37:00');


-- ============================================================
-- 6) CONSULTAS DOCUMENTADAS E DEMONSTRAÇÕES
-- (só leem dados ou usam transação; pode apagar esta parte se quiser só o banco)
-- ============================================================

-- ------------------------------------------------------------
-- CONSULTA 1 - JOIN com 5 tabelas
-- Uso pretendido: tela de conferência das compras feitas pelo site, mostrando
-- a conta do cliente, o produto comprado e a categoria do produto.
-- ------------------------------------------------------------
SELECT p.id AS pedido, l.email AS conta_cliente, p.data_pedido,
       i.produto, t.nome AS categoria, i.quantidade, i.valor * i.quantidade AS total_item
FROM pedidos p
JOIN login l ON l.id = p.id_usuario
JOIN itens_pedido i ON i.id_pedido = p.id
JOIN produtos pr ON pr.id = i.id_produto
LEFT JOIN topicos t ON t.id = pr.id_topico
ORDER BY p.data_pedido DESC;

-- ------------------------------------------------------------
-- CONSULTA 2 - JOIN com 2 tabelas
-- Uso pretendido: lista de produção da Júlia com as encomendas ainda não entregues
-- que estão esperando o cliente enviar a arte (filtro "Enviar arte" do painel).
-- ------------------------------------------------------------
SELECT p.id AS pedido, p.cliente, p.telefone, p.prazo, i.produto, i.tema
FROM pedidos p
JOIN itens_pedido i ON i.id_pedido = p.id
WHERE i.precisa_arte = 1
  AND (i.arte IS NULL OR i.arte = '')
  AND p.buscou = 0
ORDER BY p.prazo;

-- ------------------------------------------------------------
-- CONSULTA 3 - GROUP BY + HAVING
-- Uso pretendido: identificar clientes recorrentes (3 pedidos ou mais) para ações de
-- fidelização, como desconto ou brinde na próxima compra.
-- ------------------------------------------------------------
SELECT cliente, telefone, COUNT(*) AS qtd_pedidos, MAX(data_pedido) AS ultimo_pedido
FROM pedidos
GROUP BY cliente, telefone
HAVING COUNT(*) >= 3
ORDER BY qtd_pedidos DESC;

-- ------------------------------------------------------------
-- CONSULTA 4 - Subconsulta com NOT EXISTS
-- Uso pretendido: encontrar clientes que criaram conta no site mas nunca fizeram um pedido,
-- para a Júlia mandar uma mensagem de incentivo à primeira compra.
-- ------------------------------------------------------------
SELECT l.id, l.email, l.telefone, l.data_cadastro
FROM login l
WHERE NOT EXISTS (SELECT 1 FROM pedidos p WHERE p.id_usuario = l.id);

-- ------------------------------------------------------------
-- CONSULTA 5 - Subconsulta com IN
-- Uso pretendido: mostrar os produtos que estão nos favoritos de clientes que já compraram
-- no site (produtos com maior chance de nova compra, bons para divulgar).
-- ------------------------------------------------------------
SELECT pr.id, pr.nome, pr.preco
FROM produtos pr
WHERE pr.id IN (SELECT f.id_produto
                FROM favoritos f
                WHERE f.id_usuario IN (SELECT id_usuario FROM pedidos WHERE id_usuario IS NOT NULL));

-- ------------------------------------------------------------
-- CONSULTA 6 - Funções de agregação + ordenação
-- Uso pretendido: ranking dos produtos que mais faturaram, para a Júlia saber
-- onde concentrar a produção e a divulgação.
-- ------------------------------------------------------------
SELECT i.produto,
       COUNT(DISTINCT i.id_pedido) AS pedidos,
       SUM(i.quantidade) AS unidades,
       SUM(i.valor * i.quantidade) AS faturamento,
       ROUND(AVG(i.valor), 2) AS preco_medio
FROM itens_pedido i
GROUP BY i.produto
ORDER BY faturamento DESC
LIMIT 10;

-- ------------------------------------------------------------
-- CONSULTA 7 - Filtro por intervalo de datas
-- Uso pretendido: agenda da semana, com as encomendas que vencem entre duas datas e ainda
-- não foram entregues. No sistema, as datas seriam CURDATE() e CURDATE() + 7 dias.
-- ------------------------------------------------------------
SELECT p.id AS pedido, p.cliente, p.prazo, fn_status_pedido(p.id) AS situacao,
       fn_total_pedido(p.id) AS total
FROM pedidos p
WHERE p.prazo BETWEEN '2026-11-23' AND '2026-11-30'
  AND p.buscou = 0
ORDER BY p.prazo;

-- ------------------------------------------------------------
-- CONSULTA 8 - Filtro por intervalo de valores
-- Uso pretendido: encontrar pedidos de valor alto (entre R$ 100 e R$ 500) para
-- a Júlia pedir sinal/entrada antes de começar a produção.
-- ------------------------------------------------------------
SELECT p.id AS pedido, p.cliente, p.data_pedido, fn_total_pedido(p.id) AS total
FROM pedidos p
WHERE fn_total_pedido(p.id) BETWEEN 100 AND 500
ORDER BY total DESC;


-- ------------------------------------------------------------
-- USO DAS VIEWS
-- ------------------------------------------------------------
SELECT * FROM vw_relatorio_vendas_mensal ORDER BY mes;
SELECT id_pedido, cliente, produto, total FROM vw_encomendas_painel WHERE pago = 0 LIMIT 10;
SELECT id, nome, preco, categoria FROM vw_produtos_loja WHERE categoria = 'Topper';
SELECT * FROM vw_clientes_seguro;
SELECT * FROM vw_administradores_seguro;


-- ------------------------------------------------------------
-- USO DAS FUNÇÕES E PROCEDURES
-- ------------------------------------------------------------
SELECT fn_total_pedido(281) AS total_281, fn_status_pedido(281) AS status_281,
       fn_status_pedido(288) AS status_288;

CALL sp_relatorio_vendas('2026-10-01', '2026-10-31');


-- ------------------------------------------------------------
-- DEMONSTRAÇÃO DE TRANSAÇÃO (falha e recuperação)
--
-- Isolamento escolhido: REPEATABLE READ (o padrão do InnoDB).
--   - Dentro da transação, as leituras normais enxergam sempre o mesmo "retrato" dos dados,
--     evitando leitura suja (dirty read) e leitura não repetível (non-repeatable read).
--   - Na baixa de estoque (sp_baixar_estoque) a linha do produto é lida com SELECT ... FOR UPDATE:
--     ela fica travada até o COMMIT/ROLLBACK, o que evita a "atualização perdida" (lost update),
--     ou seja, duas pessoas comprando a mesma última unidade ao mesmo tempo.
--   - O READ COMMITTED também serviria, mas o REPEATABLE READ dá leituras consistentes
--     durante a compra inteira sem custo extra neste sistema (poucos acessos simultâneos).
--
-- sp_demonstrar_transacao faz a compra de um pedido do site:
--   START TRANSACTION -> INSERT pedido -> INSERT item -> baixa de estoque -> INSERT histórico -> COMMIT
-- Com p_forcar_erro = 1, o segundo item é gravado com quantidade 0, o CHECK
-- ck_itens_pedido_quantidade falha, o handler captura o erro e faz ROLLBACK:
-- o pedido e o primeiro item, que já tinham sido inseridos, são desfeitos.
-- ------------------------------------------------------------
DELIMITER $$
DROP PROCEDURE IF EXISTS sp_demonstrar_transacao$$
CREATE PROCEDURE sp_demonstrar_transacao(IN p_forcar_erro TINYINT)
BEGIN
    DECLARE v_erro INT DEFAULT 0;
    DECLARE v_mensagem VARCHAR(255) DEFAULT '';
    DECLARE v_pedidos_antes INT;
    DECLARE v_id_pedido INT;

    -- Se qualquer comando falhar, anota o erro e continua até o IF do final
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_mensagem = MESSAGE_TEXT;
        SET v_erro = 1;
    END;

    SELECT COUNT(*) INTO v_pedidos_antes FROM pedidos;

    START TRANSACTION;

    INSERT INTO pedidos (id_usuario, criado_por, cliente, telefone, email, forma_entrega, data_pedido, prazo)
    VALUES (8, 'site', 'Henrique Costa', '19 97788-4102', 'henrique.costa@email.com',
            'retirada', NOW(), DATE_ADD(CURDATE(), INTERVAL 10 DAY));
    SET v_id_pedido = LAST_INSERT_ID();

    IF v_erro = 0 THEN
        INSERT INTO itens_pedido (id_pedido, id_produto, produto, valor, quantidade, tema)
        VALUES (v_id_pedido, 1, 'Topper simples Toy Story', 22.00, 1, 'Toy Story');
        CALL sp_baixar_estoque(1, 1);
    END IF;

    IF v_erro = 0 THEN
        INSERT INTO itens_pedido (id_pedido, id_produto, produto, valor, quantidade, tema)
        VALUES (v_id_pedido, 3, 'Caixinha dedeira', 8.00,
                IF(p_forcar_erro = 1, 0, 10), 'Toy Story');
    END IF;

    IF v_erro = 0 THEN
        CALL sp_registrar_historico('Henrique Costa solicitou encomenda', v_id_pedido, NULL);
    END IF;

    IF v_erro = 1 THEN
        ROLLBACK;
        SELECT 'ROLLBACK' AS resultado, v_mensagem AS erro_capturado,
               v_pedidos_antes AS pedidos_antes,
               (SELECT COUNT(*) FROM pedidos) AS pedidos_depois,
               (SELECT COUNT(*) FROM itens_pedido WHERE id_pedido = v_id_pedido) AS itens_que_ficaram;
    ELSE
        COMMIT;
        SELECT 'COMMIT' AS resultado, v_id_pedido AS pedido_gravado,
               v_pedidos_antes AS pedidos_antes,
               (SELECT COUNT(*) FROM pedidos) AS pedidos_depois,
               fn_total_pedido(v_id_pedido) AS total;
    END IF;
END$$
DELIMITER ;

SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

-- Falha e recuperação: o resultado mostra ROLLBACK e pedidos_antes = pedidos_depois
CALL sp_demonstrar_transacao(1);
-- Caminho de sucesso (grava um pedido de verdade): CALL sp_demonstrar_transacao(0);


-- ------------------------------------------------------------
-- DEMONSTRAÇÃO DOS TRIGGERS
-- ------------------------------------------------------------

-- Auditoria de alteração: o pedido 286 foi pago e ficou pronto
SET @usuario_painel = 'Júlia';
UPDATE pedidos SET pago = 1, pronto = 1 WHERE id = 286;
SET @usuario_painel = NULL;
SELECT * FROM log_pedidos WHERE id_pedido = 286;

-- Auditoria de exclusão (dentro de uma transação desfeita no final, para não perder o pedido de exemplo)
START TRANSACTION;
SET @usuario_painel = 'Júlia';
DELETE FROM pedidos WHERE id = 288;
SELECT * FROM log_pedidos WHERE id_pedido = 288;
ROLLBACK;
SET @usuario_painel = NULL;

-- Integridade: o comando abaixo é BLOQUEADO pelo trigger trg_produtos_impedir_exclusao.
-- Rode sozinho para ver o erro:
--   DELETE FROM produtos WHERE id = 1;
--   -> #1644 - Produto já vendido não pode ser excluído. Desative o produto no painel.
