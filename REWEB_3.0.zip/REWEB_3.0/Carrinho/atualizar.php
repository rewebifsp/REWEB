<?php
// Muda a quantidade de um item do carrinho ou remove o item.
// Quem chama são os botões "-", "+" e "Remover" da tela do carrinho.
@session_start();
require('../Adiministracao/conexao.php');

$indice = isset($_POST['indice']) ? (int) $_POST['indice'] : -1;
$acao = isset($_POST['acao']) ? $_POST['acao'] : '';

// Só mexe se esse item existir no carrinho
if (isset($_SESSION['carrinho'][$indice])) {

    if ($acao == 'mais') {
        $quantidadeNova = $_SESSION['carrinho'][$indice]['quantidade'] + 1;

        // Produto de pronta entrega: não deixa pedir mais do que tem no estoque
        $stmt = $con->prepare("SELECT tipo, estoque FROM produtos WHERE id = ?");
        $stmt->bind_param("i", $_SESSION['carrinho'][$indice]['id_produto']);
        $stmt->execute();
        $produto = mysqli_fetch_assoc($stmt->get_result());

        $passouDoEstoque = $produto && $produto['tipo'] == 'pronta_entrega' && $quantidadeNova > $produto['estoque'];

        if (!$passouDoEstoque) {
            $_SESSION['carrinho'][$indice]['quantidade'] = $quantidadeNova;
        }
    }

    // A quantidade nunca fica menor que 1
    if ($acao == 'menos' && $_SESSION['carrinho'][$indice]['quantidade'] > 1) {
        $_SESSION['carrinho'][$indice]['quantidade']--;
    }

    if ($acao == 'remover') {
        unset($_SESSION['carrinho'][$indice]);
        $_SESSION['carrinho'] = array_values($_SESSION['carrinho']); // reorganiza os números da lista
    }
}

header('Location: carrinho.php');
exit;
