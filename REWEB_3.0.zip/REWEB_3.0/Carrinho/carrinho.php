<?php
// Esta página está dentro da pasta Carrinho, então o site principal fica uma pasta acima
$raiz = '../';

@session_start();
require('../Includes/funcoes.php');

// O carrinho fica guardado na sessão, por isso funciona mesmo sem conta.
// Ele sobrevive ao F5, mas some quando a pessoa fecha o navegador.
$itens = [];
if (isset($_SESSION['carrinho'])) {
    $itens = $_SESSION['carrinho'];
}

// Soma o valor de todos os itens para mostrar no resumo
$subtotal = 0;
foreach ($itens as $item) {
    $subtotal = $subtotal + $item['preco'] * $item['quantidade'];
}

// Por enquanto não existem adicionais nem taxa de serviço
$adicionais = 0;

// PEDIDOS JÁ CONFIRMADOS: quando a pessoa confirma o pedido, os itens saem do carrinho
// (senão dava para pagar duas vezes) e passam a viver no banco. Aqui eles voltam para a tela,
// cada um com o status que a Júlia atualiza no painel. Só quem tem conta tem pedidos.
$pedidos = [];
if (isset($_SESSION['usuario']) && $_SESSION['usuario']['tipo'] == 'cliente') {
    require('../Adiministracao/conexao.php');

    $idUsuario = $_SESSION['usuario']['id'];

    $stmt = $con->prepare(
        "SELECT p.id AS id_pedido, p.data_pedido, p.forma_entrega, p.prazo, p.pago, p.pronto, p.buscou, p.status, p.criado_por,
                i.produto, i.valor, i.quantidade, i.tema, i.tamanho, i.idade, i.nome_escrito, i.cor, i.observacoes,
                pr.foto1, pr.especificacoes
         FROM pedidos p
         JOIN itens_pedido i ON i.id_pedido = p.id
         LEFT JOIN produtos pr ON pr.id = i.id_produto
         WHERE p.id_usuario = ?
         ORDER BY p.id DESC, i.id ASC"
    );
    $stmt->bind_param("i", $idUsuario);
    $stmt->execute();
    $resultado = $stmt->get_result();

    // Junta os itens de cada pedido (o status é do pedido inteiro)
    while ($linha = mysqli_fetch_assoc($resultado)) {
        $numero = $linha['id_pedido'];

        if (!isset($pedidos[$numero])) {
            $pedidos[$numero] = [
                'id' => $numero,
                'data' => $linha['data_pedido'],
                'prazo' => $linha['prazo'],
                'pago' => $linha['pago'],
                'status' => statusDoPedido($linha),
                'total' => 0,
                'itens' => []
            ];
        }

        $pedidos[$numero]['total'] += $linha['valor'] * $linha['quantidade'];
        $pedidos[$numero]['itens'][] = $linha;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho - Corisco's Paper</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="../Includes/cabecalho.css">
    <link rel="stylesheet" href="Css/carrinho.css">
</head>

<body>

    <?php include('../Includes/cabecalho.php'); ?>

    <main class="pagina-carrinho">

        <?php if (count($itens) == 0 && count($pedidos) == 0) { ?>

            <!-- Carrinho sem nenhum item e sem nenhum pedido -->
            <p class="carrinho-vazio">Seu carrinho está vazio.</p>
            <a class="continuar" href="../index.php">Continuar comprando</a>

        <?php } ?>

        <?php if (count($itens) == 0 && count($pedidos) > 0) { ?>
            <p class="aviso-carrinho">Nenhum item novo no carrinho. <a href="../index.php">Continuar comprando</a></p>
        <?php } ?>

        <?php if (count($itens) > 0) { ?>

            <!-- Um bloco para cada item do carrinho -->
            <?php foreach ($itens as $indice => $item) { ?>

                <article class="item-carrinho">

                    <div class="item-esquerda">
                        <img class="foto-item" src="<?php echo $raiz . escapar($item['foto']); ?>" alt="<?php echo escapar($item['nome']); ?>">

                        <div class="item-textos">
                            <h2><?php echo escapar($item['nome']); ?></h2>
                            <p class="descricao"><?php echo escapar($item['especificacoes']); ?></p>
                        </div>
                    </div>

                    <ul class="detalhes">
                        <li>Nome: <?php echo escapar($item['nome_escrito']); ?></li>
                        <li>Idade: <?php echo escapar($item['idade']); ?></li>
                        <li>Tamanho e formato do bolo: <?php echo escapar($item['tamanho']); ?></li>
                        <li>Obs: <?php echo escapar($item['observacoes']); ?></li>
                        <?php if ($item['cor'] != '') { ?>
                            <li>Cor: <?php echo escapar($item['cor']); ?></li>
                        <?php } ?>
                    </ul>

                    <!-- Quantidade: os botões enviam para o atualizar.php, que muda o carrinho na sessão -->
                    <form class="contador" action="atualizar.php" method="post">
                        <input type="hidden" name="indice" value="<?php echo $indice; ?>">
                        <button name="acao" value="menos" type="submit" aria-label="Diminuir quantidade">-</button>
                        <input class="quantidade" type="text" value="<?php echo $item['quantidade']; ?>" readonly>
                        <button name="acao" value="mais" type="submit" aria-label="Aumentar quantidade">+</button>
                    </form>

                    <div class="item-direita">
                        <p class="preco-item"><?php echo dinheiro($item['preco'] * $item['quantidade']); ?></p>
                        <!-- Ainda não virou pedido: só passa a ter status depois de "Confirmar pedido" -->
                        <p class="status status-no-carrinho">STATUS: NO CARRINHO</p>

                        <form action="atualizar.php" method="post">
                            <input type="hidden" name="indice" value="<?php echo $indice; ?>">
                            <button class="remover" name="acao" value="remover" type="submit">Remover do carrinho</button>
                        </form>
                    </div>

                </article>

            <?php } ?>

            <section class="resumo">
                <h2>Resumo</h2>

                <p class="linha-resumo"><span>Subtotal:</span> <span id="subtotal"><?php echo dinheiro($subtotal); ?></span></p>
                <p class="linha-resumo"><span>Adicionais:</span> <span><?php echo dinheiro($adicionais); ?></span></p>
                <p class="linha-resumo"><span>Taxa de serviço:</span> <span>Isento</span></p>

                <!-- Quem não está logado é levado ao login na tela de cobrança, e depois volta para ela -->
                <a class="botao-finalizar" href="../Cobranca/cobranca.php">Finalizar compra</a>
                <a class="continuar" href="../index.php">Continuar comprando</a>
            </section>

        <?php } ?>

        <!-- Pedidos já confirmados, com o status que aparece no painel da administração -->
        <?php if (count($pedidos) > 0) { ?>

            <h2 class="titulo-pedidos">Meus pedidos</h2>

            <?php foreach ($pedidos as $pedido) { ?>

                <section class="pedido">

                    <div class="pedido-topo">
                        <p>
                            <strong>Pedido #<?php echo $pedido['id']; ?></strong>
                            · feito em <?php echo date('d/m/Y', strtotime($pedido['data'])); ?>
                            <?php if ($pedido['prazo'] != '') { ?>
                                · prazo <?php echo date('d/m/Y', strtotime($pedido['prazo'])); ?>
                            <?php } ?>
                        </p>
                        <p class="pedido-total">Total: <?php echo dinheiro($pedido['total']); ?></p>
                    </div>

                    <?php foreach ($pedido['itens'] as $item) { ?>

                        <article class="item-carrinho item-pedido">

                            <div class="item-esquerda">
                                <img class="foto-item" src="<?php echo $raiz . escapar($item['foto1'] != '' ? $item['foto1'] : 'imagens/caixa.png'); ?>" alt="<?php echo escapar($item['produto']); ?>">

                                <div class="item-textos">
                                    <h2><?php echo escapar($item['produto']); ?></h2>
                                    <p class="descricao"><?php echo escapar($item['especificacoes']); ?></p>
                                </div>
                            </div>

                            <ul class="detalhes">
                                <?php if ($item['tema'] != '') { ?><li>Tema: <?php echo escapar($item['tema']); ?></li><?php } ?>
                                <?php if ($item['nome_escrito'] != '') { ?><li>Nome: <?php echo escapar($item['nome_escrito']); ?></li><?php } ?>
                                <?php if ($item['idade'] != '') { ?><li>Idade: <?php echo escapar($item['idade']); ?></li><?php } ?>
                                <?php if ($item['tamanho'] != '') { ?><li>Tamanho e formato do bolo: <?php echo escapar($item['tamanho']); ?></li><?php } ?>
                                <?php if ($item['observacoes'] != '') { ?><li>Obs: <?php echo escapar($item['observacoes']); ?></li><?php } ?>
                                <?php if ($item['cor'] != '') { ?><li>Cor: <?php echo escapar($item['cor']); ?></li><?php } ?>
                            </ul>

                            <!-- Pedido confirmado não muda de quantidade aqui: só mostra -->
                            <p class="qtd-pedido">Qtd.: <?php echo $item['quantidade']; ?></p>

                            <div class="item-direita">
                                <p class="preco-item"><?php echo dinheiro($item['valor'] * $item['quantidade']); ?></p>
                                <p class="status <?php echo $pedido['status']['classe']; ?>">STATUS: <?php echo escapar(mb_strtoupper($pedido['status']['texto'])); ?></p>
                            </div>

                        </article>

                    <?php } ?>

                    <?php if ($pedido['pago'] == 0) { ?>
                        <a class="botao-pagar" href="../Cobranca/pix.php?pedido=<?php echo $pedido['id']; ?>">Pagar com Pix</a>
                    <?php } ?>

                </section>

            <?php } ?>

        <?php } ?>

    </main>

    <?php include('../Includes/rodape.php'); ?>
    <!-- acessibilidades implementadas -->
    <div data-acc-position="bottom-left"></div>
    <script src="https://cdn.jsdelivr.net/gh/ifrederico/accessible-web-widget@1.6.3/dist/accessible-web-widget.min.js"></script>
    <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>

</body>

</html>
