<?php
// Tela de resultado de pesquisa (exemplo: pesquisa.php?pesquisa=batman)
// Esta página está dentro da pasta Pesquisa, então o site principal fica uma pasta acima
$raiz = '../';

@session_start();
require('../Adiministracao/conexao.php'); // conexão com o banco
require('../Includes/funcoes.php');       // funções dinheiro() e escapar()

// Pega o que a pessoa digitou na barra de pesquisa
// (o cabecalho.php usa essa variável para continuar mostrando o texto na barra)
$termoPesquisa = isset($_GET['pesquisa']) ? trim($_GET['pesquisa']) : '';

// Os % fazem o banco procurar o texto em qualquer parte do nome ou do tema
// (exemplo: "bat" encontra "Topper Batman")
$busca = '%' . $termoPesquisa . '%';

// Procura nos produtos ativos (os cadastrados por último aparecem primeiro)
// A pesquisa olha o nome do produto, o tema E o nome da categoria dele (tabela topicos).
// Assim os botões da tela inicial funcionam: clicar em "Brindes" pesquisa "Brindes" e traz todos os produtos dessa categoria.
// O LEFT JOIN liga cada produto à sua categoria (p e t são apelidos das tabelas produtos e topicos)
// O ? é preenchido pelo bind_param, igual no login
$stmt = $con->prepare("SELECT p.id, p.nome, p.preco, p.foto1, t.nome AS categoria
                       FROM produtos p
                       LEFT JOIN topicos t ON t.id = p.id_topico
                       WHERE p.ativo = 1 AND " . sqlDisponivel('p') . " AND (p.nome LIKE ? OR p.tema LIKE ? OR t.nome LIKE ?)
                       ORDER BY p.id DESC");
$stmt->bind_param("sss", $busca, $busca, $busca); // "sss" = três textos (nome, tema e categoria)
$stmt->execute();
$resultado = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesquisa - Corisco's Paper</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- O ?v=... muda sempre que o CSS é alterado, assim o navegador não usa uma cópia antiga guardada em cache -->
    <link rel="stylesheet" href="../style.css?v=<?php echo filemtime(__DIR__ . '/../style.css'); ?>">
    <link rel="stylesheet" href="../Includes/cabecalho.css?v=<?php echo filemtime(__DIR__ . '/../Includes/cabecalho.css'); ?>">
    <link rel="stylesheet" href="Css/pesquisa.css?v=<?php echo filemtime(__DIR__ . '/Css/pesquisa.css'); ?>">
</head>

<body>

    <!-- Topo do site (logo, pesquisa, favoritos, carrinho e login) -->
    <?php include('../Includes/cabecalho.php'); ?>

    <!-- Faixa com o texto da pesquisa e o funil no canto direito -->
    <section class="faixa-pesquisa">

        <?php if ($termoPesquisa == '') { ?>
            <!-- Pesquisa vazia: mostra todos os produtos -->
            <p class="titulo-pesquisa">Todos os produtos</p>
        <?php } else { ?>
            <p class="titulo-pesquisa">Resultados para pesquisa "<?php echo escapar($termoPesquisa); ?>"</p>
        <?php } ?>

        <!-- Funil de filtro: abre a lista de categorias com caixinhas de marcar (o Js/pesquisa.js monta a lista) -->
        <button class="filtro" id="botaoFiltro" type="button" aria-label="Filtrar por categoria" aria-expanded="false">
            <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M3 4h18l-7 8.5V20l-4 2v-9.5z" />
            </svg>
        </button>

        <div class="pop-categorias" id="popCategorias" hidden>
            <p class="pop-titulo">Filtrar por <strong>categoria</strong></p>
            <div class="pop-lista" id="listaCategorias"></div>
            <div class="pop-botoes">
                <button type="button" id="limparCategorias">Limpar</button>
                <button type="button" id="aplicarCategorias" class="pop-aplicar">Aplicar</button>
            </div>
        </div>

    </section>

    <main class="pagina-pesquisa">

        <?php if (mysqli_num_rows($resultado) == 0) { ?>

            <!-- Aparece quando nenhum produto combina com o que foi digitado -->
            <p class="sem-produtos">Nenhum produto encontrado para essa pesquisa.</p>

        <?php } else { ?>

            <!-- Aparece quando o filtro de categorias esconde todos os produtos -->
            <p class="sem-produtos" id="semResultadoFiltro" hidden>Nenhum produto nas categorias escolhidas.</p>

            <div class="lista-produtos">

                <!-- Repete um cartão para cada produto encontrado no banco -->
                <?php while ($produto = mysqli_fetch_assoc($resultado)) { ?>

                    <article class="cartao-produto" data-categoria="<?php echo escapar($produto['categoria'] != '' ? $produto['categoria'] : 'Sem categoria'); ?>">
                        <!-- Foto do produto (se não tiver foto, usa a imagem padrão) -->
                        <img src="<?php echo $raiz . ($produto['foto1'] != '' ? escapar($produto['foto1']) : 'imagens/caixa.png'); ?>" alt="<?php echo escapar($produto['nome']); ?>">

                        <!-- Nome e preço -->
                        <h2><?php echo escapar($produto['nome']); ?></h2>
                        <p class="preco"><?php echo dinheiro($produto['preco']); ?></p>

                        <!-- Botão azul que leva para a tela do produto -->
                        <a class="botao-comprar" href="../Produto/produto.php?id=<?php echo (int) $produto['id']; ?>">COMPRAR</a>
                    </article>

                <?php } ?>

            </div>

        <?php } ?>

    </main>

    <script src="Js/pesquisa.js?v=<?php echo filemtime(__DIR__ . '/Js/pesquisa.js'); ?>"></script>

    <?php include('../Includes/rodape.php'); ?>
    <!-- acessibilidades implementadas -->
    <div data-acc-position="bottom-left"></div>
    <script src="https://cdn.jsdelivr.net/gh/ifrederico/accessible-web-widget@1.6.3/dist/accessible-web-widget.min.js"></script>
    <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>

</body>

</html>
