// Filtro de categorias da tela de pesquisa (parecido com o filtro do Excel / do painel do ADM).
// A lista mostra as categorias dos produtos que apareceram na pesquisa. Marcou, clicou em Aplicar: só essas categorias ficam.

const botaoFiltro = document.getElementById('botaoFiltro');
const pop = document.getElementById('popCategorias');
const lista = document.getElementById('listaCategorias');
const cartoes = document.querySelectorAll('.cartao-produto');
const avisoVazio = document.getElementById('semResultadoFiltro');

// Categorias escolhidas no momento. null = nenhuma escolha feita (aparece tudo)
let escolhidas = null;

// Quando a pesquisa não achou nada, não tem o que filtrar
if (cartoes.length === 0) {
    botaoFiltro.hidden = true;
}

// Monta a lista com as categorias diferentes que existem nos cartões
function montarLista() {
    const categorias = [];
    cartoes.forEach((cartao) => {
        if (!categorias.includes(cartao.dataset.categoria)) categorias.push(cartao.dataset.categoria);
    });
    categorias.sort((a, b) => a.localeCompare(b, 'pt-BR'));

    lista.innerHTML = '';
    lista.appendChild(criarOpcao('Selecionar tudo', '', true, true));
    categorias.forEach((nome) => {
        lista.appendChild(criarOpcao(nome, nome, escolhidas === null || escolhidas.includes(nome), false));
    });
    atualizarSelecionarTudo();
}

function criarOpcao(texto, valor, marcada, ehTodos) {
    const rotulo = document.createElement('label');
    rotulo.className = 'pop-opcao' + (ehTodos ? ' pop-todos' : '');
    const caixa = document.createElement('input');
    caixa.type = 'checkbox';
    caixa.checked = marcada;
    if (ehTodos) {
        caixa.id = 'categoriasTodas';
    } else {
        caixa.className = 'categoria-valor';
        caixa.value = valor;
    }
    rotulo.append(caixa, ' ' + texto);
    return rotulo;
}

// "Selecionar tudo" fica marcado só quando todas as categorias estão marcadas
function atualizarSelecionarTudo() {
    const caixas = lista.querySelectorAll('.categoria-valor');
    document.getElementById('categoriasTodas').checked = [...caixas].every((c) => c.checked);
}

lista.addEventListener('change', (evento) => {
    if (evento.target.id === 'categoriasTodas') {
        lista.querySelectorAll('.categoria-valor').forEach((c) => { c.checked = evento.target.checked; });
    }
    atualizarSelecionarTudo();
});

// Mostra ou esconde cada produto conforme as categorias escolhidas
function filtrar() {
    let aparecendo = 0;
    cartoes.forEach((cartao) => {
        const aparece = escolhidas === null || escolhidas.includes(cartao.dataset.categoria);
        cartao.hidden = !aparece;
        if (aparece) aparecendo++;
    });
    avisoVazio.hidden = aparecendo > 0;
    botaoFiltro.classList.toggle('ativo', escolhidas !== null); // funil fica vermelho quando tem filtro
}

function abrir() {
    montarLista();
    pop.hidden = false;
    botaoFiltro.setAttribute('aria-expanded', 'true');
}

function fechar() {
    pop.hidden = true;
    botaoFiltro.setAttribute('aria-expanded', 'false');
}

botaoFiltro.addEventListener('click', (evento) => {
    evento.stopPropagation();
    if (pop.hidden) abrir(); else fechar();
});

document.getElementById('aplicarCategorias').addEventListener('click', () => {
    const caixas = [...lista.querySelectorAll('.categoria-valor')];
    const marcadas = caixas.filter((c) => c.checked).map((c) => c.value);
    escolhidas = marcadas.length === caixas.length ? null : marcadas; // tudo marcado = sem filtro
    filtrar();
    fechar();
});

document.getElementById('limparCategorias').addEventListener('click', () => {
    escolhidas = null;
    filtrar();
    fechar();
});

// Clicar fora ou apertar Esc fecha a caixinha
document.addEventListener('click', (evento) => {
    if (!pop.hidden && !pop.contains(evento.target)) fechar();
});
document.addEventListener('keydown', (evento) => {
    if (evento.key === 'Escape') fechar();
});
