<?php
// Recebe o feedback do rodapé (estrelas + texto) e guarda na tabela feedbacks.
// Responde em JSON: {"ok": true} ou {"ok": false, "erro": "mensagem"}
@session_start();
require('../Adiministracao/conexao.php');

header('Content-Type: application/json; charset=utf-8');

function responderFeedback($ok, $erro = '')
{
    echo json_encode(['ok' => $ok, 'erro' => $erro]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    responderFeedback(false, 'Pedido inválido.');
}

$estrelas = isset($_POST['estrelas']) ? (int) $_POST['estrelas'] : 0;
$mensagem = isset($_POST['mensagem']) ? trim($_POST['mensagem']) : '';

if ($estrelas < 1 || $estrelas > 5) {
    responderFeedback(false, 'Escolha de 1 a 5 estrelas.');
}
if (mb_strlen($mensagem) > 500) {
    responderFeedback(false, 'Escreva no máximo 500 caracteres.');
}

// Evita enviar várias vezes seguidas (só um feedback a cada 30 segundos por visitante)
if (isset($_SESSION['ultimo_feedback']) && time() - $_SESSION['ultimo_feedback'] < 30) {
    responderFeedback(false, 'Aguarde um pouco para enviar outro feedback.');
}

// Se a pessoa está logada como cliente, guarda quem foi (senão fica vazio)
$idUsuario = null;
if (isset($_SESSION['usuario']) && $_SESSION['usuario']['tipo'] == 'cliente') {
    $idUsuario = (int) $_SESSION['usuario']['id'];
}

$stmt = $con->prepare("INSERT INTO feedbacks (id_usuario, estrelas, mensagem) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $idUsuario, $estrelas, $mensagem);
if (!$stmt->execute()) {
    responderFeedback(false, 'Não foi possível salvar. Tente de novo.');
}

$_SESSION['ultimo_feedback'] = time();
responderFeedback(true);
