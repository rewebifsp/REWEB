<?php
// Funções pequenas que várias páginas usam

// Transforma 55 em "R$55,00"
function dinheiro($valor) {
    return 'R$' . number_format($valor, 2, ',', '.');
}

// Deixa um texto seguro para mostrar na página
// (assim ninguém consegue escrever código HTML no meio de um nome, por exemplo)
function escapar($texto) {
    return htmlspecialchars((string) $texto, ENT_QUOTES, 'UTF-8');
}

// Pedaço de SQL que deixa passar só os produtos que podem ser vendidos agora.
// Encomenda é feita sob pedido (não tem estoque), então sempre passa.
// Pronta entrega só passa se ainda tiver unidade no estoque (estoque > 0).
// Se o estoque zerar, o produto some de todas as telas até o ADM repor no painel.
// Exemplo de uso: "WHERE ativo = 1 AND " . sqlDisponivel()   ou   sqlDisponivel('p')  quando a tabela tem apelido "p"
function sqlDisponivel($apelido = '') {
    $prefixo = $apelido != '' ? $apelido . '.' : '';
    return "(" . $prefixo . "tipo <> 'pronta_entrega' OR " . $prefixo . "estoque > 0)";
}

// Descobre o status de um pedido a partir do que a Júlia marca no painel (Pagou / Pronto / Buscou).
// Devolve o texto para mostrar e uma classe de cor para o CSS.
// Observação: no painel só existe "Buscou". Para pedido com entrega, "Buscou" = já foi enviado.
function statusPedido($pago, $pronto, $buscou, $forma) {
    $entrega = ($forma == 'entrega');

    if ($buscou == 1) {
        return $entrega
            ? ['texto' => 'Enviado', 'classe' => 'status-concluido']
            : ['texto' => 'Retirado', 'classe' => 'status-concluido'];
    }
    if ($pronto == 1) {
        return $entrega
            ? ['texto' => 'Pronto para envio', 'classe' => 'status-pronto']
            : ['texto' => 'Pronto para retirada', 'classe' => 'status-pronto'];
    }
    if ($pago == 1) {
        return ['texto' => 'Em processamento', 'classe' => 'status-processando'];
    }
    return ['texto' => 'Aguardando pagamento', 'classe' => 'status-aguardando'];
}

// Status que sempre existem na lista do painel. A Júlia pode criar outros (eles ficam salvos em pedidos.status).
function statusPadrao() {
    return ['Verificar comprovante', 'Aguardando pagamento', 'Em processamento',
            'Pronto para retirada', 'Pronto para envio', 'Retirado', 'Enviado'];
}

// Cor de cada status (classes do CSS). Status criado pela Júlia usa a cor "status-outro".
function classeDoStatus($texto) {
    $mapa = [
        'Verificar comprovante' => 'status-aguardando',
        'Aguardando pagamento' => 'status-aguardando',
        'Em processamento' => 'status-processando',
        'Pronto para retirada' => 'status-pronto',
        'Pronto para envio' => 'status-pronto',
        'Retirado' => 'status-concluido',
        'Enviado' => 'status-concluido'
    ];
    return isset($mapa[$texto]) ? $mapa[$texto] : 'status-outro';
}

// STATUS ÚNICO do pedido: é o mesmo que aparece na tabela do painel e no carrinho do cliente.
// 1) Se a Júlia escolheu um status no painel (coluna pedidos.status), vale esse.
// 2) Senão, pedido feito pelo site e ainda não pago = "Verificar comprovante".
// 3) Senão, o status é calculado pelas caixinhas Pagou / Pronto / Buscou (statusPedido).
// $p precisa ter: status, criado_por, pago, pronto, buscou, forma_entrega
function statusDoPedido($p) {
    if (isset($p['status']) && $p['status'] != '') {
        return ['texto' => $p['status'], 'classe' => classeDoStatus($p['status'])];
    }
    if ($p['criado_por'] == 'site' && $p['pago'] == 0 && $p['pronto'] == 0 && $p['buscou'] == 0) {
        return ['texto' => 'Verificar comprovante', 'classe' => 'status-aguardando'];
    }
    return statusPedido($p['pago'], $p['pronto'], $p['buscou'], $p['forma_entrega']);
}

// Transforma um limite escrito do jeito do php.ini (exemplo: "2M") em número de bytes
function emBytes($valor) {
    $numero = (int) $valor;
    $letra = strtoupper(substr(trim($valor), -1));

    if ($letra == 'G') {
        return $numero * 1024 * 1024 * 1024;
    }
    if ($letra == 'M') {
        return $numero * 1024 * 1024;
    }
    if ($letra == 'K') {
        return $numero * 1024;
    }
    return $numero;
}

// Guarda uma imagem enviada pelo formulário na pasta uploads.
// Devolve o caminho da imagem (exemplo: uploads/arte_123.png) ou '' se não veio imagem válida.
function salvarImagem($campo, $prefixo) {
    if (!isset($_FILES[$campo]) || $_FILES[$campo]['error'] != 0) {
        return '';
    }

    $extensao = strtolower(pathinfo($_FILES[$campo]['name'], PATHINFO_EXTENSION));
    $permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    // Só aceita se a extensão for de imagem e o arquivo for uma imagem de verdade
    if (!in_array($extensao, $permitidas) || getimagesize($_FILES[$campo]['tmp_name']) === false) {
        return '';
    }

    if (!is_dir('../uploads')) {
        mkdir('../uploads');
    }

    $caminho = 'uploads/' . uniqid($prefixo) . '.' . $extensao;
    move_uploaded_file($_FILES[$campo]['tmp_name'], '../' . $caminho);
    return $caminho;
}
