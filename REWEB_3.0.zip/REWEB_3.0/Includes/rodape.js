// Feedback do rodapé: o cliente escolhe de 1 a 5 estrelas, escreve (se quiser) e envia.
(function () {

    const formulario = document.getElementById('formFeedback');
    if (!formulario) return;

    const estrelas = formulario.querySelectorAll('.estrela');
    const texto = document.getElementById('feedbackTexto');
    const aviso = document.getElementById('feedbackAviso');
    let nota = 0; // 0 = ainda não escolheu

    // Pinta as estrelas até a nota escolhida
    function pintar(ate) {
        estrelas.forEach(function (estrela) {
            const n = Number(estrela.dataset.nota);
            estrela.classList.toggle('cheia', n <= ate);
            estrela.setAttribute('aria-checked', n === nota ? 'true' : 'false');
        });
    }

    estrelas.forEach(function (estrela) {
        estrela.addEventListener('click', function () {
            nota = Number(estrela.dataset.nota);
            pintar(nota);
        });
        // Passar o mouse mostra a nota que seria escolhida
        estrela.addEventListener('mouseenter', function () { pintar(Number(estrela.dataset.nota)); });
    });
    formulario.querySelector('.estrelas').addEventListener('mouseleave', function () { pintar(nota); });

    formulario.addEventListener('submit', async function (evento) {
        evento.preventDefault();
        aviso.className = 'feedback-aviso';

        if (nota === 0) {
            aviso.textContent = 'Escolha de 1 a 5 estrelas.';
            aviso.classList.add('erro');
            return;
        }

        const dados = new FormData();
        dados.append('estrelas', nota);
        dados.append('mensagem', texto.value);

        try {
            const resposta = await fetch(formulario.dataset.envio, { method: 'POST', body: dados });
            const resultado = await resposta.json();
            if (resultado.ok) {
                aviso.textContent = 'Obrigado pelo seu feedback!';
                aviso.classList.add('ok');
                nota = 0;
                pintar(0);
                texto.value = '';
            } else {
                aviso.textContent = resultado.erro || 'Não foi possível enviar.';
                aviso.classList.add('erro');
            }
        } catch (erro) {
            aviso.textContent = 'Erro de conexão. Tente de novo.';
            aviso.classList.add('erro');
        }
    });

})();
