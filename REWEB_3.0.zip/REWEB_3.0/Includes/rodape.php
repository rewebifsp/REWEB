<?php
// Rodapé do site (usado em todas as telas). Para usar: include('Includes/rodape.php');
// $raiz é o caminho até a pasta principal do site ('' na tela inicial, '../' nas outras)
$raizRodape = isset($raiz) ? $raiz : '';
?>
<link rel="stylesheet" href="<?php echo $raizRodape; ?>Includes/rodape.css?v=<?php echo filemtime(__DIR__ . '/rodape.css'); ?>">

<footer class="rodape">

    <!-- Esquerda: logo da loja -->
    <div class="rodape-marca">
        <img src="<?php echo $raizRodape; ?>imagens/logo.png" alt="Corisco's Paper - Papelaria Criativa">
    </div>

    <!-- Meio: atendimento + quem desenvolveu -->
    <div class="rodape-meio">

        <div class="rodape-atendimento">
            <p class="selo">&#10022; ATENDIMENTO &#10022;</p>
            <ul>
                <li>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.6L3 21l4.5-1.2A9 9 0 1 0 12 3z"/><path d="M9 8c0 3.5 3 6.5 6.5 6.5l1-1.5-2-1-1 .8c-1-.4-2-1.4-2.4-2.4l.8-1-1-2z"/></svg>
                    <a href="https://wa.me/5519988565666" target="_blank" rel="noopener">(19) 98856-5666</a>
                </li>
                <li>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17" cy="7" r="1"/></svg>
                    <a href="https://www.instagram.com/juliacoriscopapelaria" target="_blank" rel="noopener">@juliacoriscopapelaria</a>
                </li>
                <li>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>
                    <a href="mailto:juliacoriscopapelaria@gmail.com">juliacoriscopapelaria@gmail.com</a>
                </li>
            </ul>
        </div>

        <div class="rodape-dev">
            <img src="<?php echo $raizRodape; ?>imagens/reweb.png" alt="ReWeb - Softwares de Reuso">
            <div>
                <p class="dev-titulo">Desenvolvido por</p>
                <p class="dev-nome">REWEB SOFTWARES DE REUSO</p>
                <ul>
                    <li>
                        <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>
                        <a href="mailto:rewebifsp@gmail.com">rewebifsp@gmail.com</a>
                    </li>
                    <li>
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.6L3 21l4.5-1.2A9 9 0 1 0 12 3z"/><path d="M9 8c0 3.5 3 6.5 6.5 6.5l1-1.5-2-1-1 .8c-1-.4-2-1.4-2.4-2.4l.8-1-1-2z"/></svg>
                        <a href="https://wa.me/5541984118283" target="_blank" rel="noopener">(41) 98411-8283</a>
                    </li>
                </ul>
            </div>
        </div>

    </div>

    <!-- Direita: feedback (estrelas + texto) -->
    <form class="rodape-feedback" id="formFeedback" data-envio="<?php echo $raizRodape; ?>Includes/enviar-feedback.php" novalidate>
        <p class="selo">&#10022; FEEDBACKS &#10022;</p>

        <div class="estrelas" id="estrelas" role="radiogroup" aria-label="Sua nota de 1 a 5 estrelas">
            <?php for ($i = 1; $i <= 5; $i++) { ?>
                <button type="button" class="estrela" data-nota="<?php echo $i; ?>" role="radio" aria-checked="false" aria-label="<?php echo $i; ?> estrela<?php echo $i > 1 ? 's' : ''; ?>">&#9733;</button>
            <?php } ?>
        </div>

        <textarea id="feedbackTexto" maxlength="500" rows="4" placeholder="Escreva suas observações sobre nós..." aria-label="Suas observações"></textarea>
        <button type="submit" class="feedback-enviar">Enviar</button>
        <p class="feedback-aviso" id="feedbackAviso" role="status"></p>
    </form>

</footer>

<script src="<?php echo $raizRodape; ?>Includes/rodape.js?v=<?php echo filemtime(__DIR__ . '/rodape.js'); ?>"></script>
