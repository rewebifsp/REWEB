<?php
// Todas as ações da tela de administração (painel.php) passam por aqui:
//   nova_encomenda    -> anota uma encomenda nova
//   salvar_encomenda  -> altera uma encomenda que já existe
//   excluir_encomenda -> apaga uma encomenda inteira (com todos os itens dela)
//   novo_produto      -> cadastra um produto novo na loja
//   novo_admin        -> cria a conta de um novo administrador
//   admin_ativo       -> desativa ou reativa o acesso de um administrador
// O painel.php chama este arquivo com fetch() e recebe a resposta em JSON ({ok: true} ou {ok: false, erro: "..."}).

require('so-adm.php'); // só ADM entra (quem não for volta para a tela inicial)
require_once('conexao.php');
require('../Includes/funcoes.php');

header('Content-Type: application/json; charset=utf-8');

// Avisa o banco quem está logado no painel. Os triggers de auditoria (tabela log_pedidos)
// usam essa variável para gravar quem alterou ou excluiu cada pedido.
$nomeAdmin = isset($_SESSION['usuario']['nome']) ? $_SESSION['usuario']['nome'] : 'painel';
$stmt = $con->prepare("SET @usuario_painel = ?");
$stmt->bind_param("s", $nomeAdmin);
$stmt->execute();
$stmt->close();

// Termina a execução devolvendo uma resposta em JSON
function responder($ok, $erro = '')
{
    echo json_encode(['ok' => $ok, 'erro' => $erro]);
    exit;
}

// Só aceita envio de formulário (POST)
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    http_response_code(405);
    responder(false, 'Método não permitido.');
}

// Se o envio inteiro passou do limite de tamanho do servidor, o PHP joga fora tudo o que veio.
// Então avisamos o motivo de verdade (senão apareceria só "Sessão expirada")
if (empty($_POST) && empty($_FILES) && isset($_SERVER['CONTENT_LENGTH']) && $_SERVER['CONTENT_LENGTH'] > 0) {
    responder(false, 'O envio passou do limite de tamanho (' . ini_get('post_max_size') . 'B). Escolha fotos menores.');
}

// Proteção contra formulários falsos vindos de outros sites: o token precisa ser o mesmo da sessão
$token = isset($_POST['csrf']) ? $_POST['csrf'] : '';
if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $token)) {
    http_response_code(403);
    responder(false, 'Sessão expirada. Recarregue a página e tente de novo.');
}

$acao = isset($_POST['acao']) ? $_POST['acao'] : '';

// Confere se um texto é uma data real no formato aaaa-mm-dd (rejeita letras, dias que não existem, anos absurdos)
function dataValida($texto)
{
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $texto, $p)) {
        return false;
    }
    return checkdate((int) $p[2], (int) $p[3], (int) $p[1]) && (int) $p[1] <= 2100;
}

// Telefone: só números e os símbolos ( ) - + e espaço, com no máximo 15 dígitos.
// Devolve '' se está tudo certo, ou a mensagem do problema.
function conferirTelefone($telefone)
{
    if ($telefone == '') {
        return '';
    }
    if (!preg_match('/^[0-9()+\-\s]+$/', $telefone)) {
        return 'O telefone deve ter só números.';
    }
    if (strlen(preg_replace('/\D/', '', $telefone)) > 15) {
        return 'O telefone pode ter no máximo 15 dígitos.';
    }
    return '';
}


// Pega um campo de texto do formulário já sem espaços nas pontas
function texto($campo)
{
    return isset($_POST[$campo]) ? trim($_POST[$campo]) : '';
}

// Confere uma foto do formulário ANTES de salvar o produto (assim o produto não fica salvo pela metade).
// Devolve '' se está tudo certo (ou se nenhuma foto foi escolhida) ou a mensagem do problema.
function erroDaFoto($campo, $nomeDaFoto)
{
    // Nenhum arquivo escolhido nesse campo: tudo bem, as fotos 2 e 3 são opcionais
    if (!isset($_FILES[$campo]) || $_FILES[$campo]['error'] == UPLOAD_ERR_NO_FILE) {
        return '';
    }

    // O arquivo passou do limite de tamanho por foto
    if ($_FILES[$campo]['error'] == UPLOAD_ERR_INI_SIZE || $_FILES[$campo]['error'] == UPLOAD_ERR_FORM_SIZE) {
        return 'A ' . $nomeDaFoto . ' é grande demais (o limite é ' . ini_get('upload_max_filesize') . 'B por foto). Escolha uma foto menor.';
    }

    // Qualquer outro problema no envio
    if ($_FILES[$campo]['error'] != UPLOAD_ERR_OK) {
        return 'Não foi possível enviar a ' . $nomeDaFoto . '. Tente de novo.';
    }

    // Tem que ser uma imagem de verdade (mesmas regras da função salvarImagem)
    $extensao = strtolower(pathinfo($_FILES[$campo]['name'], PATHINFO_EXTENSION));
    $permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    if (!in_array($extensao, $permitidas) || getimagesize($_FILES[$campo]['tmp_name']) === false) {
        return 'A ' . $nomeDaFoto . ' precisa ser uma imagem (JPG, PNG, GIF ou WEBP).';
    }

    return '';
}

// Anota uma frase no histórico (a caixa amarela do painel)
function anotarHistorico($con, $descricao, $idPedido)
{
    // Quem fez a ação: o nome do administrador que está logado
    $autor = isset($_SESSION['usuario']['nome']) ? $_SESSION['usuario']['nome'] : null;

    // Procedure sp_registrar_historico (está no banco_reweb.sql)
    $stmt = $con->prepare("CALL sp_registrar_historico(?, ?, ?)");
    $stmt->bind_param("sis", $descricao, $idPedido, $autor);
    $stmt->execute();
    $stmt->close();
}

// ------------------------------------------------------------
// NOVA ENCOMENDA (o ADM anota na mão)
// ------------------------------------------------------------
if ($acao == 'nova_encomenda') {

    $cliente = texto('cliente');
    $produto = texto('produto');
    $valor = (float) texto('valor');
    $quantidade = (int) texto('quantidade');
    $tema = texto('tema');
    $telefone = texto('telefone');
    $endereco = texto('endereco');
    $email = texto('email');
    $observacoes = texto('observacoes');

    if ($cliente == '' || $produto == '') {
        responder(false, 'Preencha o cliente e o produto.');
    }
    if ($quantidade < 1) {
        $quantidade = 1;
    }

    // Se a data não foi preenchida, usa a data de hoje
    $data = texto('data') != '' ? texto('data') : date('Y-m-d');
    if (!dataValida($data)) {
        responder(false, 'Data inválida.');
    }
    if ($data < date('Y-m-d')) {
        responder(false, 'A data da encomenda não pode ser anterior a hoje.');
    }

    // O prazo é opcional (fica vazio no banco quando não preenchido)
    $prazo = texto('prazo') != '' ? texto('prazo') : null;
    if ($prazo === null) {
        responder(false, 'Informe o prazo (data de entrega) da encomenda.');
    }
    if (!dataValida($prazo)) {
        responder(false, 'Prazo inválido.');
    }
    if ($prazo < $data) {
        responder(false, 'O prazo não pode ser anterior à data da encomenda.');
    }
    $data = $data . ' 00:00:00';

    $erroTelefone = conferirTelefone($telefone);
    if ($erroTelefone != '') {
        responder(false, $erroTelefone);
    }

    // Caixinhas de marcar: marcada = 1, desmarcada = 0
    $pagou = isset($_POST['pagou']) ? 1 : 0;
    $buscou = isset($_POST['buscou']) ? 1 : 0;

    // (retirada ou entrega é decidido pela procedure: com endereço é entrega, sem endereço é retirada)

    // Guarda a foto da encomenda (se tiver). Se foi enviada, ela já conta como arte recebida
    $arte = salvarImagem('foto', 'encomenda_');

    $precisaArte = isset($_POST['precisa_arte']) ? 1 : 0;
    $autor = isset($_SESSION['usuario']['nome']) ? $_SESSION['usuario']['nome'] : null;

    // Salva o pedido, o produto e o histórico JUNTOS pela procedure sp_inserir_encomenda (está no banco_reweb.sql).
    // Ela faz a transação dentro do banco: confere os dados, grava tudo e dá COMMIT,
    // ou dá ROLLBACK e devolve o erro se alguma parte falhar. O número do pedido novo volta em @id_pedido.
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // se der erro no banco, o PHP avisa com uma exceção

    try {
        $stmt = $con->prepare("CALL sp_inserir_encomenda(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, @id_pedido)");
        $stmt->bind_param("ssssssiissdissis", $cliente, $telefone, $email, $endereco, $data, $prazo, $pagou, $buscou, $observacoes,
                          $produto, $valor, $quantidade, $tema, $arte, $precisaArte, $autor);
        $stmt->execute();
        $stmt->close();
    } catch (mysqli_sql_exception $erro) {
        // Erro 1644 = regra da procedure (ex.: prazo antes da data): mostra a mensagem dela
        if ($erro->getCode() == 1644) {
            responder(false, $erro->getMessage());
        }
        responder(false, 'Não foi possível salvar a encomenda. Tente de novo.');
    }

    responder(true);
}

// ------------------------------------------------------------
// SALVAR ENCOMENDA (alterar uma que já existe)
// ------------------------------------------------------------
if ($acao == 'salvar_encomenda') {

    $idPedido = (int) texto('id_pedido');
    $idItem = (int) texto('id_item');

    $cliente = texto('cliente');
    $produto = texto('produto');
    if ($cliente == '' || $produto == '') {
        responder(false, 'Preencha o cliente e o produto.');
    }

    // Confere se o pedido e o item existem e são um do outro
    $stmt = $con->prepare("SELECT p.data_pedido, p.pago, p.pronto, p.buscou, p.status, i.arte FROM pedidos p JOIN itens_pedido i ON i.id_pedido = p.id WHERE p.id = ? AND i.id = ?");
    $stmt->bind_param("ii", $idPedido, $idItem);
    $stmt->execute();
    $atual = mysqli_fetch_assoc($stmt->get_result());
    if (!$atual) {
        responder(false, 'Encomenda não encontrada.');
    }

    $telefone = texto('telefone');
    $email = texto('email');
    $endereco = texto('endereco');
    $observacoes = texto('observacoes');
    $forma = $endereco != '' ? 'entrega' : 'retirada';
    $prazo = texto('prazo') != '' ? texto('prazo') : null;
    $erroTelefone = conferirTelefone($telefone);
    if ($erroTelefone != '') {
        responder(false, $erroTelefone);
    }
    if ($prazo !== null && !dataValida($prazo)) {
        responder(false, 'Prazo inválido.');
    }
    $pagou = isset($_POST['pagou']) ? 1 : 0;
    $pronto = isset($_POST['pronto']) ? 1 : 0;
    $buscou = isset($_POST['buscou']) ? 1 : 0;

    // A data só muda se a pessoa mexeu nela (assim a hora do pedido não se perde)
    $data = $atual['data_pedido'];
    if (texto('data') != '' && texto('data') != substr($atual['data_pedido'], 0, 10)) {
        // Só confere quando a data foi trocada (pedidos antigos continuam podendo ser editados)
        if (!dataValida(texto('data'))) {
            responder(false, 'Data inválida.');
        }
        if (texto('data') < date('Y-m-d')) {
            responder(false, 'A data da encomenda não pode ser anterior a hoje.');
        }
        $data = texto('data') . ' 00:00:00';
    }

    if ($prazo !== null && $prazo < substr($data, 0, 10)) {
        responder(false, 'O prazo não pode ser anterior à data da encomenda.');
    }

    // ----- STATUS -----
    // Status escolhido na lista (ou criado agora com "+ Novo status")
    $statusEscolhido = texto('status');
    if ($statusEscolhido == '__novo__') {
        $statusEscolhido = mb_substr(texto('novo_status'), 0, 40);
        if ($statusEscolhido == '') {
            responder(false, 'Digite o nome do novo status.');
        }
    }
    $statusOriginal = texto('status_original'); // o status que a janela mostrava ao abrir
    $statusSalvo = $atual['status'] != '' ? $atual['status'] : null;

    if ($statusEscolhido != '' && $statusEscolhido != $statusOriginal) {
        // A Júlia trocou o status: ele fica salvo e as caixinhas acompanham (para os quadros do topo e filtros baterem)
        $statusSalvo = $statusEscolhido;
        if (in_array($statusEscolhido, ['Verificar comprovante', 'Aguardando pagamento'])) {
            $pagou = 0; $pronto = 0; $buscou = 0;
        } elseif ($statusEscolhido == 'Em processamento') {
            $pagou = 1; $pronto = 0; $buscou = 0;
        } elseif (in_array($statusEscolhido, ['Pronto para retirada', 'Pronto para envio'])) {
            $pagou = 1; $pronto = 1; $buscou = 0;
        } elseif (in_array($statusEscolhido, ['Retirado', 'Enviado'])) {
            $pagou = 1; $pronto = 1; $buscou = 1;
        }
        // Status criado pela Júlia: as caixinhas ficam como ela marcou
    } else {
        // Status não foi mexido. Se ela mexeu nas caixinhas e o status era um dos padrão, ele volta a ser calculado por elas
        $mudouCaixinha = ($pagou != $atual['pago'] || $pronto != $atual['pronto'] || $buscou != $atual['buscou']);
        if ($mudouCaixinha && ($statusSalvo === null || in_array($statusSalvo, statusPadrao()))) {
            $statusSalvo = null;
        }
    }

    $stmt = $con->prepare("UPDATE pedidos SET cliente = ?, telefone = ?, email = ?, forma_entrega = ?, endereco = ?, data_pedido = ?, prazo = ?, pago = ?, pronto = ?, buscou = ?, observacoes = ?, status = ? WHERE id = ?");
    $stmt->bind_param("sssssssiiissi", $cliente, $telefone, $email, $forma, $endereco, $data, $prazo, $pagou, $pronto, $buscou, $observacoes, $statusSalvo, $idPedido);
    $stmt->execute();

    // Se mandaram uma foto nova, ela troca a anterior. Se não, continua a que já estava
    $arte = salvarImagem('foto', 'encomenda_');
    if ($arte == '') {
        $arte = $atual['arte'];
    }

    $valor = (float) texto('valor');
    $quantidade = max(1, (int) texto('quantidade'));
    $tema = texto('tema');
    $precisaArte = isset($_POST['precisa_arte']) ? 1 : 0;

    $stmt = $con->prepare("UPDATE itens_pedido SET produto = ?, valor = ?, quantidade = ?, tema = ?, arte = ?, precisa_arte = ? WHERE id = ?");
    $stmt->bind_param("sdissii", $produto, $valor, $quantidade, $tema, $arte, $precisaArte, $idItem);
    $stmt->execute();

    anotarHistorico($con, 'Administração alterou a encomenda de ' . $cliente, $idPedido);
    responder(true);
}

// ------------------------------------------------------------
// EXCLUIR ENCOMENDA (o pedido inteiro; os itens saem junto por causa do ON DELETE CASCADE)
// ------------------------------------------------------------
if ($acao == 'excluir_encomenda') {

    $idPedido = (int) texto('id_pedido');

    $stmt = $con->prepare("SELECT cliente FROM pedidos WHERE id = ?");
    $stmt->bind_param("i", $idPedido);
    $stmt->execute();
    $pedido = mysqli_fetch_assoc($stmt->get_result());
    if (!$pedido) {
        responder(false, 'Encomenda não encontrada.');
    }

    // Apaga a encomenda e anota no histórico JUNTOS (transação).
    // Assim, se a encomenda foi apagada, sempre fica o registro de quem apagou.
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // se uma gravação falhar, o PHP avisa com um erro
    $con->begin_transaction();

    try {
        $stmt = $con->prepare("DELETE FROM pedidos WHERE id = ?");
        $stmt->bind_param("i", $idPedido);
        $stmt->execute();

        // O pedido já não existe, então o histórico fica sem número de pedido (vazio)
        anotarHistorico($con, 'Administração excluiu a encomenda de ' . $pedido['cliente'], null);

        $con->commit(); // deu tudo certo: confirma
    } catch (Exception $erro) {
        $con->rollback(); // deu erro: desfaz tudo (a encomenda continua existindo)
        responder(false, 'Não foi possível excluir a encomenda. Tente de novo.');
    }

    responder(true);
}

// ------------------------------------------------------------
// NOVO PRODUTO (aparece na loja)
// ------------------------------------------------------------
if ($acao == 'novo_produto') {

    $nome = texto('produto');
    $tema = texto('tema');
    $preco = (float) texto('valor');
    $especificacoes = texto('especificacoes');
    $topico = texto('topico');
    $tipo = texto('tipo') == 'pronta_entrega' ? 'pronta_entrega' : 'encomenda';
    $cores = texto('cores');

    if ($nome == '') {
        responder(false, 'Preencha o nome do produto.');
    }

    // Estoque: só existe para pronta entrega (quantas unidades já estão prontas).
    // Encomenda é feita sob pedido, então fica vazio (NULL) e nunca "acaba".
    $estoque = null;
    if ($tipo == 'pronta_entrega') {
        if (texto('estoque') === '' || (int) texto('estoque') < 0) {
            responder(false, 'Informe quantas unidades de pronta entrega tem em estoque.');
        }
        $estoque = (int) texto('estoque');
    }

    // Confere as 3 fotos antes de salvar qualquer coisa (se uma tiver problema, nada é salvo)
    $fotosDoFormulario = ['imagem' => 'foto principal', 'imagem2' => 'foto 2', 'imagem3' => 'foto 3'];
    foreach ($fotosDoFormulario as $campo => $nomeDaFoto) {
        $erroFoto = erroDaFoto($campo, $nomeDaFoto);
        if ($erroFoto != '') {
            responder(false, $erroFoto);
        }
    }

    // O tópico é a categoria. A pessoa escolhe uma da lista ou escolhe "+ Nova categoria" (valor __nova__)
    // e digita o nome dela
    $nomeTopico = $topico;
    if ($topico == '__nova__') {
        $nomeTopico = texto('nova_categoria');
        if ($nomeTopico == '') {
            responder(false, 'Digite o nome da nova categoria.');
        }
    }
    if ($nomeTopico == '') {
        responder(false, 'Escolha uma categoria da lista.');
    }
    if (mb_strlen($nomeTopico) > 100) {
        responder(false, 'O nome da categoria pode ter no máximo 100 letras.');
    }

    // Procura a categoria no banco (maiúsculas e minúsculas não fazem diferença)
    $stmt = $con->prepare("SELECT id FROM topicos WHERE nome = ?");
    $stmt->bind_param("s", $nomeTopico);
    $stmt->execute();
    $achou = mysqli_fetch_assoc($stmt->get_result());

    if ($achou) {
        // Já existe: usa a que existe (assim não cria categoria repetida)
        $idTopico = $achou['id'];
    } elseif ($topico == '__nova__') {
        // Não existe e a pessoa pediu uma nova: cria
        $stmt = $con->prepare("INSERT INTO topicos (nome) VALUES (?)");
        $stmt->bind_param("s", $nomeTopico);
        $stmt->execute();
        $idTopico = $con->insert_id;
    } else {
        // Veio um nome que não está na lista e não foi pedido como novo
        responder(false, 'Escolha uma categoria da lista.');
    }

    // Guarda as fotos do produto (as que não foram enviadas ficam vazias)
    $foto1 = salvarImagem('imagem', 'produto_');
    $foto2 = salvarImagem('imagem2', 'produto_');
    $foto3 = salvarImagem('imagem3', 'produto_');

    $stmt = $con->prepare("INSERT INTO produtos (nome, tema, preco, especificacoes, id_topico, tipo, cores_disponiveis, foto1, foto2, foto3, estoque) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdsisssssi", $nome, $tema, $preco, $especificacoes, $idTopico, $tipo, $cores, $foto1, $foto2, $foto3, $estoque);
    $stmt->execute();

    anotarHistorico($con, 'Administração cadastrou o produto ' . $nome, null);
    responder(true);
}

// ------------------------------------------------------------
// DEFINIR O ESTOQUE de um produto de pronta entrega (usado para repor quando acabou).
// Com estoque 0 o produto some da loja; com 1 ou mais ele volta a aparecer.
// ------------------------------------------------------------
if ($acao == 'definir_estoque') {

    $idProduto = (int) texto('id_produto');

    if (texto('estoque') === '' || !ctype_digit(texto('estoque'))) {
        responder(false, 'Digite um número de unidades (0 ou mais).');
    }
    $estoque = (int) texto('estoque');

    $stmt = $con->prepare("SELECT nome, tipo FROM produtos WHERE id = ?");
    $stmt->bind_param("i", $idProduto);
    $stmt->execute();
    $produto = mysqli_fetch_assoc($stmt->get_result());

    if (!$produto) {
        responder(false, 'Produto não encontrado.');
    }
    if ($produto['tipo'] != 'pronta_entrega') {
        responder(false, 'Só produtos de pronta entrega têm estoque.');
    }

    $stmt = $con->prepare("UPDATE produtos SET estoque = ? WHERE id = ?");
    $stmt->bind_param("ii", $estoque, $idProduto);
    $stmt->execute();

    anotarHistorico($con, 'Administração definiu o estoque de ' . $produto['nome'] . ' para ' . $estoque . ($estoque == 1 ? ' unidade' : ' unidades'), null);
    responder(true);
}

// ------------------------------------------------------------
// ATIVAR / DESATIVAR PRODUTO (coluna "ativo": 1 = aparece na loja, 0 = escondido)
// ------------------------------------------------------------
if ($acao == 'alternar_produto') {

    $idProduto = (int) texto('id_produto');
    $ativo = texto('ativo') === '1' ? 1 : 0;

    $stmt = $con->prepare("SELECT nome FROM produtos WHERE id = ?");
    $stmt->bind_param("i", $idProduto);
    $stmt->execute();
    $produto = mysqli_fetch_assoc($stmt->get_result());
    if (!$produto) {
        responder(false, 'Produto não encontrado.');
    }

    $stmt = $con->prepare("UPDATE produtos SET ativo = ? WHERE id = ?");
    $stmt->bind_param("ii", $ativo, $idProduto);
    $stmt->execute();

    anotarHistorico($con, 'Administração ' . ($ativo == 1 ? 'ativou' : 'desativou') . ' o produto ' . $produto['nome'], null);
    responder(true);
}

// ------------------------------------------------------------
// NOVO ADMINISTRADOR (cada pessoa tem a sua conta, assim o histórico mostra quem fez cada coisa)
// ------------------------------------------------------------
if ($acao == 'novo_admin') {

    $nome = texto('nome_admin');
    $email = strtolower(texto('email_admin'));
    // A senha não passa pelo texto() porque espaços fazem parte dela
    $senha = isset($_POST['senha_admin']) ? $_POST['senha_admin'] : '';
    $confirmar = isset($_POST['confirmar_admin']) ? $_POST['confirmar_admin'] : '';

    if ($nome == '' || mb_strlen($nome) > 100) {
        responder(false, 'Preencha o nome (até 100 letras).');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
        responder(false, 'Digite um e-mail válido.');
    }
    if (strlen($senha) < 8) {
        responder(false, 'A senha precisa ter pelo menos 8 caracteres.');
    }
    if ($senha != $confirmar) {
        responder(false, 'As senhas não são iguais.');
    }

    // O e-mail não pode ser de outro administrador
    $stmt = $con->prepare("SELECT id FROM administradores WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if (mysqli_fetch_assoc($stmt->get_result())) {
        responder(false, 'Já existe um administrador com esse e-mail.');
    }

    // ...nem de um cliente do site (senão o login ficaria confuso)
    $stmt = $con->prepare("SELECT id FROM login WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if (mysqli_fetch_assoc($stmt->get_result())) {
        responder(false, 'Esse e-mail já é de um cliente do site. Use outro e-mail.');
    }

    // Criptografa a senha ANTES de salvar, assim a senha de verdade nunca vai para o banco
    $senhaCriptografada = password_hash($senha, PASSWORD_DEFAULT);

    $stmt = $con->prepare("INSERT INTO administradores (nome, email, senha) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nome, $email, $senhaCriptografada);
    $stmt->execute();

    anotarHistorico($con, 'Administração criou a conta do administrador ' . $nome, null);
    responder(true);
}

// ------------------------------------------------------------
// DESATIVAR OU REATIVAR UM ADMINISTRADOR (a conta não é apagada, só perde ou ganha o acesso)
// ------------------------------------------------------------
if ($acao == 'admin_ativo') {

    $idAdmin = (int) texto('id_admin');
    $ativo = texto('ativo') == '1' ? 1 : 0;

    // Ninguém desativa a própria conta (senão ficaria trancado para fora do painel)
    $meuId = isset($_SESSION['usuario']['admin_id']) ? (int) $_SESSION['usuario']['admin_id'] : 0;
    if ($idAdmin == $meuId && $ativo == 0) {
        responder(false, 'Você não pode desativar a sua própria conta.');
    }

    // Procura o administrador para anotar o nome dele no histórico
    $stmt = $con->prepare("SELECT nome FROM administradores WHERE id = ?");
    $stmt->bind_param("i", $idAdmin);
    $stmt->execute();
    $admin = mysqli_fetch_assoc($stmt->get_result());

    if (!$admin) {
        responder(false, 'Administrador não encontrado.');
    }

    $stmt = $con->prepare("UPDATE administradores SET ativo = ? WHERE id = ?");
    $stmt->bind_param("ii", $ativo, $idAdmin);
    $stmt->execute();

    anotarHistorico($con, 'Administração ' . ($ativo == 1 ? 'reativou' : 'desativou') . ' o administrador ' . $admin['nome'], null);
    responder(true);
}

responder(false, 'Ação desconhecida.');
