<?php
// Busca no banco tudo o que a tela da administração (painel.php) precisa mostrar.
// Quem usa: require('buscar-encomendas.php'); e depois percorre as listas abaixo.
//   $linhas     -> uma linha da tabela para cada ITEM de pedido
//   $historico  -> as últimas coisas que aconteceram (caixa amarela)
//   $clientes   -> lista de clientes (menu "Clientes" da lateral)
//   $produtos   -> lista de produtos (menu "Produtos" da lateral)
//   $topicos    -> categorias (sugestões no formulário de produto)
//   $meses      -> meses que têm pedidos (menu "Painel" da lateral)
//   $feedbacks  -> últimos feedbacks do rodapé do site (menu "Feedbacks" da lateral)
//   $administradores -> quem tem acesso ao painel (menu "Administradores" da lateral)
require_once('conexao.php');
require('../Includes/funcoes.php');

// Cada item de pedido vira uma linha da tabela.
// A view vw_encomendas_painel (está no banco_reweb.sql) já junta itens_pedido + pedidos + login
// e já traz o total da linha (valor * quantidade).
$sql = "SELECT * FROM vw_encomendas_painel ORDER BY data_pedido DESC, id_item DESC";
$resultado = $con->query($sql);

$linhas = [];
while ($linha = mysqli_fetch_assoc($resultado)) {

    // Essas informações ajudam os botões de filtro (Aguarda PGTO, Prontos...) da tela
    $linha['f_pagou'] = $linha['pago'] == 1 ? 'sim' : 'nao';
    // Pedido já buscado/enviado também passa por "pronto", então conta nos Prontos do topo
    $linha['f_pronto'] = ($linha['pronto'] == 1 || $linha['buscou'] == 1) ? 'sim' : 'nao';

    // Status que aparece na tabela (o mesmo do carrinho do cliente)
    $linha['status_info'] = statusDoPedido($linha);
    $linha['f_arte'] = ($linha['precisa_arte'] == 1 && $linha['arte'] == '') ? 'sim' : 'nao';

    // Prazo próximo: o prazo é daqui a 15 dias ou menos
    $linha['f_prazo'] = ($linha['prazo'] != '' && strtotime($linha['prazo']) <= strtotime('+15 days')) ? 'sim' : 'nao';

    // Mês usado no menu "Painel" da lateral (exemplo: 2026-10).
    // Se o pedido tem prazo (data de entrega), vale o mês do PRAZO, assim a Júlia vê o que está agendado para cada mês.
    // Se não tem prazo, vale o mês em que o pedido foi feito.
    $dataDoMes = $linha['prazo'] != '' ? $linha['prazo'] : $linha['data_pedido'];
    $linha['f_mes'] = date('Y-m', strtotime($dataDoMes));

    $linhas[] = $linha;
}

// As últimas coisas que aconteceram (caixa amarela "Histórico")
$resultado = $con->query("SELECT descricao, data_hora, autor FROM historico ORDER BY data_hora DESC, id DESC LIMIT 10");
$historico = [];
while ($linha = mysqli_fetch_assoc($resultado)) {
    $historico[] = $linha;
}

// Clientes que já fizeram pedido (um por nome) e quantos pedidos cada um tem
$resultado = $con->query("SELECT cliente, COUNT(*) AS total FROM pedidos GROUP BY cliente ORDER BY cliente");
$clientes = [];
while ($linha = mysqli_fetch_assoc($resultado)) {
    $clientes[] = $linha;
}

// Todos os produtos (ativos e desativados). Os desativados não aparecem na loja, mas ficam aqui para poder ativar de novo
$resultado = $con->query("SELECT p.id, p.nome, p.preco, p.tipo, p.estoque, p.ativo, t.nome AS topico
                          FROM produtos p
                          LEFT JOIN topicos t ON t.id = p.id_topico
                          ORDER BY p.ativo DESC, p.nome");
$produtos = [];
while ($linha = mysqli_fetch_assoc($resultado)) {
    $produtos[] = $linha;
}

// Categorias que já existem (o formulário de produto sugere esses nomes)
$resultado = $con->query("SELECT nome FROM topicos ORDER BY nome");
$topicos = [];
while ($linha = mysqli_fetch_assoc($resultado)) {
    $topicos[] = $linha['nome'];
}

// Administradores (quem tem acesso ao painel). A view vw_administradores_seguro não tem a coluna senha
$resultado = $con->query("SELECT id, nome, email, ativo FROM vw_administradores_seguro ORDER BY nome");
$administradores = [];
while ($linha = mysqli_fetch_assoc($resultado)) {
    $administradores[] = $linha;
}

// Meses que têm pedido, do mais novo para o mais antigo, com a quantidade de pedidos de cada um.
// O mês de hoje sempre aparece, mesmo sem pedidos ainda.
$meses = [date('Y-m') => 0];
$vistos = [];
foreach ($linhas as $linha) {
    if (!isset($vistos[$linha['id_pedido']])) {
        $vistos[$linha['id_pedido']] = true;
        $mes = $linha['f_mes'];
        $meses[$mes] = isset($meses[$mes]) ? $meses[$mes] + 1 : 1;
    }
}
krsort($meses);

// Lista de status para escolher no painel: os padrão + os que a Júlia já criou
$listaStatus = statusPadrao();
$resultadoStatus = $con->query("SELECT DISTINCT status FROM pedidos WHERE status IS NOT NULL AND status <> '' ORDER BY status");
while ($linhaStatus = mysqli_fetch_assoc($resultadoStatus)) {
    if (!in_array($linhaStatus['status'], $listaStatus)) {
        $listaStatus[] = $linhaStatus['status'];
    }
}

// Últimos feedbacks enviados pelo rodapé do site (estrelas e texto)
$feedbacks = [];
$resultadoFeedbacks = $con->query("SELECT estrelas, mensagem, data_hora FROM feedbacks ORDER BY id DESC LIMIT 30");
while ($linhaFeedback = mysqli_fetch_assoc($resultadoFeedbacks)) {
    $feedbacks[] = $linhaFeedback;
}
