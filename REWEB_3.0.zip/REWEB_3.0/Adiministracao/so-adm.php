<?php
// Coloque este arquivo no começo de toda página de administração:
//   require('so-adm.php');
// Se a pessoa não for ADM, ela volta para a tela inicial antes de ver qualquer coisa.
@session_start();

if (!isset($_SESSION['usuario']['tipo']) || $_SESSION['usuario']['tipo'] != 'adm') {
    header('Location: ../index.php');
    exit;
}

// Confere no banco se essa conta de ADM ainda está ativa.
// Assim, quando alguém é desativado no painel, perde o acesso na hora (mesmo com a página aberta).
require_once('conexao.php');
$idAdmin = isset($_SESSION['usuario']['admin_id']) ? (int) $_SESSION['usuario']['admin_id'] : 0;
$stmt = $con->prepare("SELECT ativo FROM administradores WHERE id = ?");
$stmt->bind_param("i", $idAdmin);
$stmt->execute();
$conta = mysqli_fetch_assoc($stmt->get_result());

if (!$conta || $conta['ativo'] != 1) {
    unset($_SESSION['usuario']); // tira o login dessa pessoa
    header('Location: ../index.php');
    exit;
}
