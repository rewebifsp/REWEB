// Tela única da administração (painel.php): filtros, números do topo, exportar e as janelas.

const tabela = document.getElementById('tabelaEncomendas');
const buscaTabela = document.getElementById('buscaTabela');
const buscaLateral = document.getElementById('buscaLateral');

// Dados de cada linha (vêm do PHP), usados para preencher a janela "Editar encomenda"
const dadosPedidos = JSON.parse(document.getElementById('dadosPedidos').textContent);

// Tudo o que está filtrando a tabela neste momento
const filtros = {
    busca: '',        // texto digitado na pesquisa
    mes: '',          // mês escolhido na lateral (exemplo: 2026-10). Vazio = todos
    cliente: '',      // cliente escolhido na lateral. Vazio = todos
    rapido: '',       // botão rápido: aguardando, pronto, prazo ou arte
    colunas: {}       // filtro de cada coluna (funil): lista dos valores marcados, ex.: { 7: ['Não'], 0: ['Jak', 'Ana'] }
};

// Deixa o texto minúsculo e sem acento, assim "Prazo" acha "prazo" e "nao" acha "não"
function limpar(texto) {
    return texto.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
}

// Texto de uma célula; célula sem nada vira "(Vazias)", como no Excel
const VAZIA = '(Vazias)';
function valorDaCelula(celula) {
    const texto = celula.textContent.replace(/\s+/g, ' ').trim();
    return texto === '' ? VAZIA : texto;
}

// ------------------------------------------------------------
// Aplica todos os filtros e atualiza os quadros do topo
// ------------------------------------------------------------
function filtrar() {
    let pedidosVistos = new Set();
    let aguardando = new Set();
    let prontos = new Set();
    let faturamento = 0;

    tabela.querySelectorAll('tbody tr[data-item]').forEach((linha) => {
        const d = linha.dataset;

        let aparece = limpar(linha.textContent).includes(limpar(filtros.busca));

        if (aparece && filtros.mes !== '') {
            aparece = d.mes === filtros.mes;
        }
        if (aparece && filtros.cliente !== '') {
            aparece = d.cliente === filtros.cliente;
        }
        if (aparece && filtros.rapido !== '') {
            aparece =
                (filtros.rapido === 'aguardando' && d.pagou === 'nao') ||
                (filtros.rapido === 'pronto' && d.pronto === 'sim') ||
                (filtros.rapido === 'prazo' && d.prazo === 'sim') ||
                (filtros.rapido === 'arte' && d.arte === 'sim');
        }
        if (aparece) {
            for (const coluna in filtros.colunas) {
                if (!filtros.colunas[coluna].includes(valorDaCelula(linha.cells[coluna]))) {
                    aparece = false;
                    break;
                }
            }
        }

        linha.hidden = !aparece;

        // Os quadros do topo contam só o que está aparecendo
        if (aparece) {
            pedidosVistos.add(d.pedido);
            if (d.pagou === 'nao') aguardando.add(d.pedido);
            if (d.pronto === 'sim') prontos.add(d.pedido);
            if (d.pagou === 'sim') faturamento += parseFloat(d.total);
        }
    });

    // Número com dois dígitos, como no desenho (02, 06, 84)
    const doisDigitos = (n) => String(n).padStart(2, '0');
    document.getElementById('kpiPedidos').textContent = doisDigitos(pedidosVistos.size);
    document.getElementById('kpiAguardando').textContent = doisDigitos(aguardando.size);
    document.getElementById('kpiProntos').textContent = doisDigitos(prontos.size);
    document.getElementById('kpiFaturamento').textContent =
        'R$' + faturamento.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ------------------------------------------------------------
// Pesquisas (a de cima e a da lateral mexem na mesma coisa)
// ------------------------------------------------------------
function pesquisar(texto) {
    filtros.busca = texto;
    buscaTabela.value = texto;
    buscaLateral.value = texto;
    filtrar();
}

buscaTabela.addEventListener('input', () => pesquisar(buscaTabela.value));
buscaLateral.addEventListener('input', () => pesquisar(buscaLateral.value));

// ------------------------------------------------------------
// Botões rápidos (Aguarda PGTO, Prontos, Prazo próximo, Enviar arte)
// ------------------------------------------------------------
document.querySelectorAll('[data-filtro]').forEach((botao) => {
    botao.addEventListener('click', () => {
        // Clicar de novo no botão que já está ligado desliga ele
        filtros.rapido = filtros.rapido === botao.dataset.filtro ? '' : botao.dataset.filtro;
        document.querySelectorAll('[data-filtro]').forEach((b) => {
            b.classList.toggle('ativo', b.dataset.filtro === filtros.rapido);
        });
        filtrar();
    });
});

// ------------------------------------------------------------
// Lateral: meses e clientes
// ------------------------------------------------------------
function marcarItemLateral() {
    document.querySelectorAll('.item-menu[data-mes]').forEach((b) => {
        b.classList.toggle('ativo', b.dataset.mes === filtros.mes);
    });
    document.querySelectorAll('.item-menu[data-cliente]').forEach((b) => {
        b.classList.toggle('ativo', b.dataset.cliente === filtros.cliente && filtros.cliente !== '');
    });
}

document.querySelectorAll('.item-menu[data-mes]').forEach((botao) => {
    botao.addEventListener('click', () => {
        filtros.mes = botao.dataset.mes;
        marcarItemLateral();
        filtrar();
    });
});

document.querySelectorAll('.item-menu[data-cliente]').forEach((botao) => {
    botao.addEventListener('click', () => {
        // Clicar de novo no mesmo cliente volta a mostrar todos
        filtros.cliente = filtros.cliente === botao.dataset.cliente ? '' : botao.dataset.cliente;
        marcarItemLateral();
        filtrar();
    });
});

// ------------------------------------------------------------
// Funil de cada coluna: abre uma lista com os valores da coluna e caixinhas para marcar
// (igual ao filtro do Excel: "Selecionar tudo", "(Vazias)", cada valor, pesquisa e Aplicar)
// ------------------------------------------------------------
const popFiltro = document.getElementById('popFiltro');
const popInput = document.getElementById('popInput');
const popNome = document.getElementById('popNome');
const popLista = document.getElementById('popLista');
let colunaAberta = null;

function fecharPop() {
    popFiltro.hidden = true;
    colunaAberta = null;
}

// Cria uma linha da lista: caixinha + texto
function criarOpcao(texto, valor, marcada, ehTodos) {
    const rotulo = document.createElement('label');
    rotulo.className = 'pop-opcao' + (ehTodos ? ' pop-todos' : '');
    const caixa = document.createElement('input');
    caixa.type = 'checkbox';
    caixa.checked = marcada;
    if (ehTodos) {
        caixa.id = 'popTodos';
    } else {
        caixa.className = 'pop-valor';
        caixa.value = valor;
    }
    rotulo.append(caixa, ' ' + texto);
    return rotulo;
}

// Monta a lista com os valores diferentes da coluna (olhando todas as linhas da tabela)
function montarLista(coluna) {
    const valores = new Set();
    tabela.querySelectorAll('tbody tr[data-item]').forEach((linha) => {
        valores.add(valorDaCelula(linha.cells[coluna]));
    });

    // Ordem alfabética/numérica; "(Vazias)" fica sempre no fim
    const ordenados = [...valores].filter((v) => v !== VAZIA)
        .sort((a, b) => a.localeCompare(b, 'pt-BR', { numeric: true }));
    if (valores.has(VAZIA)) ordenados.push(VAZIA);

    // Sem filtro ainda = tudo marcado
    const marcados = filtros.colunas[coluna];
    popLista.innerHTML = '';
    popLista.appendChild(criarOpcao('Selecionar tudo', '', true, true));
    ordenados.forEach((v) => {
        popLista.appendChild(criarOpcao(v, v, marcados === undefined || marcados.includes(v), false));
    });
    atualizarSelecionarTudo();
}

// "Selecionar tudo" fica marcado só quando todas as opções visíveis na lista estão marcadas
function atualizarSelecionarTudo() {
    const valores = popLista.querySelectorAll('.pop-valor');
    document.getElementById('popTodos').checked = [...valores].every((c) => c.checked);
}

// Pesquisa dentro da lista: esconde as opções que não combinam
popInput.addEventListener('input', () => {
    const texto = limpar(popInput.value);
    popLista.querySelectorAll('.pop-valor').forEach((c) => {
        c.parentElement.hidden = !limpar(c.value).includes(texto);
    });
});

// Marcar/desmarcar "Selecionar tudo" mexe em todas as opções que aparecem na lista
popLista.addEventListener('change', (evento) => {
    if (evento.target.id === 'popTodos') {
        popLista.querySelectorAll('.pop-valor').forEach((c) => {
            if (!c.parentElement.hidden) c.checked = evento.target.checked;
        });
    }
    atualizarSelecionarTudo();
});

document.querySelectorAll('.filtro-coluna').forEach((botao) => {
    botao.addEventListener('click', (evento) => {
        evento.stopPropagation();
        const coluna = botao.dataset.col;

        // Clicar no mesmo funil de novo fecha a caixinha
        if (colunaAberta === coluna && !popFiltro.hidden) {
            fecharPop();
            return;
        }

        colunaAberta = coluna;
        popNome.textContent = botao.parentElement.textContent.trim().toLowerCase();
        popInput.value = '';
        montarLista(coluna);

        // Põe a caixinha embaixo do funil clicado
        const caixa = botao.getBoundingClientRect();
        popFiltro.style.top = (window.scrollY + caixa.bottom + 6) + 'px';
        popFiltro.style.left = Math.max(0, Math.min(window.scrollX + caixa.left, window.innerWidth - 250)) + 'px';
        popFiltro.hidden = false;
        popInput.focus();
    });
});

// Aplicar: guarda só os valores marcados (se tudo estiver marcado, tira o filtro da coluna)
document.getElementById('popAplicar').addEventListener('click', () => {
    const todos = [...popLista.querySelectorAll('.pop-valor')];
    const marcados = todos.filter((c) => c.checked).map((c) => c.value);

    if (marcados.length === todos.length) {
        delete filtros.colunas[colunaAberta];
    } else {
        filtros.colunas[colunaAberta] = marcados; // lista vazia = nada aparece, como no Excel
    }
    marcarFunis();
    filtrar();
    fecharPop();
});

// Limpar: tira o filtro desta coluna
document.getElementById('popLimpar').addEventListener('click', () => {
    delete filtros.colunas[colunaAberta];
    marcarFunis();
    filtrar();
    fecharPop();
});

// Funil fica vermelho quando a coluna está filtrada
function marcarFunis() {
    document.querySelectorAll('.filtro-coluna').forEach((b) => {
        b.classList.toggle('ativo', filtros.colunas[b.dataset.col] !== undefined);
    });
}

// Clicar fora ou apertar Esc fecha a caixinha
document.addEventListener('click', (evento) => {
    if (!popFiltro.hidden && !popFiltro.contains(evento.target)) fecharPop();
});
document.addEventListener('keydown', (evento) => {
    if (evento.key === 'Escape') fecharPop();
});

// ------------------------------------------------------------
// Limpar filtros: volta tudo ao começo
// ------------------------------------------------------------
document.getElementById('limpar').addEventListener('click', () => {
    filtros.busca = '';
    // O mês NÃO é limpo aqui: ele funciona como uma tabela à parte. Para voltar a todos, clique em "Todos os meses".
    filtros.cliente = '';
    filtros.rapido = '';
    filtros.colunas = {};
    buscaTabela.value = '';
    buscaLateral.value = '';
    document.querySelectorAll('[data-filtro]').forEach((b) => b.classList.remove('ativo'));
    marcarItemLateral();
    marcarFunis();
    fecharPop();
    filtrar();
});

// ------------------------------------------------------------
// Exportar: baixa as linhas que estão aparecendo em um arquivo CSV (abre no Excel)
// ------------------------------------------------------------
document.getElementById('exportar').addEventListener('click', () => {
    const linhas = [...tabela.querySelectorAll('tr')].filter((l) => !l.hidden && !l.classList.contains('linha-vazia'));
    const csv = linhas.map((linha) => [...linha.cells]
        .map((celula) => '"' + celula.innerText.trim().replaceAll('"', '""') + '"').join(';')).join('\n');

    const arquivo = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(arquivo);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'encomendas.csv';
    link.click();
    URL.revokeObjectURL(url);
});

// ------------------------------------------------------------
// Menu da lateral em telas pequenas
// ------------------------------------------------------------
const lateral = document.getElementById('lateral');
const botaoMenu = document.getElementById('botaoMenu');

botaoMenu.addEventListener('click', () => {
    const aberta = lateral.classList.toggle('aberta');
    botaoMenu.setAttribute('aria-expanded', aberta);
});

// ------------------------------------------------------------
// Janelas (nova encomenda, editar encomenda, novo produto)
// ------------------------------------------------------------
const janelaNova = document.getElementById('janelaNova');
const janelaEditar = document.getElementById('janelaEditar');
const janelaProduto = document.getElementById('janelaProduto');
const janelaAdmin = document.getElementById('janelaAdmin');

// Botões "Cancelar" fecham a janela em que estão
document.querySelectorAll('[data-fechar]').forEach((botao) => {
    botao.addEventListener('click', () => botao.closest('dialog').close());
});

// Clicar fora da janela NÃO fecha mais (a Júlia perdia o que tinha digitado).
// A tecla Esc também não fecha. A janela só fecha em "Cancelar" ou ao salvar.
document.querySelectorAll('dialog').forEach((janela) => {
    janela.addEventListener('cancel', (evento) => evento.preventDefault());
});

// Data de hoje no formato do campo de data (aaaa-mm-dd), usando o horário do computador
function hoje() {
    const agora = new Date();
    agora.setMinutes(agora.getMinutes() - agora.getTimezoneOffset());
    return agora.toISOString().slice(0, 10);
}

document.getElementById('abrirNova').addEventListener('click', () => {
    document.getElementById('formNova').reset();
    document.getElementById('novaData').min = hoje(); // não deixa escolher dia que já passou
    document.getElementById('novoPrazo').min = hoje();
    document.getElementById('novaData').value = hoje();
    janelaNova.showModal();
});

// Status: ao escolher "+ Novo status", aparece o campo para digitar o nome dele
const listaStatus = document.getElementById('editStatus');
function mostrarCampoNovoStatus() {
    const novo = listaStatus.value === '__novo__';
    document.getElementById('campoNovoStatus').hidden = !novo;
    document.getElementById('novoStatus').required = novo;
    if (!novo) document.getElementById('novoStatus').value = '';
}
listaStatus.addEventListener('change', mostrarCampoNovoStatus);

// Telefone: só aceita números e ( ) - + espaço, e no máximo 15 dígitos
document.querySelectorAll('.campo-telefone').forEach((campo) => {
    campo.addEventListener('input', () => {
        let texto = campo.value.replace(/[^0-9()+\-\s]/g, '');
        let digitos = 0;
        let resultado = '';
        for (const letra of texto) {
            if (/\d/.test(letra)) {
                if (digitos >= 15) continue; // passou de 15 dígitos: ignora
                digitos++;
            }
            resultado += letra;
        }
        campo.value = resultado;
    });
});

// O prazo não pode ser antes da data da encomenda
document.getElementById('novaData').addEventListener('change', (e) => {
    document.getElementById('novoPrazo').min = e.target.value || hoje();
});

// Categoria do produto: ao escolher "+ Nova categoria", aparece o campo para digitar o nome dela
const listaCategoria = document.querySelector('#formProduto [name="topico"]');
const campoNovaCategoria = document.getElementById('campoNovaCategoria');
const novaCategoria = document.getElementById('novaCategoria');

function mostrarCampoNovaCategoria() {
    const nova = listaCategoria.value === '__nova__';
    campoNovaCategoria.hidden = !nova; // mostra ou esconde o campo
    novaCategoria.required = nova;     // só é obrigatório enquanto está aparecendo
    if (!nova) novaCategoria.value = '';
}

listaCategoria.addEventListener('change', mostrarCampoNovaCategoria);

// Estoque: só pronta entrega tem. O campo aparece (e é obrigatório) só quando o tipo é "Pronta entrega"
const listaTipo = document.querySelector('#formProduto [name="tipo"]');
const campoEstoque = document.getElementById('campoEstoque');
const estoqueProduto = document.getElementById('estoqueProduto');

function mostrarCampoEstoque() {
    const prontaEntrega = listaTipo.value === 'pronta_entrega';
    campoEstoque.hidden = !prontaEntrega;
    estoqueProduto.required = prontaEntrega;
    if (!prontaEntrega) estoqueProduto.value = '';
}

listaTipo.addEventListener('change', mostrarCampoEstoque);

document.getElementById('abrirProduto').addEventListener('click', () => {
    document.getElementById('formProduto').reset();
    mostrarCampoNovaCategoria(); // o reset volta a lista para o começo, então esconde o campo
    mostrarCampoEstoque();
    janelaProduto.showModal();
});

// Repor o estoque de um produto de pronta entrega (botão ao lado do produto na lateral)
document.querySelectorAll('[data-produto]').forEach((botao) => {
    botao.addEventListener('click', () => {
        const resposta = prompt(
            'Quantas unidades de "' + botao.dataset.nome + '" tem em estoque agora?\n' +
            '(hoje: ' + botao.dataset.estoque + '. Com 0 o produto some da loja, com 1 ou mais ele aparece.)',
            botao.dataset.estoque
        );
        if (resposta === null) return; // clicou em Cancelar

        if (!/^\d+$/.test(resposta.trim())) {
            alert('Digite só um número (0 ou mais).');
            return;
        }

        const dados = new FormData();
        dados.append('csrf', document.querySelector('#formProduto [name="csrf"]').value);
        dados.append('acao', 'definir_estoque');
        dados.append('id_produto', botao.dataset.produto);
        dados.append('estoque', resposta.trim());
        enviar(dados, botao);
    });
});

// Ativar ou desativar um produto (troca o "ativo" do banco entre 1 e 0)
document.querySelectorAll('[data-ativar]').forEach((botao) => {
    botao.addEventListener('click', () => {
        const desativando = botao.dataset.ativo === '1';
        const pergunta = desativando
            ? 'Desativar "' + botao.dataset.nome + '"? Ele deixa de aparecer na loja (você pode ativar de novo depois).'
            : 'Ativar "' + botao.dataset.nome + '"? Ele volta a aparecer na loja.';
        if (!confirm(pergunta)) return;

        const dados = new FormData();
        dados.append('csrf', document.querySelector('#formProduto [name="csrf"]').value);
        dados.append('acao', 'alternar_produto');
        dados.append('id_produto', botao.dataset.ativar);
        dados.append('ativo', desativando ? '0' : '1');
        enviar(dados, botao);
    });
});

document.getElementById('abrirAdmin').addEventListener('click', () => {
    document.getElementById('formAdmin').reset();
    janelaAdmin.showModal();
});

// Clicar numa linha da tabela abre a janela de edição daquela encomenda
function abrirEdicao(linha) {
    const d = dadosPedidos[linha.dataset.item];
    if (!d) return;

    document.getElementById('editIdPedido').value = d.id_pedido;
    document.getElementById('editIdItem').value = d.id_item;
    document.getElementById('editCliente').value = d.cliente || '';
    document.getElementById('editProduto').value = d.produto || '';
    document.getElementById('editValor').value = d.valor || 0;
    document.getElementById('editQuantidade').value = d.quantidade || 1;
    document.getElementById('editData').value = d.data || '';
    document.getElementById('editTema').value = d.tema || '';
    document.getElementById('editPrazo').value = d.prazo || '';
    document.getElementById('editTelefone').value = d.telefone || '';
    document.getElementById('editEndereco').value = d.endereco || '';
    document.getElementById('editEmail').value = d.email || '';
    document.getElementById('editObservacoes').value = d.observacoes || '';
    document.getElementById('editStatus').value = d.status;
    document.getElementById('editStatusOriginal').value = d.status;
    mostrarCampoNovoStatus();
    document.getElementById('editPagou').checked = d.pago === 1;
    document.getElementById('editPronto').checked = d.pronto === 1;
    document.getElementById('editBuscou').checked = d.buscou === 1;
    document.getElementById('editPrecisaArte').checked = d.precisa_arte === 1;
    janelaEditar.querySelector('input[type="file"]').value = '';

    // Link para ver a arte que já foi enviada
    const arte = document.getElementById('editArteAtual');
    arte.hidden = !d.arte;
    if (d.arte) arte.href = '../' + d.arte;

    // O que o cliente escreveu na tela do produto
    const detalhes = document.getElementById('editDetalhes');
    detalhes.textContent = '';
    Object.entries(d.detalhes || {}).forEach(([nome, valor]) => {
        const p = document.createElement('div');
        const negrito = document.createElement('strong');
        negrito.textContent = nome + ': ';
        p.append(negrito, document.createTextNode(valor));
        detalhes.append(p);
    });
    detalhes.hidden = detalhes.children.length === 0;

    janelaEditar.showModal();
}

tabela.querySelectorAll('tbody tr[data-item]').forEach((linha) => {
    linha.addEventListener('click', (evento) => {
        // Clicar no clips (ver a arte) abre a imagem, não a janela
        if (evento.target.closest('a')) return;
        abrirEdicao(linha);
    });
    linha.addEventListener('keydown', (evento) => {
        if (evento.key === 'Enter') abrirEdicao(linha);
    });
});

// Manda os dados de um formulário para o acoes.php e recarrega a página se deu certo
async function enviar(dados, botao) {
    if (botao) botao.disabled = true;
    try {
        const resposta = await fetch('acoes.php', { method: 'POST', body: dados });
        const resultado = await resposta.json();
        if (resultado.ok) {
            window.location.reload();
            return;
        }
        alert(resultado.erro || 'Não foi possível concluir.');
    } catch (erro) {
        alert('Erro de conexão com o servidor. Tente de novo.');
    }
    if (botao) botao.disabled = false;
}

// Transforma bytes em texto fácil de ler (exemplo: 2,5 MB)
function emMB(bytes) {
    return (bytes / 1048576).toFixed(1).replace('.', ',') + ' MB';
}

// Confere o tamanho das fotos do produto ANTES de enviar.
// Os limites vêm do servidor (estão no formulário em data-limite-foto e data-limite-total).
// Devolve a mensagem do problema, ou '' se está tudo certo.
function conferirFotos(formulario) {
    const limiteFoto = Number(formulario.dataset.limiteFoto);   // limite de cada foto, em bytes
    const limiteTotal = Number(formulario.dataset.limiteTotal); // limite de todas as fotos juntas, em bytes
    const nomes = ['foto principal', 'foto 2', 'foto 3'];
    const campos = formulario.querySelectorAll('input[type="file"]');
    let total = 0;

    for (let i = 0; i < campos.length; i++) {
        const arquivo = campos[i].files[0];
        if (!arquivo) continue; // nenhuma foto escolhida nesse campo

        total += arquivo.size;
        if (limiteFoto && arquivo.size > limiteFoto) {
            return 'A ' + nomes[i] + ' é grande demais (' + emMB(arquivo.size) + '). O limite é ' + emMB(limiteFoto) + ' por foto. Escolha uma foto menor.';
        }
    }

    if (limiteTotal && total > limiteTotal) {
        return 'As fotos juntas são grandes demais (' + emMB(total) + '). O limite é ' + emMB(limiteTotal) + ' no total. Escolha fotos menores.';
    }
    return '';
}

['formNova', 'formEditar', 'formProduto', 'formAdmin'].forEach((id) => {
    const formulario = document.getElementById(id);
    formulario.addEventListener('submit', (evento) => {
        evento.preventDefault();

        // No formulário de produto, confere o tamanho das fotos antes de enviar
        if (id === 'formProduto') {
            const problema = conferirFotos(formulario);
            if (problema) {
                alert(problema);
                return;
            }
        }

        // No formulário de administrador, confere se as duas senhas são iguais antes de enviar
        if (id === 'formAdmin' && formulario.senha_admin.value !== formulario.confirmar_admin.value) {
            alert('As senhas não são iguais.');
            return;
        }

        enviar(new FormData(formulario), formulario.querySelector('.botao-salvar'));
    });
});

// Desativar ou reativar um administrador (depois de confirmar)
document.querySelectorAll('[data-admin]').forEach((botao) => {
    botao.addEventListener('click', () => {
        const desativar = botao.dataset.ativo === '0';
        const pergunta = desativar
            ? 'Desativar o acesso de ' + botao.dataset.nome + '? Essa pessoa não vai mais conseguir entrar no painel.'
            : 'Reativar o acesso de ' + botao.dataset.nome + '?';
        if (!confirm(pergunta)) return;

        const dados = new FormData();
        dados.append('csrf', document.querySelector('#formAdmin [name="csrf"]').value);
        dados.append('acao', 'admin_ativo');
        dados.append('id_admin', botao.dataset.admin);
        dados.append('ativo', botao.dataset.ativo);
        enviar(dados, botao);
    });
});

// Excluir a encomenda (o pedido inteiro) depois de confirmar
document.getElementById('excluirEncomenda').addEventListener('click', () => {
    const nome = document.getElementById('editCliente').value;
    if (!confirm('Excluir a encomenda de ' + nome + '? Todos os itens dela serão apagados.')) return;

    const dados = new FormData();
    dados.append('csrf', document.querySelector('#formEditar [name="csrf"]').value);
    dados.append('acao', 'excluir_encomenda');
    dados.append('id_pedido', document.getElementById('editIdPedido').value);
    enviar(dados, document.getElementById('excluirEncomenda'));
});

// Começa mostrando os números de tudo
filtrar();
