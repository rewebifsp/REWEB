
// CARROSSEL DA TELA INICIAL
// Ideia simples: os cartões ficam numa fila (os produtos e, no fim, o cartão "Ver mais").
// A variável "posicao" diz quantos cartões a fila já andou para a esquerda.
//   posicao 0  -> começo da fila: a seta da esquerda trava
//   última posicao -> o "Ver mais" aparece no fim: a seta da direita trava
// Para andar, o script só muda o "transform" dos cartões. O CSS cuida da animação de deslizar.
// A fila NÃO gira em círculo: ela começa no primeiro produto e termina no "Ver mais".

(function () {

    const carrossel = document.getElementById('carrossel');

    // Se todos os produtos estiverem sem estoque, a tela inicial nem cria o carrossel: não tem o que animar
    if (!carrossel) return;

    const voltar = document.getElementById('voltar');
    const avancar = document.getElementById('avancar');
    const cartoes = carrossel.querySelectorAll('.produto-card');

    let posicao = 0; // quantos cartões a fila já andou para a esquerda


    // Quanto a fila anda em cada clique: largura de um cartão + o espaço entre os cartões (12px, igual ao CSS)
    function calcularPasso() {

        return cartoes[0].offsetWidth + 12;

    }


    // Quantos cartões cabem na tela agora (4 no computador, 2 no celular: o CSS é quem decide)
    function quantosCabem() {

        const estilo = getComputedStyle(carrossel);
        const larguraUtil = carrossel.clientWidth - parseFloat(estilo.paddingLeft) - parseFloat(estilo.paddingRight);

        // n cartões ocupam n * passo - 12, então n = (largura + 12) / passo
        return Math.round((larguraUtil + 12) / calcularPasso());

    }


    // Até onde a fila pode andar: quando o último cartão ("Ver mais") encosta no fim, não anda mais
    function ultimaPosicao() {

        return Math.max(0, cartoes.length - quantosCabem());

    }


    // Põe a fila na posição certa e trava ou libera as setas
    function atualizar() {

        const ultima = ultimaPosicao();

        // Se a janela ficou maior e a posição passou do limite, volta para o limite
        if (posicao > ultima) posicao = ultima;

        const deslocamento = posicao * calcularPasso();

        cartoes.forEach(function (cartao) {
            cartao.style.transform = 'translateX(-' + deslocamento + 'px)';
        });

        voltar.disabled = (posicao === 0);      // no começo não dá para ir mais para a esquerda
        avancar.disabled = (posicao >= ultima); // no "Ver mais" não dá para ir mais para a direita

        // Se todos os cartões já cabem na tela, não tem para onde andar: esconde as duas setas
        const visibilidade = (ultima === 0) ? 'hidden' : 'visible';
        voltar.style.visibility = visibilidade;
        avancar.style.visibility = visibilidade;

    }


    // SETA DA DIREITA: anda um cartão, até chegar no "Ver mais"
    avancar.addEventListener('click', function () {

        if (posicao < ultimaPosicao()) {
            posicao++;
            atualizar();
        }

    });


    // SETA DA ESQUERDA: volta um cartão, até chegar no primeiro
    voltar.addEventListener('click', function () {

        if (posicao > 0) {
            posicao--;
            atualizar();
        }

    });


    // Se a janela mudar de tamanho (ou o celular girar), quantos cartões cabem muda: acerta a fila de novo
    window.addEventListener('resize', atualizar);

    // Ao abrir a página
    atualizar();

})();


// CARROSSEL DE IMAGENS DO BANNER
// Ideia simples: "atual" é o número da imagem que está aparecendo (0, 1 ou 2).
// Mostrar uma imagem = tirar a classe "ativo" de todas e colocar só na escolhida.
// A cada 5 segundos o script passa sozinho para a próxima (e volta para a primeira no fim).
(function () {

    const imagens = document.querySelectorAll('.banner-slide');
    const bolinhas = document.querySelectorAll('#banner-bolinhas button');
    const banner = document.getElementById('inicio');

    if (imagens.length == 0) return;

    let atual = 0;
    let relogio = null;

    function mostrar(numero) {

        // Passou do fim volta para a primeira; passou do começo vai para a última
        if (numero >= imagens.length) numero = 0;
        if (numero < 0) numero = imagens.length - 1;

        for (let i = 0; i < imagens.length; i++) {
            imagens[i].classList.toggle('ativo', i == numero);
            bolinhas[i].classList.toggle('ativa', i == numero);
        }

        atual = numero;
    }

    function comecarAutomatico() {
        pararAutomatico();
        relogio = setInterval(function () {
            mostrar(atual + 1);
        }, 5000);
    }

    function pararAutomatico() {
        if (relogio) clearInterval(relogio);
    }

    document.getElementById('banner-voltar').addEventListener('click', function () {
        mostrar(atual - 1);
        comecarAutomatico(); // reinicia a contagem dos 5 segundos
    });

    document.getElementById('banner-avancar').addEventListener('click', function () {
        mostrar(atual + 1);
        comecarAutomatico();
    });

    for (let i = 0; i < bolinhas.length; i++) {
        bolinhas[i].addEventListener('click', function () {
            mostrar(i);
            comecarAutomatico();
        });
    }

    // Com o mouse em cima, o banner não troca sozinho (dá tempo de olhar)
    banner.addEventListener('mouseenter', pararAutomatico);
    banner.addEventListener('mouseleave', comecarAutomatico);

    comecarAutomatico();

})();
